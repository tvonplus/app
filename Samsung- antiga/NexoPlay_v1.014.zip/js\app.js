var NexoApp = (function () {
    var state = {
        screen: "login",
        focusElement: null,
        loginField: "code",
        login: { code: "", username: "", password: "" },
        loginKeyboardField: null,
        loginKeyboardValue: "",
        loginKeyboardUppercase: false,
        accessData: null,
        codeEntry: null,
        session: null,
        savedSessionInfo: null,
        currentType: null,
        currentCategory: null,
        currentCategoryName: "",
        catalogItems: [],
        catalogViewItems: [],
        catalogRenderedCount: 0,
        detailOpen: false,
        detailItem: null,
        detailReturnView: null,
        detailResumeEntry: null,
        seriesOpen: false,
        seriesItem: null,
        seriesData: null,
        seriesSeason: null,
        seriesSeasonMenuOpen: false,
        seriesFocusEpisodeId: "",
        searchQuery: "",
        searchActive: false,
        modalReturnFocus: null,
        serverModalSourceIndex: 0,
        playerReturnFocus: null,
        playerReturnSeriesContext: null,
        preview: false,
        modalOpen: false,
        playerOpen: false,
        toastTimer: null,
        volumeTimer: null,
        loadingTimer: null,
        enterPressed: false,
        enterLongFired: false,
        enterHoldTimer: null,
        enterShortTimer: null,
        enterHoldElement: null,
        enterReleaseTimer: null,
        enterRepeatSeen: false,
        enterSuppressUntil: 0,
        enterKeyUpObserved: false,
        enterStartedAt: 0,
        recentTimer: null,
        favoriteLookup: null,
        recentPending: null,
        recentStarted: false,
        recentRecorded: false,
        recentLastSavedTime: 0,
        recentMigration: null,
        watchedLookup: null,
        seriesReturnView: null,
        seriesContinueEntry: null,
        playerType: null,
        playerItem: null,
        playerEpisodeContext: null,
        playerCurrentTime: 0,
        playerDuration: 0,
        playerResumeTime: 0,
        playerResumeApplied: false,
        playerAdvancePrepared: false,
        playerAutoAdvancePending: false,
        playerAutoAdvanceTimer: null,
        playerPanelOpen: false,
        playerPanelSeason: null,
        playerPanelSeasonMenuOpen: false,
        playerPanelTimer: null,
        playerDisplayMode: "auto",
        playerToken: 0,
        playerTitle: "",
        playerReconnectTimer: null,
        playerReconnectAttempts: 0,
        playerReconnectReason: "",
        pendingRecentDelete: null,
        pendingFavoriteRemove: null,
        pendingSavedServerOpen: null,
        parentalSettings: null,
        parentalPinMode: "",
        parentalPinValue: "",
        parentalNewPin: "",
        parentalPinSuccess: null,
        parentalCategoryType: "live",
        parentalCategories: { live: null, movie: null, series: null },
        parentalCategoryNames: { live: {}, movie: {}, series: {} },
        parentalModalView: "",
        latestCatalogCache: { serverHost: "", live: null, movie: null, series: null },
        latestCatalogLoading: { live: false, movie: false, series: false },
        latestCatalogWaiters: { live: [], movie: [], series: [] },
        latestCatalogImages: { movie: [], series: [] },
        catalogCategories: { live: null, movie: null, series: null },
        catalogCategoryLoading: { live: false, movie: false, series: false },
        catalogCategoryWaiters: { live: [], movie: [], series: [] },
        catalogLoadStatus: { live: "pending", movie: "pending", series: "pending" },
        catalogLoadedDate: "",
        catalogRestored: false,
        catalogUpdateDays: 1,
        catalogBlocking: false,
        latestPrefetchTimer: null,
        latestPrefetchToken: 0,
        catalogStatusTimer: null,
        catalogDailyTimer: null,
        favoriteOpenType: null,
        clockTimer: null,
        suspended: false,
        initialized: false
    };

    function byId(id) {
        return document.getElementById(id);
    }

    function hasClass(element, name) {
        return element && (" " + element.className + " ").indexOf(" " + name + " ") >= 0;
    }

    function addClass(element, name) {
        if (element && !hasClass(element, name)) {
            element.className += (element.className ? " " : "") + name;
        }
    }

    function removeClass(element, name) {
        if (element) {
            element.className = (" " + element.className + " ").replace(" " + name + " ", " ").replace(/^\s+|\s+$/g, "");
        }
    }

    function setScreen(name) {
        var screens = document.getElementsByClassName("screen");
        var i;
        for (i = 0; i < screens.length; i += 1) {
            removeClass(screens[i], "active");
        }
        addClass(byId("screen-" + name), "active");
        state.screen = name;
    }

    function visible(element) {
        var node = element;
        while (node && node !== document.body) {
            if (hasClass(node, "hidden") || (node.style && node.style.display === "none")) {
                return false;
            }
            node = node.parentNode;
        }
        return true;
    }

    function focusables() {
        var scope = state.modalOpen ? byId("modal") : byId("screen-" + state.screen);
        var all = scope ? scope.getElementsByClassName("focusable") : [];
        var result = [];
        var i;
        for (i = 0; i < all.length; i += 1) {
            if (visible(all[i]) && !all[i].disabled) {
                result.push(all[i]);
            }
        }
        return result;
    }

    function updateMenuFocusIcon(element, selected) {
        var icons;
        var icon;
        var defaultSource;
        var selectedSource;
        if (!element || (!hasClass(element, "menu-item") && !hasClass(element, "catalog-search-button"))) { return; }
        icons = element.getElementsByClassName("menu-item-icon");
        if (!icons.length) { return; }
        icon = icons[0];
        defaultSource = icon.getAttribute("data-default-src") || icon.getAttribute("src") || "";
        if (!icon.getAttribute("data-default-src")) { icon.setAttribute("data-default-src", defaultSource); }
        if (!selected) {
            icon.setAttribute("src", defaultSource);
            return;
        }
        selectedSource = defaultSource.replace(/\.png$/i, "-selected.png");
        icon.setAttribute("src", selectedSource);
    }

    function setFocus(element) {
        if (!element || !visible(element)) {
            return;
        }
        if (state.focusElement) {
            updateMenuFocusIcon(state.focusElement, false);
            removeClass(state.focusElement, "focused");
            try { state.focusElement.blur(); } catch (ignoreBlur) {}
        }
        state.focusElement = element;
        addClass(element, "focused");
        updateMenuFocusIcon(element, true);
        try { element.focus(); } catch (ignore) {}
        ensureVisible(element);
        updateFavoriteCarouselArrow(element);
        if (element.getAttribute("data-field")) {
            state.loginField = element.getAttribute("data-field");
        }
    }

    function focusFirst(preferredId) {
        var preferred = preferredId ? byId(preferredId) : null;
        var items = focusables();
        if (preferred && visible(preferred)) {
            setFocus(preferred);
        } else if (items.length) {
            setFocus(items[0]);
        }
    }

    function ensureVisible(element) {
        var parent = element.parentNode;
        var rect;
        var parentRect;
        while (parent && parent !== document.body) {
            if (hasClass(parent, "items-list") || hasClass(parent, "series-season-menu") || hasClass(parent, "content-scroll") || hasClass(parent, "server-grid") ||
                    hasClass(parent, "parental-category-grid")) {
                rect = element.getBoundingClientRect();
                parentRect = parent.getBoundingClientRect();
                if (rect.bottom > parentRect.bottom) {
                    parent.scrollTop += rect.bottom - parentRect.bottom + 10;
                } else if (rect.top < parentRect.top) {
                    parent.scrollTop -= parentRect.top - rect.top + 10;
                }
                if (rect.right > parentRect.right) {
                    parent.scrollLeft += rect.right - parentRect.right + 12;
                } else if (rect.left < parentRect.left) {
                    parent.scrollLeft -= parentRect.left - rect.left + 12;
                }
            }
            if (hasClass(parent, "category-strip") || hasClass(parent, "card-row") || hasClass(parent, "player-control-strip") || hasClass(parent, "server-source-tabs")) {
                rect = element.getBoundingClientRect();
                parentRect = parent.getBoundingClientRect();
                if (rect.right > parentRect.right) {
                    parent.scrollLeft += rect.right - parentRect.right + 12;
                } else if (rect.left < parentRect.left) {
                    parent.scrollLeft -= parentRect.left - rect.left + 12;
                }
            }
            parent = parent.parentNode;
        }
    }

    function moveFocus(direction) {
        var items = focusables();
        var current = state.focusElement;
        var currentRect;
        var cx;
        var cy;
        var best = null;
        var bestScore = 9999999;
        var i;
        var rect;
        var x;
        var y;
        var dx;
        var dy;
        var primary;
        var secondary;
        var score;

        if (!current || items.indexOf(current) < 0) {
            focusFirst();
            return;
        }

        currentRect = current.getBoundingClientRect();
        cx = currentRect.left + currentRect.width / 2;
        cy = currentRect.top + currentRect.height / 2;

        for (i = 0; i < items.length; i += 1) {
            if (items[i] === current) { continue; }
            rect = items[i].getBoundingClientRect();
            x = rect.left + rect.width / 2;
            y = rect.top + rect.height / 2;
            dx = x - cx;
            dy = y - cy;

            if (direction === "left" && dx >= -3) { continue; }
            if (direction === "right" && dx <= 3) { continue; }
            if (direction === "up" && dy >= -3) { continue; }
            if (direction === "down" && dy <= 3) { continue; }

            if (direction === "left" || direction === "right") {
                primary = Math.abs(dx);
                secondary = Math.abs(dy);
            } else {
                primary = Math.abs(dy);
                secondary = Math.abs(dx);
            }
            score = primary + secondary * 2.4;
            if (score < bestScore) {
                bestScore = score;
                best = items[i];
            }
        }

        if (best) {
            setFocus(best);
        }
    }

    function moveSequentialFocus(direction) {
        var items = focusables();
        var currentIndex = -1;
        var i;
        var nextIndex;
        for (i = 0; i < items.length; i += 1) {
            if (items[i] === state.focusElement) {
                currentIndex = i;
                break;
            }
        }
        if (!items.length) { return; }
        if (currentIndex < 0) {
            setFocus(items[0]);
            return;
        }
        nextIndex = currentIndex + ((direction === "up" || direction === "left") ? -1 : 1);
        if (nextIndex >= 0 && nextIndex < items.length) {
            setFocus(items[nextIndex]);
        }
    }

    function moveFocusSafely(direction) {
        var before = state.focusElement;
        if (state.screen === "login") {
            moveSequentialFocus(direction);
            return;
        }
        try { moveFocus(direction); } catch (ignoreNavigation) {}
        if (state.focusElement === before) {
            moveSequentialFocus(direction);
        }
    }

    function focusCollectionNeighbor(collection, current, direction) {
        var index = -1;
        var i;
        for (i = 0; i < collection.length; i += 1) {
            if (collection[i] === current) { index = i; break; }
        }
        if (index < 0) { return false; }
        if (direction === "left" && index > 0) {
            setFocus(collection[index - 1]);
        } else if (direction === "right" && index < collection.length - 1) {
            setFocus(collection[index + 1]);
        }
        return true;
    }

    function focusActiveParentalType() {
        var tabs = byId("modal") ? byId("modal").getElementsByClassName("parental-type-button") : [];
        var i;
        for (i = 0; i < tabs.length; i += 1) {
            if (tabs[i].getAttribute("data-type") === state.parentalCategoryType) {
                setFocus(tabs[i]);
                return true;
            }
        }
        return false;
    }

    function focusNearestInGrid(grid, direction) {
        var items = grid.getElementsByClassName("parental-category-button");
        var current = state.focusElement;
        var currentRect = current.getBoundingClientRect();
        var cx = currentRect.left + currentRect.width / 2;
        var cy = currentRect.top + currentRect.height / 2;
        var best = null;
        var bestScore = 9999999;
        var i;
        var rect;
        var x;
        var y;
        var dx;
        var dy;
        var score;
        for (i = 0; i < items.length; i += 1) {
            if (items[i] === current) { continue; }
            rect = items[i].getBoundingClientRect();
            x = rect.left + rect.width / 2;
            y = rect.top + rect.height / 2;
            dx = x - cx;
            dy = y - cy;
            if (direction === "left" || direction === "right") {
                if (Math.abs(dy) > 10) { continue; }
                if (direction === "left" && dx >= -3) { continue; }
                if (direction === "right" && dx <= 3) { continue; }
                score = Math.abs(dx) + Math.abs(dy) * 5;
            } else {
                if (direction === "up" && dy >= -3) { continue; }
                if (direction === "down" && dy <= 3) { continue; }
                score = Math.abs(dy) + Math.abs(dx) * 2.4;
            }
            if (score < bestScore) {
                bestScore = score;
                best = items[i];
            }
        }
        if (best) {
            setFocus(best);
            return true;
        }
        if (direction === "up") { return focusActiveParentalType(); }
        return true;
    }

    function handleParentalSettingsNavigation(direction) {
        var current = state.focusElement;
        var actions;
        var tabs;
        var grid;
        var categoryItems;
        if (!state.modalOpen || state.parentalModalView !== "settings" || !current) { return false; }
        actions = byId("modal").getElementsByClassName("parental-settings-actions");
        tabs = byId("modal").getElementsByClassName("parental-type-tabs");
        grid = byId("parental-category-grid");
        if (actions.length && isInsideElement(actions[0], current)) {
            if (direction === "left" || direction === "right") {
                focusCollectionNeighbor(actions[0].getElementsByClassName("focusable"), current, direction);
            } else if (direction === "down") {
                focusActiveParentalType();
            }
            return true;
        }
        if (tabs.length && isInsideElement(tabs[0], current)) {
            if (direction === "left" || direction === "right") {
                focusCollectionNeighbor(tabs[0].getElementsByClassName("parental-type-button"), current, direction);
            } else if (direction === "down" && grid) {
                categoryItems = grid.getElementsByClassName("parental-category-button");
                if (categoryItems.length) { setFocus(categoryItems[0]); }
            } else if (direction === "up" && actions.length) {
                moveFocus("up");
            }
            return true;
        }
        if (grid && isInsideElement(grid, current)) {
            return focusNearestInGrid(grid, direction);
        }
        return false;
    }

    function focusActiveServerSource() {
        var tabs = byId("modal").getElementsByClassName("server-source-button");
        var i;
        for (i = 0; i < tabs.length; i += 1) {
            if (hasClass(tabs[i], "active-source")) {
                setFocus(tabs[i]);
                return true;
            }
        }
        return false;
    }

    function moveInsideServerGrid(grid, direction) {
        var items = grid.getElementsByClassName("modal-button");
        var current = state.focusElement;
        var currentRect = current.getBoundingClientRect();
        var cx = currentRect.left + currentRect.width / 2;
        var cy = currentRect.top + currentRect.height / 2;
        var best = null;
        var bestScore = 9999999;
        var refreshButtons;
        var i;
        var rect;
        var x;
        var y;
        var dx;
        var dy;
        var score;
        for (i = 0; i < items.length; i += 1) {
            if (items[i] === current) { continue; }
            rect = items[i].getBoundingClientRect();
            x = rect.left + rect.width / 2;
            y = rect.top + rect.height / 2;
            dx = x - cx;
            dy = y - cy;
            if (direction === "left" || direction === "right") {
                if (Math.abs(dy) > 9) { continue; }
                if (direction === "left" && dx >= -3) { continue; }
                if (direction === "right" && dx <= 3) { continue; }
                score = Math.abs(dx) + Math.abs(dy) * 5;
            } else {
                if (direction === "up" && dy >= -3) { continue; }
                if (direction === "down" && dy <= 3) { continue; }
                score = Math.abs(dy) + Math.abs(dx) * 2.4;
            }
            if (score < bestScore) {
                bestScore = score;
                best = items[i];
            }
        }
        if (best) {
            setFocus(best);
            return true;
        }
        if (direction === "up") { focusActiveServerSource(); }
        else if (direction === "down") {
            refreshButtons = byId("modal").getElementsByClassName("server-refresh-button");
            if (refreshButtons.length) { setFocus(refreshButtons[0]); }
        }
        return true;
    }

    function handleServerPickerNavigation(direction) {
        var modal = byId("modal");
        var current = state.focusElement;
        var tabs;
        var grids;
        var actions;
        var servers;
        if (!state.modalOpen || !modal || !hasClass(modal, "server-picker-modal") || !current) { return false; }
        tabs = modal.getElementsByClassName("server-source-tabs");
        grids = modal.getElementsByClassName("server-grid");
        actions = modal.getElementsByClassName("server-actions");
        if (tabs.length && isInsideElement(tabs[0], current)) {
            if (direction === "left" || direction === "right") {
                focusCollectionNeighbor(tabs[0].getElementsByClassName("server-source-button"), current, direction);
            } else if (direction === "down") {
                servers = grids.length ? grids[0].getElementsByClassName("modal-button") : [];
                if (servers.length) { setFocus(servers[0]); }
                else if (actions.length && actions[0].getElementsByClassName("focusable").length) {
                    setFocus(actions[0].getElementsByClassName("focusable")[0]);
                }
            }
            return true;
        }
        if (grids.length && isInsideElement(grids[0], current)) {
            return moveInsideServerGrid(grids[0], direction);
        }
        if (actions.length && isInsideElement(actions[0], current)) {
            if (direction === "left" || direction === "right") {
                focusCollectionNeighbor(actions[0].getElementsByClassName("focusable"), current, direction);
            } else if (direction === "up" && grids.length) {
                servers = grids[0].getElementsByClassName("modal-button");
                if (servers.length) { setFocus(servers[servers.length - 1]); }
            }
            return true;
        }
        return false;
    }

    function handleCatalogCategoryNavigation(direction) {
        var current = state.focusElement;
        var strip;
        var buttons;
        var i;
        var index = -1;
        if (state.modalOpen || !current || !hasClass(current, "category-button")) { return false; }
        strip = current.parentNode;
        if (!strip || !hasClass(strip, "category-strip")) { return false; }
        buttons = strip.getElementsByClassName("category-button");
        for (i = 0; i < buttons.length; i += 1) {
            if (buttons[i] === current) { index = i; break; }
        }
        if (index < 0) { return true; }
        if (direction === "right") {
            if (index < buttons.length - 1) { setFocus(buttons[index + 1]); }
            return true;
        }
        if (direction === "left") {
            if (index > 0) { setFocus(buttons[index - 1]); }
            else { focusSideMenuType(state.currentType); }
            return true;
        }
        if (direction === "down") {
            moveFromTopStripToContent();
            return true;
        }
        if (direction === "up") { return true; }
        return false;
    }

    function handleSeriesNavigation(direction) {
        var current = state.focusElement;
        var action;
        var options;
        var episodes;
        var index = -1;
        var i;
        if (state.modalOpen || !state.seriesOpen || !current) { return false; }
        action = current.getAttribute("data-action") || "";
        if (action === "season-menu-toggle") {
            if (direction === "left") { focusSideMenuType("series"); }
            else if (direction === "down") {
                episodes = byId("series-episodes") ? byId("series-episodes").getElementsByClassName("focusable") : [];
                if (episodes.length) { setFocus(episodes[0]); }
            }
            return true;
        }
        if (action === "season-option") {
            options = byId("series-season-menu") ? byId("series-season-menu").getElementsByClassName("series-season-option") : [];
            for (i = 0; i < options.length; i += 1) {
                if (options[i] === current) { index = i; break; }
            }
            if (direction === "up" && index > 0) { setFocus(options[index - 1]); }
            else if (direction === "down" && index >= 0 && index < options.length - 1) { setFocus(options[index + 1]); }
            return true;
        }
        if (action === "episode") {
            episodes = byId("series-episodes") ? byId("series-episodes").getElementsByClassName("focusable") : [];
            for (i = 0; i < episodes.length; i += 1) {
                if (episodes[i] === current) { index = i; break; }
            }
            if (direction === "up") {
                options = byId("content-root").getElementsByClassName("series-season-selector");
                if (options.length && hasClass(options[0], "focusable")) { setFocus(options[0]); }
            } else if (direction === "right" && index >= 0 && index < episodes.length - 1) {
                setFocus(episodes[index + 1]);
            } else if (direction === "left") {
                if (index > 0) { setFocus(episodes[index - 1]); }
                else { focusSideMenuType("series"); }
            }
            return true;
        }
        return false;
    }

    function favoriteHeaders() {
        var list = byId("saved-items");
        return list ? list.getElementsByClassName("favorite-group-header") : [];
    }

    function favoriteHeaderIndex(type) {
        var headers = favoriteHeaders();
        var i;
        for (i = 0; i < headers.length; i += 1) {
            if (headers[i].getAttribute("data-favorite-type") === type) { return i; }
        }
        return -1;
    }

    function focusFavoriteHeader(type) {
        var index = favoriteHeaderIndex(type);
        var headers = favoriteHeaders();
        if (index >= 0 && headers[index]) {
            setFocus(headers[index]);
            return true;
        }
        return false;
    }

    function favoriteCards(type) {
        var carousel = byId("favorite-carousel-" + type);
        return carousel ? carousel.getElementsByClassName("saved-favorite-card") : [];
    }

    function updateFavoriteCarouselArrow(element) {
        var type;
        var cards;
        var section;
        var arrows;
        var index = -1;
        var i;
        if (!element || state.currentType !== "favorites" || element._nexoSavedKind !== "favorites" || !element._nexoSaved) {
            return;
        }
        type = element._nexoSaved.type;
        cards = favoriteCards(type);
        section = byId("favorite-group-" + type);
        arrows = section ? section.getElementsByClassName("favorite-carousel-arrow") : [];
        for (i = 0; i < cards.length; i += 1) {
            if (cards[i] === element) { index = i; break; }
        }
        if (!arrows.length) { return; }
        if (cards.length > 5 && index >= 0 && index < cards.length - 1) {
            removeClass(arrows[0], "hidden");
        } else if (index === cards.length - 1 || cards.length <= 5) {
            addClass(arrows[0], "hidden");
        }
    }

    function focusSideMenuAction(action) {
        var buttons = byId("screen-main").getElementsByClassName("menu-item");
        var i;
        for (i = 0; i < buttons.length; i += 1) {
            if (buttons[i].getAttribute("data-action") === action) {
                setFocus(buttons[i]);
                return true;
            }
        }
        return false;
    }

    function handleFavoritesNavigation(direction) {
        var current = state.focusElement;
        var headers;
        var headerIndex;
        var type;
        var cards;
        var cardIndex = -1;
        var i;
        if (state.modalOpen || state.currentType !== "favorites" || !current) { return false; }
        headers = favoriteHeaders();
        if (hasClass(current, "favorite-group-header")) {
            type = current.getAttribute("data-favorite-type") || "";
            headerIndex = favoriteHeaderIndex(type);
            if (direction === "left") {
                focusSideMenuAction("favorites");
            } else if (direction === "down") {
                cards = state.favoriteOpenType === type ? favoriteCards(type) : [];
                if (cards.length) { setFocus(cards[0]); }
                else if (headerIndex >= 0 && headerIndex < headers.length - 1) { setFocus(headers[headerIndex + 1]); }
            } else if (direction === "up" && headerIndex > 0) {
                setFocus(headers[headerIndex - 1]);
            }
            return true;
        }
        if (current._nexoSavedKind === "favorites" && current._nexoSaved) {
            type = current._nexoSaved.type;
            cards = favoriteCards(type);
            for (i = 0; i < cards.length; i += 1) {
                if (cards[i] === current) { cardIndex = i; break; }
            }
            if (direction === "left" && cardIndex > 0) {
                setFocus(cards[cardIndex - 1]);
            } else if (direction === "right" && cardIndex >= 0 && cardIndex < cards.length - 1) {
                setFocus(cards[cardIndex + 1]);
            } else if (direction === "up") {
                focusFavoriteHeader(type);
            } else if (direction === "down") {
                headerIndex = favoriteHeaderIndex(type);
                if (headerIndex >= 0 && headerIndex < headers.length - 1) { setFocus(headers[headerIndex + 1]); }
            }
            return true;
        }
        return false;
    }

    function handleMovieDetailNavigation(direction) {
        var current = state.focusElement;
        if (!state.detailOpen || !current || current.getAttribute("data-action") !== "movie-play") {
            return false;
        }
        if (direction === "left") { focusSideMenuType("movie"); }
        return true;
    }

    function handleStructuredNavigation(direction) {
        return handleMovieDetailNavigation(direction) || handleSeriesNavigation(direction) || handleFavoritesNavigation(direction) || handleServerPickerNavigation(direction) || handleParentalSettingsNavigation(direction) ||
            handleCatalogCategoryNavigation(direction);
    }

    function moveFromTopStripToContent() {
        var list;
        var items;
        if (state.modalOpen || !hasClass(state.focusElement, "category-button")) {
            return false;
        }
        list = state.seriesOpen ? byId("series-episodes") : byId("catalog-items");
        items = list ? list.getElementsByClassName("focusable") : [];
        if (items.length) {
            setFocus(items[0]);
            return true;
        }
        return false;
    }

    function focusSideMenuType(type) {
        var buttons = byId("screen-main").getElementsByClassName("menu-item");
        var i;
        for (i = 0; i < buttons.length; i += 1) {
            if (buttons[i].getAttribute("data-action") === "catalog" && buttons[i].getAttribute("data-type") === type) {
                setFocus(buttons[i]);
                return true;
            }
        }
        return false;
    }

    function moveLiveChannelToSideMenu() {
        var list = byId("catalog-items");
        if (state.currentType === "live" && !state.seriesOpen && list && state.focusElement &&
                isInsideElement(list, state.focusElement) && state.focusElement._nexoType === "live") {
            return focusSideMenuType("live");
        }
        return false;
    }

    function isInsideElement(root, element) {
        var node = element;
        while (node && node !== document.body) {
            if (node === root) { return true; }
            node = node.parentNode;
        }
        return false;
    }

    function shouldLockCatalogDown() {
        var list = byId("catalog-items");
        var items;
        var currentRect;
        var rect;
        var i;
        if ((state.currentType !== "movie" && state.currentType !== "series") || state.seriesOpen ||
                !list || !state.focusElement || !isInsideElement(list, state.focusElement)) {
            return false;
        }
        items = list.getElementsByClassName("focusable");
        currentRect = state.focusElement.getBoundingClientRect();
        for (i = 0; i < items.length; i += 1) {
            if (items[i] !== state.focusElement) {
                rect = items[i].getBoundingClientRect();
                if (rect.top > currentRect.top + 8) { return false; }
            }
        }
        return true;
    }

    function shouldLockSideMenuDown() {
        return !!(state.focusElement && hasClass(state.focusElement, "menu-item") &&
            state.focusElement.getAttribute("data-action") === "logout");
    }

    function updateLoginUi() {
        byId("value-code").innerHTML = state.login.code || "----";
        byId("value-username").innerHTML = state.login.username || "Digite o usu\u00E1rio";
        byId("value-password").innerHTML = state.login.password ? new Array(state.login.password.length + 1).join("\u2022") : "Digite a senha";
    }

    function appendDigit(digit) {
        var field = state.loginField;
        var limits = { code: 4, username: 32, password: 32 };
        if (state.modalOpen && state.parentalPinMode) {
            appendParentalDigit(digit);
            return true;
        }
        if (state.modalOpen && state.loginKeyboardField) {
            appendLoginKeyboardCharacter(digit);
            return true;
        }
        if (state.screen !== "login" || !limits[field]) {
            return false;
        }
        if (state.login[field].length < limits[field]) {
            state.login[field] += digit;
            updateLoginUi();
            if (field === "code" && state.login.code.length === 4) {
                setFocus(byId("login-user"));
            }
        }
        return true;
    }

    function eraseDigit(clearAll) {
        var field = state.loginField;
        if (state.modalOpen && state.parentalPinMode) {
            state.parentalPinValue = clearAll ? "" : state.parentalPinValue.substring(0, Math.max(0, state.parentalPinValue.length - 1));
            updateParentalPinDisplay();
            return;
        }
        if (state.modalOpen && state.loginKeyboardField) {
            state.loginKeyboardValue = clearAll ? "" : state.loginKeyboardValue.substring(0, Math.max(0, state.loginKeyboardValue.length - 1));
            updateLoginKeyboardDisplay();
            return;
        }
        if (state.screen !== "login" || typeof state.login[field] === "undefined") {
            return;
        }
        state.login[field] = clearAll ? "" : state.login[field].substring(0, state.login[field].length - 1);
        updateLoginUi();
    }

    function setLoginStatus(message, error) {
        var status = byId("login-status");
        status.innerHTML = message || "";
        status.style.color = error ? "#ff9a9a" : "#8fc6c2";
    }

    function showLoading(message) {
        var splashStatus = byId("splash-status");
        if (state.screen === "splash" && splashStatus) {
            splashStatus.innerHTML = message || "Carregando...";
            addClass(byId("global-loading"), "hidden");
            return;
        }
        byId("global-loading-text").innerHTML = message || "Carregando...";
        removeClass(byId("global-loading"), "hidden");
    }

    function updateLoadingMessage(message) {
        var splashStatus = byId("splash-status");
        if (state.screen === "splash" && splashStatus) {
            splashStatus.innerHTML = message || "Carregando...";
        } else {
            byId("global-loading-text").innerHTML = message || "Carregando...";
        }
    }

    function hideLoading() {
        addClass(byId("global-loading"), "hidden");
    }

    function showBackgroundStatus(message) {
        var status = byId("background-status");
        var text = byId("background-status-text");
        if (!status || !text) { return; }
        text.innerHTML = message || "";
        removeClass(status, "hidden");
    }

    function hideBackgroundStatus() {
        var status = byId("background-status");
        if (status) { addClass(status, "hidden"); }
    }

    function toast(message) {
        var element = byId("toast");
        if (state.toastTimer) { clearTimeout(state.toastTimer); }
        element.innerHTML = message;
        removeClass(element, "hidden");
        state.toastTimer = setTimeout(function () {
            addClass(element, "hidden");
        }, 3500);
    }

    function showVolumeOsd(direction) {
        var value = Platform.getVolume();
        var display = direction === "mute" ? "Mudo" : (direction === "up" ? "+" : "\u2212");
        if (value !== null && typeof value !== "undefined" && value !== "") {
            display = String(value);
        }
        byId("volume-value").innerHTML = display;
        removeClass(byId("volume-osd"), "hidden");
        if (state.volumeTimer) { clearTimeout(state.volumeTimer); }
        state.volumeTimer = setTimeout(function () {
            addClass(byId("volume-osd"), "hidden");
        }, 1700);
    }

    function saveSession() {
        var saved;
        try {
            saved = {
                code: state.login.code,
                username: state.login.username,
                password: state.login.password,
                serverName: state.session.server.serverName,
                serverHost: state.session.server.serverHost,
                sourceName: state.session.server.sourceName
            };
            localStorage.setItem("nexo_legacy_session", JSON.stringify(saved));
            state.savedSessionInfo = saved;
        } catch (ignore) {}
    }

    function loadSavedSession() {
        var saved;
        try {
            saved = JSON.parse(localStorage.getItem("nexo_legacy_session") || "null");
        } catch (ignore) {
            saved = null;
        }
        if (saved && saved.code && saved.username && saved.password) {
            state.savedSessionInfo = saved;
            state.login.code = saved.code;
            state.login.username = saved.username;
            state.login.password = saved.password;
            updateLoginUi();
            return saved;
        }
        return null;
    }

    function clearSavedSession() {
        try { localStorage.removeItem("nexo_legacy_session"); } catch (ignore) {}
        state.savedSessionInfo = null;
    }

    function prioritizeSavedServer(servers) {
        var saved = state.savedSessionInfo;
        var result = [];
        var i;
        if (!saved || String(saved.code) !== String(state.login.code) ||
                String(saved.username) !== String(state.login.username) || !saved.serverHost) {
            return servers;
        }
        for (i = 0; i < servers.length; i += 1) {
            if (String(servers[i].serverHost) === String(saved.serverHost)) {
                result.push(servers[i]);
            }
        }
        for (i = 0; i < servers.length; i += 1) {
            if (String(servers[i].serverHost) !== String(saved.serverHost)) {
                result.push(servers[i]);
            }
        }
        return result.length ? result : servers;
    }

    function loadStoredList(key) {
        var list;
        try { list = JSON.parse(localStorage.getItem(key) || "[]"); } catch (ignore) { list = []; }
        return list && typeof list.length === "number" ? list : [];
    }

    function saveStoredList(key, list) {
        try {
            localStorage.setItem(key, JSON.stringify(list || []));
            return true;
        } catch (ignore) {}
        return false;
    }

    function parentalStorageKey() {
        return "nexo_legacy_parental_" + String(state.login.code || "") + "_" + String(state.login.username || "");
    }

    function loadParentalSettings() {
        var settings;
        try { settings = JSON.parse(localStorage.getItem(parentalStorageKey()) || "null"); } catch (ignore) { settings = null; }
        if (!settings || typeof settings !== "object") { settings = {}; }
        if (!/^\d{4}$/.test(String(settings.pin || ""))) { settings.pin = "0000"; }
        if (!settings.blockedCategories || typeof settings.blockedCategories.length !== "number") {
            settings.blockedCategories = [];
        }
        state.parentalSettings = settings;
        return settings;
    }

    function saveParentalSettings() {
        if (!state.parentalSettings) { loadParentalSettings(); }
        try { localStorage.setItem(parentalStorageKey(), JSON.stringify(state.parentalSettings)); } catch (ignore) {}
    }

    function parentalCategoryKey(type, categoryId) {
        return currentServerHost() + "|" + String(type || "") + "|" + String(categoryId || "");
    }

    function isAdultCategoryName(name) {
        var value = " " + normalizeSearchText(name).replace(/[^a-z0-9+]+/g, " ") + " ";
        return value.indexOf(" adulto ") >= 0 || value.indexOf(" adultos ") >= 0 ||
            value.indexOf(" adult ") >= 0 || value.indexOf(" xxx ") >= 0 ||
            value.indexOf(" +18 ") >= 0 || value.indexOf(" 18+ ") >= 0 ||
            value.indexOf(" erotico ") >= 0 || value.indexOf(" erotica ") >= 0 ||
            value.indexOf(" erotic ") >= 0 || value.indexOf(" pornografia ") >= 0 ||
            value.indexOf(" porno ") >= 0 || value.indexOf(" porn ") >= 0 ||
            value.indexOf(" playboy ") >= 0 || value.indexOf(" sexo ") >= 0;
    }

    function blockedCategoryIndex(type, categoryId) {
        var settings = state.parentalSettings || loadParentalSettings();
        var key = parentalCategoryKey(type, categoryId);
        var i;
        for (i = 0; i < settings.blockedCategories.length; i += 1) {
            if (settings.blockedCategories[i].key === key) { return i; }
        }
        return -1;
    }

    function isCategoryBlocked(type, categoryId, categoryName) {
        if (!categoryId || String(categoryId) === "__latest__") { return false; }
        return isAdultCategoryName(categoryName) || blockedCategoryIndex(type, categoryId) >= 0;
    }

    function toggleBlockedCategory(category) {
        var settings = state.parentalSettings || loadParentalSettings();
        var index;
        if (!category || !category.id) { return; }
        if (isAdultCategoryName(category.name)) {
            toast("Conte\u00FAdo adulto permanece sempre protegido");
            return;
        }
        index = blockedCategoryIndex(category.type, category.id);
        if (index >= 0) {
            settings.blockedCategories.splice(index, 1);
        } else {
            settings.blockedCategories.push({
                key: parentalCategoryKey(category.type, category.id),
                serverHost: currentServerHost(),
                type: category.type,
                categoryId: String(category.id),
                categoryName: category.name
            });
        }
        saveParentalSettings();
    }

    function rememberCategoryNames(type, categories) {
        var names = {};
        var i;
        categories = categories || [];
        for (i = 0; i < categories.length; i += 1) {
            names[String(categories[i].category_id || "")] = categories[i].category_name || "";
        }
        state.parentalCategoryNames[type] = names;
    }

    function itemCategoryDetails(type, item) {
        var id = item ? String(item.category_id || "") : "";
        var names = state.parentalCategoryNames[type] || {};
        return { type: type, id: id, name: (item && item.category_name) || names[id] || "" };
    }

    function authorizeCategory(category, success) {
        if (!category || !isCategoryBlocked(category.type, category.id, category.name)) {
            success();
            return;
        }
        openParentalPin("Digite o PIN para acessar " + (category.name || "este conte\u00FAdo"), success);
    }

    function currentServerHost() {
        return state.session && state.session.server ? String(state.session.server.serverHost || "") : "";
    }

    function resetLatestCatalogCache(serverHost) {
        if (state.latestPrefetchTimer) { clearTimeout(state.latestPrefetchTimer); }
        if (state.catalogStatusTimer) { clearTimeout(state.catalogStatusTimer); }
        state.latestPrefetchTimer = null;
        state.catalogStatusTimer = null;
        hideBackgroundStatus();
        state.latestPrefetchToken += 1;
        state.latestCatalogCache = { serverHost: String(serverHost || currentServerHost()), live: null, movie: null, series: null };
        state.latestCatalogLoading = { live: false, movie: false, series: false };
        state.latestCatalogWaiters = { live: [], movie: [], series: [] };
        state.latestCatalogImages = { movie: [], series: [] };
        state.catalogCategories = { live: null, movie: null, series: null };
        state.catalogCategoryLoading = { live: false, movie: false, series: false };
        state.catalogCategoryWaiters = { live: [], movie: [], series: [] };
        state.catalogLoadStatus = { live: "pending", movie: "pending", series: "pending" };
        state.catalogLoadedDate = "";
        state.catalogRestored = false;
        state.catalogBlocking = false;
    }

    function ensureLatestCatalogCache() {
        var host = currentServerHost();
        if (!state.latestCatalogCache || state.latestCatalogCache.serverHost !== host) {
            resetLatestCatalogCache(host);
        }
    }

    function catalogDateKey() {
        var now = new Date();
        return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate();
    }

    function catalogPersistentKey() {
        var host = String(currentServerHost() || "").replace(/\/+$/, "").toLowerCase();
        var username = state.session ? String(state.session.username || "") : "";
        return host + "|" + username;
    }

    function loadCatalogUpdateDays() {
        var value = 1;
        try { value = parseInt(window.localStorage.getItem("nexo_catalog_update_days"), 10) || 1; } catch (ignoreCatalogDaysLoad) {}
        state.catalogUpdateDays = Math.max(1, Math.min(7, value));
    }

    function saveCatalogUpdateDays(value) {
        state.catalogUpdateDays = Math.max(1, Math.min(7, parseInt(value, 10) || 1));
        try { window.localStorage.setItem("nexo_catalog_update_days", String(state.catalogUpdateDays)); } catch (ignoreCatalogDaysSave) {}
    }

    function catalogDayNumber(value) {
        var parts = String(value || "").split("-");
        var date;
        if (parts.length !== 3) { return 0; }
        date = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        return Math.floor(date.getTime() / 86400000);
    }

    function catalogCacheIsDue(savedDate) {
        var savedDay = catalogDayNumber(savedDate);
        var currentDay = catalogDayNumber(catalogDateKey());
        if (!savedDay || !currentDay) { return true; }
        return currentDay - savedDay >= state.catalogUpdateDays;
    }

    function clearPersistentCatalogCache() {
        Platform.deletePersistentText("catalog_meta.json");
        Platform.deletePersistentText("catalog_live.json");
        Platform.deletePersistentText("catalog_movie.json");
        Platform.deletePersistentText("catalog_series.json");
    }

    function savePersistentCatalogCache() {
        var types = ["live", "movie", "series"];
        var key = catalogPersistentKey();
        var date = catalogDateKey();
        var payload;
        var ok = true;
        var i;
        Platform.deletePersistentText("catalog_meta.json");
        try {
            for (i = 0; i < types.length; i += 1) {
                payload = JSON.stringify({
                    version: 1,
                    key: key,
                    savedDate: date,
                    categories: state.catalogCategories[types[i]] || [],
                    items: state.latestCatalogCache[types[i]] || []
                });
                if (!Platform.writePersistentText("catalog_" + types[i] + ".json", payload)) { ok = false; break; }
            }
            if (ok) {
                ok = Platform.writePersistentText("catalog_meta.json", JSON.stringify({ version: 1, key: key, savedDate: date }));
            }
        } catch (ignoreCatalogSave) {
            ok = false;
        }
        if (!ok) { Platform.deletePersistentText("catalog_meta.json"); }
        return ok;
    }

    function restorePersistentCatalogCache() {
        var types = ["live", "movie", "series"];
        var meta;
        var payloads = {};
        var text;
        var i;
        try {
            text = Platform.readPersistentText("catalog_meta.json");
            if (!text) { return false; }
            meta = JSON.parse(text);
            if (!meta || meta.version !== 1 || meta.key !== catalogPersistentKey() || catalogCacheIsDue(meta.savedDate)) { return false; }
            for (i = 0; i < types.length; i += 1) {
                text = Platform.readPersistentText("catalog_" + types[i] + ".json");
                if (!text) { return false; }
                payloads[types[i]] = JSON.parse(text);
                if (!payloads[types[i]] || payloads[types[i]].version !== 1 || payloads[types[i]].key !== meta.key ||
                        !(payloads[types[i]].categories instanceof Array) || !(payloads[types[i]].items instanceof Array)) {
                    return false;
                }
            }
        } catch (ignoreCatalogRestore) {
            return false;
        }
        for (i = 0; i < types.length; i += 1) {
            state.catalogCategories[types[i]] = payloads[types[i]].categories;
            state.latestCatalogCache[types[i]] = payloads[types[i]].items;
            state.catalogLoadStatus[types[i]] = "ready";
            rememberCategoryNames(types[i], payloads[types[i]].categories);
            state.parentalCategories[types[i]] = payloads[types[i]].categories.slice(0);
            if (types[i] !== "live") { preloadLatestCatalogImages(types[i], payloads[types[i]].items); }
        }
        state.catalogLoadedDate = meta.savedDate;
        state.catalogRestored = true;
        return true;
    }

    function catalogStatusLabel(type) {
        return type === "live" ? "TV ao vivo" : (type === "movie" ? "Filmes" : "S\u00E9ries");
    }

    function renderCatalogLoadStatus(finalMessage) {
        var types = ["live", "movie", "series"];
        var html = "<strong>" + (finalMessage || "Carregando listas") + "</strong>";
        var value;
        var symbol;
        var css;
        var i;
        for (i = 0; i < types.length; i += 1) {
            value = state.catalogLoadStatus[types[i]] || "pending";
            symbol = value === "ready" ? "&#10003;" : (value === "loading" ? "&#8230;" : (value === "error" ? "!" : "&#8211;"));
            css = value === "ready" ? " ready" : (value === "loading" ? " loading" : (value === "error" ? " error" : ""));
            html += "<span class='catalog-status-line" + css + "'><b>" + symbol + "</b>" + catalogStatusLabel(types[i]) + "</span>";
        }
        hideLoading();
        showBackgroundStatus(html);
    }

    function allCatalogsReady() {
        return state.latestCatalogCache.live !== null && state.latestCatalogCache.movie !== null && state.latestCatalogCache.series !== null;
    }

    function finishCatalogLoadNotice(onComplete) {
        var delay;
        var saved = true;
        if (allCatalogsReady()) {
            if (!state.catalogRestored) {
                state.catalogLoadedDate = catalogDateKey();
                saved = savePersistentCatalogCache();
            }
            renderCatalogLoadStatus(state.catalogRestored ? "Listas carregadas" : (saved ? "Listas atualizadas" : "Listas atualizadas (sem cache)"));
            delay = 1300;
        } else {
            renderCatalogLoadStatus("Algumas listas falharam");
            delay = 2600;
        }
        if (typeof onComplete === "function") {
            try { onComplete(); } catch (ignoreCatalogComplete) {}
        }
        if (state.catalogStatusTimer) { clearTimeout(state.catalogStatusTimer); }
        state.catalogStatusTimer = setTimeout(function () {
            state.catalogBlocking = false;
            hideBackgroundStatus();
            state.catalogStatusTimer = null;
        }, delay);
    }

    function requestCatalogCategories(type, callback) {
        var host;
        var token;
        ensureLatestCatalogCache();
        host = currentServerHost();
        token = state.latestPrefetchToken;
        if (state.catalogCategories[type] !== null) {
            if (callback) { callback(null, state.catalogCategories[type], true); }
            return;
        }
        if (callback) { state.catalogCategoryWaiters[type].push(callback); }
        if (state.catalogCategoryLoading[type]) { return; }
        state.catalogCategoryLoading[type] = true;
        NexoApi.getCategories(state.session, type, function (error, categories) {
            var waiters;
            var result = error ? [] : (categories || []);
            var i;
            if (token !== state.latestPrefetchToken || host !== currentServerHost()) { return; }
            state.catalogCategoryLoading[type] = false;
            if (!error) {
                state.catalogCategories[type] = result;
                rememberCategoryNames(type, result);
                state.parentalCategories[type] = result.slice(0);
            }
            waiters = state.catalogCategoryWaiters[type].slice(0);
            state.catalogCategoryWaiters[type] = [];
            for (i = 0; i < waiters.length; i += 1) {
                waiters[i](error, result, true);
            }
        });
    }

    function compactCatalogItems(items) {
        var result = [];
        var i;
        items = items || [];
        for (i = 0; i < items.length; i += 1) {
            result.push(compactItem(items[i]));
        }
        return result;
    }

    function requestLatestCatalog(type, callback) {
        var host;
        var token;
        ensureLatestCatalogCache();
        host = currentServerHost();
        token = state.latestPrefetchToken;
        if (state.latestCatalogCache[type] !== null) {
            if (callback) { callback(null, state.latestCatalogCache[type], true); }
            return;
        }
        if (callback) { state.latestCatalogWaiters[type].push(callback); }
        if (state.latestCatalogLoading[type]) { return; }
        state.latestCatalogLoading[type] = true;
        state.catalogLoadStatus[type] = "loading";
        if (state.catalogBlocking) { renderCatalogLoadStatus(); }
        NexoApi.getAllItems(state.session, type, function (error, items) {
            var waiters;
            var sorted = [];
            var i;
            if (token !== state.latestPrefetchToken || host !== currentServerHost()) { return; }
            state.latestCatalogLoading[type] = false;
            if (!error) {
                sorted = compactCatalogItems(items || []);
                if (type !== "live") { sorted = NexoApi.sortNewest(sorted); }
                state.latestCatalogCache[type] = sorted;
                state.catalogLoadStatus[type] = "ready";
                if (type !== "live") { preloadLatestCatalogImages(type, sorted); }
            } else {
                state.catalogLoadStatus[type] = "error";
            }
            if (state.catalogBlocking) { renderCatalogLoadStatus(); }
            waiters = state.latestCatalogWaiters[type].slice(0);
            state.latestCatalogWaiters[type] = [];
            for (i = 0; i < waiters.length; i += 1) {
                waiters[i](error, sorted, true);
            }
        });
    }

    function preloadLatestCatalogImages(type, items) {
        var images = [];
        var limit = Math.min(20, items ? items.length : 0);
        var image;
        var i;
        for (i = 0; i < limit; i += 1) {
            try {
                image = new Image();
                image.src = imageFor(items[i], type);
                images.push(image);
            } catch (ignoreImagePreload) {}
        }
        state.latestCatalogImages[type] = images;
    }

    function scheduleLatestCatalogPrefetch(forceRefresh, onComplete) {
        var token;
        var types = ["live", "movie", "series"];
        if (typeof forceRefresh === "function") {
            onComplete = forceRefresh;
            forceRefresh = false;
        }
        forceRefresh = !!forceRefresh;
        ensureLatestCatalogCache();
        token = state.latestPrefetchToken;
        if (state.latestPrefetchTimer) { clearTimeout(state.latestPrefetchTimer); }
        state.catalogBlocking = true;
        renderCatalogLoadStatus();
        state.latestPrefetchTimer = setTimeout(function () {
            var loadIndex = 0;
            state.latestPrefetchTimer = null;
            if (token !== state.latestPrefetchToken || !state.session) { return; }
            if (state.playerOpen) {
                state.latestPrefetchTimer = setTimeout(function () {
                    scheduleLatestCatalogPrefetch(forceRefresh, onComplete);
                }, 4000);
                return;
            }
            if (!forceRefresh && restorePersistentCatalogCache()) {
                renderCatalogLoadStatus();
                finishCatalogLoadNotice(onComplete);
                return;
            }
            function next() {
                var type;
                if (token !== state.latestPrefetchToken || !state.session) { return; }
                if (state.playerOpen) {
                    state.latestPrefetchTimer = setTimeout(next, 4000);
                    return;
                }
                if (loadIndex >= types.length) {
                    finishCatalogLoadNotice(onComplete);
                    return;
                }
                type = types[loadIndex];
                loadIndex += 1;
                requestCatalogCategories(type, function () {
                    if (token !== state.latestPrefetchToken || !state.session) { return; }
                    requestLatestCatalog(type, function () {
                        if (token !== state.latestPrefetchToken || !state.session) { return; }
                        state.latestPrefetchTimer = setTimeout(next, 350);
                    });
                });
            }
            next();
        }, 100);
    }

    function maybeRefreshCatalogDaily() {
        var returnType;
        var returnCategory;
        var returnSeries;
        var wasSeriesOpen;
        if (!state.session || !state.catalogLoadedDate || !catalogCacheIsDue(state.catalogLoadedDate) || state.playerOpen || state.catalogBlocking) { return; }
        returnType = state.currentType || "live";
        returnCategory = state.currentCategory || "";
        returnSeries = state.seriesItem;
        wasSeriesOpen = state.seriesOpen;
        resetLatestCatalogCache(currentServerHost());
        scheduleLatestCatalogPrefetch(true, function () {
            if (wasSeriesOpen && returnSeries) { openSeries(returnSeries); }
            else if (returnType === "favorites" || returnType === "recent") { openSavedList(returnType); }
            else if (returnType === "live" || returnType === "movie" || returnType === "series") { openCatalog(returnType, returnCategory); }
            else { openCatalog("live"); }
        });
    }

    function compactItem(item) {
        return {
            id: item.id,
            stream_id: item.stream_id,
            series_id: item.series_id,
            name: item.name,
            title: item.title,
            series_name: item.series_name,
            stream_icon: item.stream_icon,
            cover: item.cover,
            container_extension: item.container_extension,
            direct_source: item.direct_source,
            category_id: item.category_id,
            category_name: item.category_name,
            added: item.added,
            last_modified: item.last_modified,
            plot: item.plot,
            description: item.description,
            rating: item.rating,
            rating_5based: item.rating_5based,
            genre: item.genre,
            releaseDate: item.releaseDate,
            releasedate: item.releasedate,
            year: item.year,
            director: item.director,
            cast: item.cast,
            duration: item.duration,
            tmdb: item.tmdb,
            tmdb_id: item.tmdb_id,
            imdb: item.imdb,
            imdb_id: item.imdb_id,
            episode_num: item.episode_num,
            season: item.season
        };
    }

    function contentId(type, item) {
        return String(item.series_id || item.stream_id || item.id || safeName(item, "item"));
    }

    function normalizeServerName(value) {
        return String(value || "").replace(/\s*\([^\)]*\)\s*$/, "").replace(/^\s+|\s+$/g, "").replace(/\s+/g, " ").toLowerCase();
    }

    function normalizeServerHost(value) {
        return String(value || "").replace(/\/+$/, "").toLowerCase();
    }

    function currentServerName() {
        return state.session && state.session.server ? String(state.session.server.serverName || "") : "";
    }

    function serverNameForHost(host) {
        var sources = state.codeEntry && state.codeEntry.fontes ? state.codeEntry.fontes : [];
        var wanted = normalizeServerHost(host);
        var servers;
        var i;
        var j;
        if (!wanted) { return ""; }
        for (i = 0; i < sources.length; i += 1) {
            servers = sources[i].servidores || [];
            for (j = 0; j < servers.length; j += 1) {
                if (normalizeServerHost(servers[j].serverHost) === wanted) {
                    return String(servers[j].serverName || "");
                }
            }
        }
        return "";
    }

    function serverIdentity(name, host) {
        var normalizedName = normalizeServerName(name);
        return normalizedName ? "name:" + normalizedName : "host:" + normalizeServerHost(host);
    }

    function currentServerIdentity() {
        return serverIdentity(currentServerName(), currentServerHost());
    }

    function savedEntryServerIdentity(entry) {
        var mappedName;
        if (entry && entry.serverName && normalizeServerName(entry.serverName) !== "servidor") {
            return serverIdentity(entry.serverName, entry.serverHost);
        }
        if (entry && entry.serverKey) { return String(entry.serverKey); }
        mappedName = serverNameForHost(entry ? entry.serverHost : "");
        if (mappedName) { return serverIdentity(mappedName, entry ? entry.serverHost : ""); }
        if (!mappedName && entry && normalizeServerHost(entry.serverHost) === normalizeServerHost(currentServerHost())) {
            mappedName = currentServerName();
        }
        return serverIdentity(mappedName, entry ? entry.serverHost : "");
    }

    function savedEntryServerName(entry) {
        var sources = state.codeEntry && state.codeEntry.fontes ? state.codeEntry.fontes : [];
        var identity = savedEntryServerIdentity(entry);
        var servers;
        var i;
        var j;
        for (i = 0; i < sources.length; i += 1) {
            servers = sources[i].servidores || [];
            for (j = 0; j < servers.length; j += 1) {
                if (serverIdentity(servers[j].serverName, servers[j].serverHost) === identity) {
                    return String(servers[j].serverName || "Servidor");
                }
            }
        }
        if (entry && entry.serverName && normalizeServerName(entry.serverName) !== "servidor") {
            return String(entry.serverName).replace(/\s*\([^\)]*\)\s*$/, "");
        }
        if (identity.indexOf("name:") === 0 && identity.substring(5)) {
            return identity.substring(5).replace(/(^|\s)([a-z])/g, function (all, space, letter) {
                return space + letter.toUpperCase();
            });
        }
        return String(serverNameForHost(entry ? entry.serverHost : "") || "Servidor");
    }

    function findServerForSavedEntry(entry) {
        var sources = state.codeEntry && state.codeEntry.fontes ? state.codeEntry.fontes : [];
        var targetIdentity = savedEntryServerIdentity(entry);
        var targetHost = normalizeServerHost(entry ? entry.serverHost : "");
        var identityFallback = null;
        var hostFallback = null;
        var servers;
        var candidate;
        var i;
        var j;
        for (i = 0; i < sources.length; i += 1) {
            servers = sources[i].servidores || [];
            for (j = 0; j < servers.length; j += 1) {
                candidate = {
                    sourceName: sources[i].nomeFonte,
                    sourceIndex: i,
                    serverIndex: j,
                    serverName: servers[j].serverName,
                    serverHost: servers[j].serverHost
                };
                if (!identityFallback && serverIdentity(candidate.serverName, candidate.serverHost) === targetIdentity) {
                    identityFallback = candidate;
                }
                if (!hostFallback && targetHost && normalizeServerHost(candidate.serverHost) === targetHost) {
                    hostFallback = candidate;
                }
            }
        }
        return identityFallback || hostFallback;
    }

    function groupSavedEntriesByServer(entries) {
        var order = [];
        var groups = {};
        var result = [];
        var identity;
        var i;
        var j;
        entries = entries || [];
        for (i = 0; i < entries.length; i += 1) {
            identity = savedEntryServerIdentity(entries[i]);
            if (!groups[identity]) {
                groups[identity] = [];
                order.push(identity);
            }
            groups[identity].push(entries[i]);
        }
        for (i = 0; i < order.length; i += 1) {
            for (j = 0; j < groups[order[i]].length; j += 1) {
                result.push(groups[order[i]][j]);
            }
        }
        return result;
    }

    function loadSavedList(storageKey) {
        var entries = loadStoredList(storageKey);
        var result = [];
        var seen = {};
        var changed = false;
        var identity;
        var key;
        var i;
        for (i = 0; i < entries.length; i += 1) {
            if (!entries[i] || !entries[i].item || !entries[i].type) { changed = true; continue; }
            identity = savedEntryServerIdentity(entries[i]);
            key = identity + "|" + entries[i].type + "|" + contentId(entries[i].type, entries[i].item);
            if (seen[key]) { changed = true; continue; }
            seen[key] = true;
            if (entries[i].serverKey !== identity || entries[i].key !== key) { changed = true; }
            entries[i].serverKey = identity;
            entries[i].key = key;
            result.push(entries[i]);
        }
        if (changed) { saveStoredList(storageKey, result); }
        return result;
    }

    function favoriteKey(type, item) {
        return currentServerIdentity() + "|" + type + "|" + contentId(type, item);
    }

    function favoriteKeyForSavedEntry(type, item, sourceEntry) {
        return (sourceEntry ? savedEntryServerIdentity(sourceEntry) : currentServerIdentity()) +
            "|" + type + "|" + contentId(type, item);
    }

    function rebuildFavoriteLookup() {
        var favorites = loadSavedList("nexo_legacy_favorites");
        var lookup = {};
        var i;
        for (i = 0; i < favorites.length; i += 1) {
            lookup[favorites[i].key] = true;
        }
        state.favoriteLookup = lookup;
    }

    function isFavoriteItem(type, item, sourceEntry) {
        if (!state.favoriteLookup) { rebuildFavoriteLookup(); }
        return !!state.favoriteLookup[favoriteKeyForSavedEntry(type, item, sourceEntry)];
    }

    function updatePosterFavoriteBadge(card, favorite) {
        var badges;
        var badge;
        if (!card || !hasClass(card, "poster-card")) { return; }
        badges = card.getElementsByClassName("favorite-badge");
        if (badges.length && !favorite) {
            card.removeChild(badges[0]);
        } else if (!badges.length && favorite) {
            badge = document.createElement("span");
            badge.className = "favorite-badge";
            badge.innerHTML = "&#9733;";
            card.appendChild(badge);
        }
    }

    function toggleFavoriteItem(type, item, sourceEntry) {
        var favorites = loadSavedList("nexo_legacy_favorites");
        var key = favoriteKeyForSavedEntry(type, item, sourceEntry);
        var found = -1;
        var i;
        for (i = 0; i < favorites.length; i += 1) {
            if (favorites[i].key === key) { found = i; break; }
        }
        if (found >= 0) {
            favorites.splice(found, 1);
            saveStoredList("nexo_legacy_favorites", favorites);
            state.favoriteLookup = null;
            toast("Removido dos favoritos");
            return false;
        } else {
            favorites.unshift({
                key: key,
                serverHost: sourceEntry ? sourceEntry.serverHost : currentServerHost(),
                serverName: sourceEntry ? savedEntryServerName(sourceEntry) : currentServerName(),
                serverKey: sourceEntry ? savedEntryServerIdentity(sourceEntry) : currentServerIdentity(),
                type: type,
                item: compactItem(item),
                savedAt: new Date().getTime()
            });
            if (favorites.length > 60) { favorites.length = 60; }
            saveStoredList("nexo_legacy_favorites", favorites);
            state.favoriteLookup = null;
            toast("Adicionado aos favoritos");
            return true;
        }
    }

    function addRecentItem(type, item, metadata) {
        var recent = loadSavedList("nexo_legacy_recent");
        var key = currentServerIdentity() + "|" + type + "|" + contentId(type, item);
        var result = [];
        var entry;
        var i;
        metadata = metadata || {};
        entry = {
            key: key,
            serverHost: currentServerHost(),
            serverName: currentServerName(),
            serverKey: currentServerIdentity(),
            type: type,
            item: compactItem(item),
            watchedAt: new Date().getTime(),
            currentTime: Math.max(0, Number(metadata.currentTime) || 0),
            duration: Math.max(0, Number(metadata.duration) || 0),
            seasonKey: metadata.seasonKey === null || typeof metadata.seasonKey === "undefined" ? "" : String(metadata.seasonKey),
            episodeIndex: typeof metadata.episodeIndex === "number" ? metadata.episodeIndex : -1,
            episodeId: metadata.episodeId || "",
            episodeTitle: metadata.episodeTitle || ""
        };
        result.push(entry);
        for (i = 0; i < recent.length && result.length < 60; i += 1) {
            if (recent[i].key !== key) { result.push(recent[i]); }
        }
        return saveStoredList("nexo_legacy_recent", result);
    }

    function removeRecentItem(type, item) {
        var recent = loadSavedList("nexo_legacy_recent");
        var key = currentServerIdentity() + "|" + type + "|" + contentId(type, item);
        var result = [];
        var i;
        for (i = 0; i < recent.length; i += 1) {
            if (recent[i].key !== key) { result.push(recent[i]); }
        }
        saveStoredList("nexo_legacy_recent", result);
    }

    function removeRecentEntry(entry) {
        var recent = loadSavedList("nexo_legacy_recent");
        var result = [];
        var i;
        if (!entry) { return false; }
        for (i = 0; i < recent.length; i += 1) {
            if (recent[i].key !== entry.key) { result.push(recent[i]); }
        }
        return saveStoredList("nexo_legacy_recent", result);
    }

    function clearRecentItems() {
        try { localStorage.removeItem("nexo_legacy_recent"); } catch (ignore) {}
    }

    function watchedEpisodeKey(seriesItem, episode) {
        return currentServerIdentity() + "|series|" + contentId("series", seriesItem) + "|episode|" + contentId("episode", episode);
    }

    function rebuildWatchedLookup() {
        var watched = loadStoredList("nexo_legacy_watched");
        var lookup = {};
        var i;
        for (i = 0; i < watched.length; i += 1) {
            if (watched[i] && watched[i].key) { lookup[watched[i].key] = true; }
        }
        state.watchedLookup = lookup;
    }

    function isEpisodeWatched(seriesItem, episode) {
        if (!seriesItem || !episode) { return false; }
        if (!state.watchedLookup) { rebuildWatchedLookup(); }
        return !!state.watchedLookup[watchedEpisodeKey(seriesItem, episode)];
    }

    function markEpisodeWatched(context) {
        var watched;
        var key;
        var result = [];
        var i;
        if (!state.seriesItem || !context || !context.episode) { return; }
        key = watchedEpisodeKey(state.seriesItem, context.episode);
        if (isEpisodeWatched(state.seriesItem, context.episode)) { return; }
        watched = loadStoredList("nexo_legacy_watched");
        result.push({
            key: key,
            serverKey: currentServerIdentity(),
            serverName: currentServerName(),
            seriesId: contentId("series", state.seriesItem),
            episodeId: contentId("episode", context.episode),
            seasonKey: context.seasonKey,
            episodeIndex: context.episodeIndex,
            watchedAt: new Date().getTime()
        });
        for (i = 0; i < watched.length && result.length < 2000; i += 1) {
            if (watched[i] && watched[i].key !== key) { result.push(watched[i]); }
        }
        saveStoredList("nexo_legacy_watched", result);
        state.watchedLookup = null;
    }

    function migrateWatchedEpisodesForMatchedSeries(continueEntry, seasons) {
        var migration = continueEntry && continueEntry._nexoMigration;
        var watched;
        var existing = {};
        var additions = [];
        var result = [];
        var episode;
        var newKey;
        var seasonKey;
        var index;
        var i;
        if (!migration || migration.type !== "series" || !seasons) { return; }
        watched = loadStoredList("nexo_legacy_watched");
        for (i = 0; i < watched.length; i += 1) {
            if (watched[i] && watched[i].key) { existing[watched[i].key] = true; }
        }
        for (i = 0; i < watched.length; i += 1) {
            if (!watched[i] || String(watched[i].serverKey || "") !== String(migration.serverKey || "") ||
                    String(watched[i].seriesId || "") !== String(migration.seriesId || "")) {
                continue;
            }
            seasonKey = String(watched[i].seasonKey === null || typeof watched[i].seasonKey === "undefined" ? "" : watched[i].seasonKey);
            index = parseInt(watched[i].episodeIndex, 10);
            episode = seasons[seasonKey] && index >= 0 ? seasons[seasonKey][index] : null;
            if (!episode) { continue; }
            newKey = watchedEpisodeKey(state.seriesItem, episode);
            if (existing[newKey]) { continue; }
            existing[newKey] = true;
            additions.push({
                key: newKey,
                serverKey: currentServerIdentity(),
                serverName: currentServerName(),
                seriesId: contentId("series", state.seriesItem),
                episodeId: contentId("episode", episode),
                seasonKey: seasonKey,
                episodeIndex: index,
                watchedAt: watched[i].watchedAt || new Date().getTime()
            });
        }
        if (!additions.length) { return; }
        for (i = 0; i < additions.length && result.length < 2000; i += 1) { result.push(additions[i]); }
        for (i = 0; i < watched.length && result.length < 2000; i += 1) { result.push(watched[i]); }
        if (saveStoredList("nexo_legacy_watched", result)) { state.watchedLookup = null; }
    }

    function findSeriesContinueEntry(item) {
        var recent = loadSavedList("nexo_legacy_recent");
        var key = currentServerIdentity() + "|series|" + contentId("series", item);
        var i;
        for (i = 0; i < recent.length; i += 1) {
            if (recent[i].key === key) { return recent[i]; }
        }
        return null;
    }

    function cancelRecentTimer() {
        if (state.recentTimer) { clearTimeout(state.recentTimer); }
        state.recentTimer = null;
        state.recentPending = null;
        state.recentStarted = false;
        state.recentRecorded = false;
        state.recentLastSavedTime = 0;
        state.recentMigration = null;
    }

    function currentContinueMetadata() {
        var context = state.playerEpisodeContext;
        return {
            currentTime: state.playerCurrentTime,
            duration: state.playerDuration,
            seasonKey: context ? context.seasonKey : "",
            episodeIndex: context ? context.episodeIndex : -1,
            episodeId: context && context.episode ? contentId("episode", context.episode) : "",
            episodeTitle: context && context.episode ? safeName(context.episode, "Epis\u00F3dio") : ""
        };
    }

    function recordContinueNow() {
        var saved;
        if (!state.playerOpen || !state.recentPending || !state.recentRecorded) { return false; }
        if (state.playerType === "episode" && state.playerAdvancePrepared) { return false; }
        saved = addRecentItem(state.recentPending.type, state.recentPending.item, currentContinueMetadata());
        if (!saved) { return false; }
        state.recentLastSavedTime = state.playerCurrentTime;
        if (state.recentMigration && state.recentMigration.oldKey && state.recentMigration.oldKey !== state.recentMigration.newKey) {
            if (removeRecentEntry({ key: state.recentMigration.oldKey })) {
                toast("Continue assistindo atualizado para " + currentServerName());
                state.recentMigration = null;
            }
        }
        return true;
    }

    function prepareNextEpisodeContinue() {
        var context = state.playerEpisodeContext;
        if (state.playerType !== "episode" || !state.seriesItem || !context || state.playerAdvancePrepared) { return; }
        markEpisodeWatched(context);
        if (!context.nextEpisode) { return; }
        addRecentItem("series", state.seriesItem, {
            currentTime: 0,
            duration: 0,
            seasonKey: context.nextSeasonKey,
            episodeIndex: context.nextEpisodeIndex,
            episodeId: contentId("episode", context.nextEpisode),
            episodeTitle: "Epis\u00F3dio " + formatEpisodeNumber(context.nextEpisode, context.nextEpisodeIndex, false)
        });
        state.playerAdvancePrepared = true;
        state.recentLastSavedTime = 0;
    }

    function startRecentTimer() {
        if (!state.playerOpen || !state.recentPending || state.recentStarted) { return; }
        state.recentStarted = true;
        state.recentTimer = setTimeout(function () {
            if (state.playerOpen && state.recentPending) {
                state.recentRecorded = true;
                recordContinueNow();
            }
            state.recentTimer = null;
        }, 30000);
    }

    function validateLoginFields() {
        if (state.login.code.length !== 4) {
            setLoginStatus("Digite um c\u00F3digo de 4 d\u00EDgitos", true);
            setFocus(byId("login-code"));
            return false;
        }
        if (!state.login.username) {
            setLoginStatus("Digite o usu\u00E1rio", true);
            setFocus(byId("login-user"));
            return false;
        }
        if (!state.login.password) {
            setLoginStatus("Digite a senha", true);
            setFocus(byId("login-pass"));
            return false;
        }
        return true;
    }

    function login(automatic) {
        var serverSearchTimer = null;
        var serverSearchStarted = 0;
        var currentServerName = "";

        function stopServerSearchTimer() {
            if (serverSearchTimer) {
                clearInterval(serverSearchTimer);
                serverSearchTimer = null;
            }
        }

        function updateServerSearchMessage() {
            var seconds;
            if (!serverSearchStarted) { return; }
            seconds = Math.floor((new Date().getTime() - serverSearchStarted) / 1000);
            updateLoadingMessage("Buscando servidor... " + seconds + "s" +
                (currentServerName ? "<br><span>" + currentServerName + "</span>" : ""));
        }

        function failLogin(message, forgetSavedAccess) {
            stopServerSearchTimer();
            hideLoading();
            if (forgetSavedAccess) { clearSavedSession(); }
            if (automatic) {
                setScreen("login");
                focusFirst("login-code");
            }
            setLoginStatus(message, true);
        }

        if (!validateLoginFields()) { return; }
        showLoading("Verificando c\u00F3digo...");
        setLoginStatus("");
        NexoApi.loadAccessCodes(function (error, data) {
            var entry;
            var servers;
            if (error) {
                failLogin("N\u00E3o foi poss\u00EDvel consultar os c\u00F3digos", false);
                return;
            }
            state.accessData = data;
            entry = data.codigos[state.login.code];
            if (!entry) {
                failLogin("C\u00F3digo n\u00E3o encontrado ou desativado", true);
                return;
            }
            state.codeEntry = entry;
            servers = NexoApi.flattenServers(entry);
            servers = prioritizeSavedServer(servers);
            if (!servers.length) {
                failLogin("Este c\u00F3digo n\u00E3o possui servidores", false);
                return;
            }
            serverSearchStarted = new Date().getTime();
            showLoading("Buscando servidor... 0s");
            serverSearchTimer = setInterval(updateServerSearchMessage, 1000);
            NexoApi.findWorkingServer(servers, state.login.username, state.login.password, function (server) {
                currentServerName = server.serverName;
                updateServerSearchMessage();
            }, function (serverError, server, account) {
                stopServerSearchTimer();
                if (serverError) {
                    failLogin("Nenhum servidor dispon\u00EDvel. O acesso continua salvo; tente novamente.", false);
                    return;
                }
                state.session = {
                    code: state.login.code,
                    username: state.login.username,
                    password: state.login.password,
                    server: server,
                    account: account,
                    sources: entry.fontes || []
                };
                state.parentalSettings = null;
                state.parentalCategories = { live: null, movie: null, series: null };
                state.parentalCategoryNames = { live: {}, movie: {}, series: {} };
                loadParentalSettings();
                saveSession();
                hideLoading();
                openMain();
            }, { maxDuration: 0, retryDelay: 500 });
        });
    }

    function openMain() {
        setScreen("main");
        byId("connected-user").innerHTML = "\u25CF " + state.session.username;
        updateServerInfo();
        resetLatestCatalogCache(currentServerHost());
        if (state.preview) {
            renderPreviewCatalog();
        } else {
            setPage("TV ao vivo", "Preparando as listas salvas");
            byId("content-root").innerHTML = "";
            scheduleLatestCatalogPrefetch(false, function () { openCatalog("live"); });
        }
    }

    function updateServerInfo() {
        var server = state.session && state.session.server;
        if (!server) { return; }
        byId("server-info").innerHTML = "<b>" + server.serverName + "</b><br>Fonte: " + (server.sourceName || "Principal");
    }

    function setPage(title, subtitle) {
        byId("page-title").innerHTML = title;
        byId("page-subtitle").innerHTML = subtitle || "";
        byId("content-scroll").scrollTop = 0;
        byId("content-scroll").scrollLeft = 0;
    }

    function safeName(item, fallback) {
        return item.name || item.title || item.series_name || fallback || "Sem t\u00EDtulo";
    }

    function imageFor(item, type) {
        if (type === "series") {
            return item.cover || item.stream_icon || "images/nexo-symbol.png";
        }
        return item.stream_icon || item.cover || "images/nexo-symbol.png";
    }

    function createPosterCard(item, type) {
        var card = document.createElement("div");
        var image = document.createElement("img");
        var label = document.createElement("span");
        if (!item.category_name && state.parentalCategoryNames[type]) {
            item.category_name = state.parentalCategoryNames[type][String(item.category_id || "")] || "";
        }
        card.className = "poster-card focusable";
        card.setAttribute("data-action", "item");
        card._nexoItem = item;
        card._nexoType = type;
        image.src = imageFor(item, type);
        image.alt = safeName(item);
        image.onerror = function () {
            this.onerror = null;
            this.src = "images/nexo-symbol.png";
        };
        label.className = "card-name";
        label.innerHTML = safeName(item);
        card.appendChild(image);
        card.appendChild(label);
        updatePosterFavoriteBadge(card, isFavoriteItem(type, item));
        return card;
    }

    function renderHome() {
        var root = byId("content-root");
        var choices = [
            { type: "live", title: "TV ao vivo", subtitle: "Canais organizados por categoria", icon: "\u25A3" },
            { type: "movie", title: "Filmes", subtitle: "Cat\u00E1logo de filmes do servidor", icon: "\u25B6" },
            { type: "series", title: "S\u00E9ries", subtitle: "Temporadas e epis\u00F3dios", icon: "\u25A4" }
        ];
        var i;
        var tile;
        var icon;
        var title;
        var subtitle;
        state.currentType = "home";
        state.currentCategory = null;
        setPage("In\u00EDcio", "Vers\u00E3o leve para Samsung Smart Hub 2014");
        root.innerHTML = "";
        for (i = 0; i < choices.length; i += 1) {
            tile = document.createElement("button");
            tile.className = "home-tile focusable";
            tile.setAttribute("data-action", "catalog");
            tile.setAttribute("data-type", choices[i].type);
            icon = document.createElement("span");
            icon.className = "home-tile-icon";
            icon.innerHTML = choices[i].icon;
            title = document.createElement("strong");
            title.innerHTML = choices[i].title;
            subtitle = document.createElement("small");
            subtitle.innerHTML = choices[i].subtitle;
            tile.appendChild(icon);
            tile.appendChild(title);
            tile.appendChild(subtitle);
            root.appendChild(tile);
        }
        focusFirst();
    }

    function createCatalogSearchButton() {
        var button = document.createElement("button");
        var icon = document.createElement("img");
        button.className = "category-button catalog-search-button focusable";
        button.setAttribute("data-action", "search");
        button.setAttribute("title", "Pesquisar");
        icon.className = "menu-item-icon catalog-search-icon";
        icon.src = "images/menu/pesquisar.png";
        icon.alt = "Pesquisar";
        button.appendChild(icon);
        return button;
    }

    function renderPreviewCatalog() {
        var root = byId("content-root");
        var strip = document.createElement("div");
        var list = document.createElement("div");
        var categories = ["Todos", "Esportes", "Canais abertos"];
        var items = [];
        var i;
        var button;
        for (i = 0; i < 65; i += 1) {
            items.push({ name: "Canal de demonstra\u00E7\u00E3o " + (i + 1), stream_icon: "images/nexo-symbol.png" });
        }
        state.currentType = "live";
        state.currentCategory = "preview";
        state.currentCategoryName = "Todos";
        state.catalogItems = items;
        setPage("TV ao vivo", "Escolha uma categoria e um canal");
        strip.className = "category-strip";
        list.className = "items-list catalog-grid";
        list.id = "catalog-items";
        strip.appendChild(createCatalogSearchButton());
        for (i = 0; i < categories.length; i += 1) {
            button = document.createElement("button");
            button.className = "category-button focusable";
            button.innerHTML = categories[i];
            strip.appendChild(button);
        }
        root.innerHTML = "";
        root.appendChild(strip);
        root.appendChild(list);
        renderCatalogResults(items, "live");
        focusFirst();
    }

    function openCatalog(type, categoryId) {
        var names = { live: "TV ao vivo", movie: "Filmes", series: "S\u00E9ries" };
        var root = byId("content-root");
        state.detailOpen = false;
        state.detailItem = null;
        state.detailReturnView = null;
        state.detailResumeEntry = null;
        state.seriesOpen = false;
        state.seriesItem = null;
        state.seriesData = null;
        state.seriesReturnView = null;
        state.searchActive = false;
        state.currentType = type;
        state.currentCategory = categoryId || "";
        state.currentCategoryName = "";
        setPage(names[type], "Escolha uma categoria e um conte\u00FAdo \u2022 Bot\u00E3o VERDE: adicionar ou remover favorito");
        root.innerHTML = "";
        showLoading("Carregando " + names[type].toLowerCase() + "...");
        requestCatalogCategories(type, function (categoryError, categories) {
            if (categoryError) {
                hideLoading();
                root.innerHTML = "<div class='empty-state'>N\u00E3o foi poss\u00EDvel carregar as categorias</div>";
                toast(categoryError.message);
                return;
            }
            categories = categories || [];
            rememberCategoryNames(type, categories);
            state.parentalCategories[type] = categories.slice(0);
            if (type === "movie" || type === "series") {
                categories = categories.slice(0);
                categories.unshift({
                    category_id: "__latest__",
                    category_name: "\u00DAltimos adicionados"
                });
            }
            renderCatalog(type, categories, categoryId || "");
        });
    }

    function renderCatalog(type, categories, categoryId) {
        var root = byId("content-root");
        var strip = document.createElement("div");
        var list = document.createElement("div");
        var selectedCategory = categoryId || (categories.length ? categories[0].category_id : "");
        var selectedButton = null;
        var i;
        var button;
        strip.className = "category-strip";
        list.className = "items-list catalog-grid";
        list.id = "catalog-items";
        strip.appendChild(createCatalogSearchButton());

        for (i = 0; i < categories.length; i += 1) {
            button = document.createElement("button");
            button.className = "category-button focusable";
            button.setAttribute("data-action", "category");
            button.setAttribute("data-category", categories[i].category_id || "");
            button.innerHTML = categories[i].category_name || ("Categoria " + (i + 1));
            button._nexoCategory = {
                type: type,
                id: String(categories[i].category_id || ""),
                name: button.innerHTML
            };
            if (String(categories[i].category_id || "") === String(selectedCategory)) {
                selectedButton = button;
                state.currentCategoryName = button.innerHTML;
            }
            strip.appendChild(button);
        }
        root.innerHTML = "";
        root.appendChild(strip);
        root.appendChild(list);
        if (selectedButton) {
            setFocus(selectedButton);
        } else if (strip.getElementsByClassName("focusable").length) {
            setFocus(strip.getElementsByClassName("focusable")[0]);
        }
        if (selectedCategory) {
            if (selectedButton && isCategoryBlocked(type, selectedCategory, selectedButton._nexoCategory.name)) {
                hideLoading();
                list.innerHTML = "<div class='empty-state protected-state'>Categoria protegida. Pressione OK e digite o PIN.</div>";
            } else {
                loadCatalogItems(type, selectedCategory);
            }
        } else {
            hideLoading();
            list.innerHTML = "<div class='empty-state'>Nenhuma categoria dispon\u00EDvel</div>";
        }
    }

    function loadCatalogItems(type, categoryId) {
        var list = byId("catalog-items");
        var finishLoading = function (error, items, alreadySorted) {
            var sorted;
            var sourceItems;
            var i;
            if (byId("catalog-items") !== list || state.currentType !== type ||
                    String(state.currentCategory || "") !== String(categoryId || "")) {
                return;
            }
            hideLoading();
            list.innerHTML = "";
            if (error) {
                list.innerHTML = "<div class='empty-state'>Falha ao carregar: " + error.message + "</div>";
                return;
            }
            sourceItems = items || [];
            if (categoryId !== "__latest__") {
                for (i = 0; i < sourceItems.length; i += 1) {
                    if (!sourceItems[i].category_id) { sourceItems[i].category_id = categoryId; }
                    if (!sourceItems[i].category_name) { sourceItems[i].category_name = state.currentCategoryName; }
                }
            }
            sorted = type === "live" ? sourceItems : (alreadySorted ? sourceItems : NexoApi.sortNewest(sourceItems));
            state.catalogItems = sorted;
            renderCatalogResults(sorted, type);
            if (!state.focusElement || !visible(state.focusElement)) {
                focusFirst();
            }
        };
        state.currentCategory = categoryId || "";
        state.searchActive = false;
        showLoading("Carregando conte\u00FAdos...");
        requestLatestCatalog(type, function (error, items) {
            var filtered = [];
            var i;
            if (!error && categoryId !== "__latest__") {
                for (i = 0; i < (items || []).length; i += 1) {
                    if (String(items[i].category_id || "") === String(categoryId || "")) {
                        filtered.push(items[i]);
                    }
                }
            } else {
                filtered = items || [];
            }
            finishLoading(error, filtered, true);
        });
    }

    function renderCatalogResults(items, type, requestedCount) {
        var list = byId("catalog-items");
        var pageSize = (state.currentCategory === "__latest__" && (type === "movie" || type === "series")) ? 20 : NEXO_CONFIG.catalogItemLimit;
        var limit = Math.min(items.length, requestedCount || pageSize);
        var i;
        var more;
        state.catalogViewItems = items;
        state.catalogRenderedCount = limit;
        list.innerHTML = "";
        for (i = 0; i < limit; i += 1) {
            if (type === "live") {
                list.appendChild(createLiveRow(items[i]));
            } else {
                list.appendChild(createPosterCard(items[i], type));
            }
        }
        if (limit < items.length) {
            more = document.createElement("div");
            more.className = type === "live" ? "list-row load-more-row focusable" : "poster-card load-more-card focusable";
            more.setAttribute("data-action", "load-more");
            if (type === "live") {
                more.innerHTML = "<span class='load-more-symbol'>+</span><span class='list-title'>Carregar mais</span>" +
                    "<span class='list-subtitle'>Mostrando " + limit + " de " + items.length + "</span>";
            } else {
                more.innerHTML = "<span class='load-more-symbol'>+</span><span class='card-name'>Ver mais<br>" + limit + " de " + items.length + "</span>";
            }
            list.appendChild(more);
        }
        if (!limit) {
            list.innerHTML = "<div class='empty-state'>Nenhum conte\u00FAdo encontrado</div>";
        }
    }

    function normalizeSearchText(value) {
        return String(value || "").toLowerCase()
            .replace(/[\u00E1\u00E0\u00E2\u00E3\u00E4]/g, "a")
            .replace(/[\u00E9\u00E8\u00EA\u00EB]/g, "e")
            .replace(/[\u00ED\u00EC\u00EE\u00EF]/g, "i")
            .replace(/[\u00F3\u00F2\u00F4\u00F5\u00F6]/g, "o")
            .replace(/[\u00FA\u00F9\u00FB\u00FC]/g, "u")
            .replace(/[\u00E7]/g, "c");
    }

    function updateSearchDisplay() {
        var display = byId("search-value");
        if (display) {
            display.innerHTML = state.searchQuery || "Digite o nome";
        }
    }

    function updateLoginKeyboardDisplay() {
        var display = byId("login-keyboard-value");
        var value = state.loginKeyboardValue || "";
        if (!display) { return; }
        if (state.loginKeyboardField === "password" && value) {
            display.innerHTML = new Array(value.length + 1).join("\u2022");
        } else {
            display.innerHTML = value || "Digite usando o teclado";
        }
    }

    function appendLoginKeyboardCharacter(character) {
        if (!state.loginKeyboardField || state.loginKeyboardValue.length >= 32) { return; }
        state.loginKeyboardValue += character;
        updateLoginKeyboardDisplay();
    }

    function renderLoginKeyboardKeys() {
        var keyboard = byId("login-keyboard-grid");
        var letters = state.loginKeyboardUppercase ? "ABCDEFGHIJKLMNOPQRSTUVWXYZ" : "abcdefghijklmnopqrstuvwxyz";
        var characters = letters + "0123456789._-@";
        var button;
        var i;
        if (!keyboard) { return; }
        keyboard.innerHTML = "";
        for (i = 0; i < characters.length; i += 1) {
            button = document.createElement("button");
            button.className = "search-key focusable";
            button.setAttribute("data-action", "login-keyboard-key");
            button.setAttribute("data-character", characters.charAt(i));
            button.innerHTML = characters.charAt(i);
            keyboard.appendChild(button);
        }
    }

    function openLoginKeyboard(field) {
        var content = byId("modal-content");
        var keyboard = document.createElement("div");
        var actions = document.createElement("div");
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        state.loginKeyboardField = field;
        state.loginKeyboardValue = state.login[field] || "";
        state.loginKeyboardUppercase = false;
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = field === "password" ? "Digite a senha" : "Digite o usu\u00E1rio";
        byId("modal-message").innerHTML = "Use as setas e ENTER para digitar letras e n\u00FAmeros";
        content.innerHTML = "<div id='login-keyboard-value' class='search-value login-keyboard-value'></div>";
        keyboard.id = "login-keyboard-grid";
        keyboard.className = "keyboard-grid login-keyboard-grid";
        actions.className = "search-actions";
        actions.innerHTML = "<button class='search-action focusable' data-action='login-keyboard-backspace'>Apagar</button>" +
            "<button class='search-action focusable' data-action='login-keyboard-clear'>Limpar</button>" +
            "<button class='search-action focusable' data-action='login-keyboard-case'>Aa</button>" +
            "<button class='search-action focusable' data-action='login-keyboard-ok'>OK</button>" +
            "<button class='search-action focusable' data-action='modal-close'>Fechar</button>";
        content.appendChild(keyboard);
        content.appendChild(actions);
        renderLoginKeyboardKeys();
        updateLoginKeyboardDisplay();
        setFocus(keyboard.getElementsByClassName("focusable")[0]);
    }

    function openSearch() {
        var content = byId("modal-content");
        var keyboard = document.createElement("div");
        var actions = document.createElement("div");
        var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ\u00C1\u00C0\u00C2\u00C3\u00C9\u00CA\u00CD\u00D3\u00D4\u00D5\u00DA\u00DC\u00C70123456789";
        var names = { live: "TV ao vivo", movie: "Filmes", series: "S\u00E9ries" };
        var i;
        var button;
        if (state.currentType !== "live" && state.currentType !== "movie" && state.currentType !== "series") {
            toast("Abra TV ao vivo, Filmes ou S\u00E9ries antes de pesquisar");
            return;
        }
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        state.searchQuery = "";
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = "Pesquisar";
        byId("modal-message").innerHTML = "Buscar em todos: " + (names[state.currentType] || "conte\u00FAdos");
        content.innerHTML = "<div id='search-value' class='search-value'>Digite o nome</div>";
        keyboard.className = "keyboard-grid";
        for (i = 0; i < characters.length; i += 1) {
            button = document.createElement("button");
            button.className = "search-key focusable";
            button.setAttribute("data-action", "search-key");
            button.setAttribute("data-character", characters.charAt(i));
            button.innerHTML = characters.charAt(i);
            keyboard.appendChild(button);
        }
        actions.className = "search-actions";
        actions.innerHTML = "<button class='search-action focusable' data-action='search-space'>Espa\u00E7o</button>" +
            "<button class='search-action focusable' data-action='search-backspace'>Apagar</button>" +
            "<button class='search-action focusable' data-action='search-clear'>Limpar</button>" +
            "<button class='search-action focusable' data-action='search-apply'>Buscar</button>" +
            "<button class='search-action focusable' data-action='modal-close'>Fechar</button>";
        content.appendChild(keyboard);
        content.appendChild(actions);
        setFocus(keyboard.getElementsByClassName("focusable")[0]);
    }

    function applySearch() {
        var query = normalizeSearchText(state.searchQuery);
        var names = { live: "TV ao vivo", movie: "Filmes", series: "S\u00E9ries" };
        if (!query) {
            toast("Digite pelo menos uma letra");
            return;
        }
        closeModal();
        showLoading("Buscando em todos os conte\u00FAdos...");
        requestLatestCatalog(state.currentType, function (error, items) {
            var source;
            var results = [];
            var i;
            hideLoading();
            if (error) {
                toast("N\u00E3o foi poss\u00EDvel concluir a pesquisa");
                return;
            }
            source = items || [];
            for (i = 0; i < source.length; i += 1) {
                if (normalizeSearchText(safeName(source[i], "")).indexOf(query) >= 0) {
                    results.push(source[i]);
                }
            }
            state.searchActive = true;
            state.seriesOpen = false;
            setPage("Pesquisa em " + (names[state.currentType] || "conte\u00FAdos"), results.length + " resultado(s) em todo o cat\u00E1logo");
            renderCatalogResults(results, state.currentType);
            if (byId("catalog-items").getElementsByClassName("focusable").length) {
                setFocus(byId("catalog-items").getElementsByClassName("focusable")[0]);
            }
        });
    }

    function createLiveRow(item) {
        var row = document.createElement("div");
        var image = document.createElement("img");
        var title = document.createElement("span");
        var subtitle = document.createElement("span");
        if (!item.category_name && state.parentalCategoryNames.live) {
            item.category_name = state.parentalCategoryNames.live[String(item.category_id || "")] || "";
        }
        row.className = "list-row focusable";
        row.setAttribute("data-action", "item");
        row._nexoItem = item;
        row._nexoType = "live";
        image.className = "list-icon";
        image.src = imageFor(item, "live");
        image.onerror = function () { this.onerror = null; this.src = "images/nexo-symbol.png"; };
        title.className = "list-title";
        title.innerHTML = safeName(item, "Canal");
        subtitle.className = "list-subtitle";
        subtitle.innerHTML = "Ao vivo";
        row.appendChild(image);
        row.appendChild(title);
        row.appendChild(subtitle);
        return row;
    }

    function createSavedRow(entry, kind) {
        var card = document.createElement("div");
        var wrapper;
        var removeButton;
        var image = document.createElement("img");
        var title = document.createElement("span");
        var progress;
        var progressFill;
        var info;
        var serverInfo;
        var percent;
        var serverLabel = "Servidor: " + savedEntryServerName(entry);
        card.className = entry.type === "live" ? "saved-live-card focusable" : "poster-card saved-poster-card focusable";
        card.setAttribute("data-action", "saved-item");
        card._nexoSaved = entry;
        card._nexoSavedKind = kind;
        if (kind === "favorites") { addClass(card, "saved-favorite-card"); }
        image.src = imageFor(entry.item, entry.type);
        image.onerror = function () { this.onerror = null; this.src = "images/nexo-symbol.png"; };
        card.appendChild(image);
        if (kind === "favorites") {
            title.className = entry.type === "live" ? "saved-live-name" : "card-name";
            title.innerHTML = escapeDetailText(safeName(entry.item, "Conte\u00FAdo"));
            card.appendChild(title);
        }
        if (kind === "recent") {
            percent = entry.duration > 0 ?
                Math.max(0, Math.min(100, Math.round((entry.currentTime || 0) * 100 / entry.duration))) : 0;
            progress = document.createElement("div");
            progress.className = "continue-card-timeline";
            progressFill = document.createElement("span");
            progressFill.style.width = percent + "%";
            progress.appendChild(progressFill);
            info = document.createElement("div");
            info.className = "continue-card-info";
            info.innerHTML = "<small>" + (entry.type === "series" ? "S\u00E9rie" : "Filme") + "</small>" +
                "<strong>" + escapeDetailText(safeName(entry.item, "Conte\u00FAdo")) + "</strong>" +
                "<span>" + escapeDetailText(serverLabel) + "</span>";
            wrapper = document.createElement("div");
            wrapper.className = "saved-poster-entry";
            removeButton = document.createElement("button");
            removeButton.className = "continue-delete-button focusable";
            removeButton.setAttribute("data-action", "recent-delete");
            removeButton._nexoSaved = entry;
            removeButton.innerHTML = "Excluir";
            wrapper.appendChild(card);
            wrapper.appendChild(progress);
            wrapper.appendChild(info);
            wrapper.appendChild(removeButton);
            return wrapper;
        }
        if (kind === "favorites") {
            wrapper = document.createElement("div");
            wrapper.className = "saved-favorite-entry" + (entry.type === "live" ? " saved-favorite-entry-live" : "");
            serverInfo = document.createElement("small");
            serverInfo.className = "favorite-server-label";
            serverInfo.innerHTML = escapeDetailText(serverLabel);
            wrapper.appendChild(card);
            wrapper.appendChild(serverInfo);
            return wrapper;
        }
        return card;
    }

    function openSavedList(kind) {
        var root = byId("content-root");
        var list = document.createElement("div");
        var storageKey = kind === "favorites" ? "nexo_legacy_favorites" : "nexo_legacy_recent";
        var entries = loadSavedList(storageKey);
        var filtered = [];
        var groups = [
            { type: "live", title: "TV ao vivo", items: [] },
            { type: "movie", title: "Filmes", items: [] },
            { type: "series", title: "S\u00E9ries", items: [] }
        ];
        var section;
        var sectionTitle;
        var sectionTitleText;
        var sectionTitleArrow;
        var sectionList;
        var carouselArrow;
        var empty;
        var j;
        var i;
        state.detailOpen = false;
        state.detailItem = null;
        state.detailReturnView = null;
        state.detailResumeEntry = null;
        state.seriesOpen = false;
        state.seriesReturnView = null;
        state.currentType = kind;
        state.currentCategory = null;
        setPage(kind === "favorites" ? "Favoritos" : "Continue assistindo",
            kind === "favorites" ? "Use o bot\u00E3o verde para adicionar ou remover favoritos" : "Conte\u00FAdos reproduzidos por pelo menos 30 segundos");
        for (i = 0; i < entries.length; i += 1) {
            filtered.push(entries[i]);
            for (j = 0; j < groups.length; j += 1) {
                if (groups[j].type === entries[i].type) {
                    groups[j].items.push(entries[i]);
                    break;
                }
            }
        }
        filtered = groupSavedEntriesByServer(filtered);
        for (i = 0; i < groups.length; i += 1) {
            groups[i].items = groupSavedEntriesByServer(groups[i].items);
        }
        list.className = "items-list saved-groups" + (kind === "recent" ? " saved-recent-grid" : "");
        list.id = "saved-items";
        if (kind === "favorites") {
            for (i = 0; i < groups.length; i += 1) {
                section = document.createElement("div");
                section.className = "saved-group saved-group-" + groups[i].type;
                section.id = "favorite-group-" + groups[i].type;
                sectionTitle = document.createElement("button");
                sectionTitle.className = "favorite-group-header focusable";
                sectionTitle.setAttribute("data-action", "favorite-group-toggle");
                sectionTitle.setAttribute("data-favorite-type", groups[i].type);
                sectionTitleText = document.createElement("span");
                sectionTitleText.className = "favorite-group-label";
                sectionTitleText.innerHTML = groups[i].title + " (" + groups[i].items.length + ")";
                sectionTitleArrow = document.createElement("span");
                sectionTitleArrow.className = "favorite-group-arrow";
                sectionTitleArrow.innerHTML = state.favoriteOpenType === groups[i].type ? "&#9660;" : "&#9654;";
                sectionTitle.appendChild(sectionTitleText);
                sectionTitle.appendChild(sectionTitleArrow);
                section.appendChild(sectionTitle);
                if (state.favoriteOpenType === groups[i].type) {
                    addClass(section, "favorite-group-open");
                    sectionList = document.createElement("div");
                    sectionList.className = "saved-group-list favorite-carousel card-row";
                    sectionList.id = "favorite-carousel-" + groups[i].type;
                    if (groups[i].items.length) {
                        for (j = 0; j < groups[i].items.length; j += 1) {
                            sectionList.appendChild(createSavedRow(groups[i].items[j], kind));
                        }
                    } else {
                        empty = document.createElement("div");
                        empty.className = "saved-group-empty";
                        empty.innerHTML = "Nenhum favorito";
                        sectionList.appendChild(empty);
                    }
                    section.appendChild(sectionList);
                    carouselArrow = document.createElement("span");
                    carouselArrow.className = "favorite-carousel-arrow" + (groups[i].items.length > 5 ? "" : " hidden");
                    carouselArrow.innerHTML = "&#10095;";
                    section.appendChild(carouselArrow);
                }
                list.appendChild(section);
            }
        } else {
            for (i = 0; i < filtered.length; i += 1) {
                list.appendChild(createSavedRow(filtered[i], kind));
            }
        }
        root.innerHTML = "";
        if (filtered.length || kind === "favorites") {
            root.appendChild(list);
            if (list.getElementsByClassName("focusable").length) {
                setFocus(list.getElementsByClassName("focusable")[0]);
            }
        } else {
            root.innerHTML = "<div class='empty-state'>" + (kind === "favorites" ? "Nenhum favorito salvo" : "Nenhum conte\u00FAdo para continuar") + "</div>";
        }
    }

    function escapeDetailText(value) {
        return String(value === null || typeof value === "undefined" ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\"/g, "&quot;")
            .replace(/'/g, "&#39;")
            .replace(/\r?\n/g, " ");
    }

    function detailValue(objects, keys) {
        var value;
        var i;
        var j;
        for (i = 0; i < objects.length; i += 1) {
            if (!objects[i]) { continue; }
            for (j = 0; j < keys.length; j += 1) {
                value = objects[i][keys[j]];
                if (value !== null && typeof value !== "undefined" && String(value).replace(/^\s+|\s+$/g, "")) {
                    return String(value).replace(/^\s+|\s+$/g, "");
                }
            }
        }
        return "";
    }

    function detailStarsHtml(objects) {
        var fiveValue = parseFloat(detailValue(objects, ["rating_5based"]));
        var ratingValue = parseFloat(detailValue(objects, ["rating"]));
        var stars;
        var label;
        var html = "";
        var i;
        if (isFinite(fiveValue) && fiveValue > 0) {
            stars = Math.max(0, Math.min(5, fiveValue));
            label = fiveValue.toFixed(1) + "/5";
        } else if (isFinite(ratingValue) && ratingValue > 0) {
            stars = Math.max(0, Math.min(5, ratingValue > 5 ? ratingValue / 2 : ratingValue));
            label = ratingValue.toFixed(1) + (ratingValue > 5 ? "/10" : "/5");
        } else {
            return "";
        }
        for (i = 1; i <= 5; i += 1) {
            html += "<span" + (i <= Math.round(stars) ? " class='filled'" : "") + ">&#9733;</span>";
        }
        return "<div class='detail-stars'>" + html + " <b>" + label + "</b></div>";
    }

    function detailMetaHtml(objects) {
        var year = detailValue(objects, ["year", "releaseDate", "releasedate"]);
        var genre = detailValue(objects, ["genre"]);
        var duration = detailValue(objects, ["duration", "duration_secs"]);
        var parts = [];
        if (year) { parts.push(escapeDetailText(year).substring(0, 10)); }
        if (genre) { parts.push(escapeDetailText(genre)); }
        if (duration) { parts.push(escapeDetailText(duration)); }
        return parts.join(" &#8226; ");
    }

    function renderMovieDetails(item, data) {
        var root = byId("content-root");
        var info = data && data.info ? data.info : null;
        var movieData = data && data.movie_data ? data.movie_data : null;
        var objects = [info, movieData, item];
        var title = detailValue(objects, ["name", "title"]) || safeName(item, "Filme");
        var plot = detailValue(objects, ["plot", "description"]) || "Sinopse n\u00E3o informada pela lista.";
        var director = detailValue(objects, ["director"]);
        var cast = detailValue(objects, ["cast", "actors"]);
        var meta = detailMetaHtml(objects);
        var button;
        setPage("Detalhes do filme", "");
        root.innerHTML = "<div class='media-detail-layout'>" +
            "<div class='media-detail-poster'><img id='movie-detail-poster' alt='' /></div>" +
            "<div class='media-detail-content'>" +
                "<h3>" + escapeDetailText(title) + "</h3>" +
                detailStarsHtml(objects) +
                (meta ? "<div class='detail-meta'>" + meta + "</div>" : "") +
                "<p class='detail-synopsis'>" + escapeDetailText(plot) + "</p>" +
                (director ? "<div class='detail-extra'><b>Dire\u00E7\u00E3o:</b> " + escapeDetailText(director) + "</div>" : "") +
                (cast ? "<div class='detail-extra'><b>Elenco:</b> " + escapeDetailText(cast) + "</div>" : "") +
                "<button id='movie-detail-play' class='detail-play-button focusable' data-action='movie-play'>Assistir</button>" +
            "</div></div>";
        byId("movie-detail-poster").src = imageFor(item, "movie");
        byId("movie-detail-poster").onerror = function () { this.onerror = null; this.src = "images/nexo-symbol.png"; };
        button = byId("movie-detail-play");
        button._nexoItem = item;
        button._nexoType = "movie";
        button._nexoResumeEntry = state.detailResumeEntry;
        setFocus(button);
    }

    function openMovieDetails(item, returnView, resumeEntry) {
        var movieId = item ? (item.stream_id || item.id) : null;
        state.detailOpen = true;
        state.detailItem = item;
        state.detailReturnView = returnView || null;
        state.detailResumeEntry = resumeEntry || null;
        state.seriesOpen = false;
        state.seriesItem = null;
        state.seriesData = null;
        setPage("Detalhes do filme", "Carregando informa\u00E7\u00F5es...");
        byId("content-root").innerHTML = "";
        showLoading("Carregando informa\u00E7\u00F5es do filme...");
        if (!movieId) {
            hideLoading();
            renderMovieDetails(item, null);
            return;
        }
        NexoApi.getMovieInfo(state.session, movieId, function (error, data) {
            if (!state.detailOpen || state.detailItem !== item) { return; }
            hideLoading();
            renderMovieDetails(item, error ? null : data);
            if (error) { toast("Detalhes complementares indispon\u00EDveis"); }
        });
    }

    function activateSavedEntry(entry, returnView) {
        if (!entry || !entry.item) { return; }
        if (entry.type === "series") {
            resumeSeriesEntry(entry, returnView);
        } else if (entry.type === "movie") {
            openMovieDetails(entry.item, returnView, returnView === "recent" ? entry : null);
        } else {
            playItem(entry.type, entry.item, safeName(entry.item), entry);
        }
    }

    function activateCatalogElement(element) {
        var details = itemCategoryDetails(element._nexoType, element._nexoItem);
        authorizeCategory(details, function () {
            if (element._nexoType === "series") {
                openSeries(element._nexoItem);
            } else if (element._nexoType === "movie") {
                openMovieDetails(element._nexoItem);
            } else {
                playItem(element._nexoType, element._nexoItem, safeName(element._nexoItem));
            }
        });
    }

    function savedContentTypeLabel(type) {
        if (type === "series") { return "essa s\u00E9rie"; }
        if (type === "movie") { return "esse filme"; }
        return "esse canal";
    }

    function canonicalMatchTitle(value) {
        var text = normalizeSearchText(value)
            .replace(/\[[^\]]*\]/g, " ")
            .replace(/\((?:19|20)\d{2}\)/g, " ")
            .replace(/\b(?:19|20)\d{2}\b/g, " ")
            .replace(/[^a-z0-9]+/g, " ")
            .replace(/^\s+|\s+$/g, "");
        var source = text ? text.split(/\s+/) : [];
        var ignored = { "a": 1, "an": 1, "the": 1, "o": 1, "os": 1, "as": 1, "um": 1, "uma": 1, "de": 1, "da": 1, "do": 1, "das": 1, "dos": 1,
            "serie": 1, "series": 1, "filme": 1, "movie": 1, "hd": 1, "fhd": 1, "uhd": 1, "4k": 1, "dublado": 1, "legendado": 1, "dual": 1 };
        var aliases = { "theory": "teoria", "theories": "teoria", "teoria": "teoria", "hundred": "100", "cem": "100" };
        var result = [];
        var token;
        var i;
        for (i = 0; i < source.length; i += 1) {
            token = aliases[source[i]] || source[i];
            if (token && !ignored[token]) { result.push(token); }
        }
        return result.join(" ");
    }

    function titleTokens(value) {
        var normalized = canonicalMatchTitle(value);
        return normalized ? normalized.split(/\s+/) : [];
    }

    function externalContentId(item) {
        return String((item && (item.imdb_id || item.imdb || item.tmdb_id || item.tmdb)) || "")
            .toLowerCase().replace(/^\s+|\s+$/g, "");
    }

    function titleMatchScore(savedItem, candidate) {
        var savedExternal = externalContentId(savedItem);
        var candidateExternal = externalContentId(candidate);
        var savedTitle = canonicalMatchTitle(safeName(savedItem, ""));
        var candidateTitle = canonicalMatchTitle(safeName(candidate, ""));
        var savedTokens;
        var candidateTokens;
        var seen = {};
        var common = 0;
        var score;
        var savedYear;
        var candidateYear;
        var i;
        if (savedExternal && candidateExternal && savedExternal === candidateExternal) { return 1000; }
        if (!savedTitle || !candidateTitle) { return 0; }
        if (savedTitle === candidateTitle) { score = 100; }
        else if ((savedTitle.length >= 4 && candidateTitle.indexOf(savedTitle) >= 0) ||
                (candidateTitle.length >= 4 && savedTitle.indexOf(candidateTitle) >= 0)) {
            score = 84;
        } else {
            savedTokens = titleTokens(savedTitle);
            candidateTokens = titleTokens(candidateTitle);
            for (i = 0; i < savedTokens.length; i += 1) { seen[savedTokens[i]] = true; }
            for (i = 0; i < candidateTokens.length; i += 1) {
                if (seen[candidateTokens[i]]) { common += 1; }
            }
            score = savedTokens.length + candidateTokens.length ?
                Math.round((common * 200) / (savedTokens.length + candidateTokens.length)) : 0;
        }
        savedYear = String((savedItem && (savedItem.year || savedItem.releaseDate || savedItem.releasedate)) || "").match(/(?:19|20)\d{2}/);
        candidateYear = String((candidate && (candidate.year || candidate.releaseDate || candidate.releasedate)) || "").match(/(?:19|20)\d{2}/);
        if (savedYear && candidateYear) { score += savedYear[0] === candidateYear[0] ? 5 : -8; }
        return Math.max(0, score);
    }

    function findSavedTitleMatches(entry, items) {
        var matches = [];
        var score;
        var i;
        items = items || [];
        for (i = 0; i < items.length; i += 1) {
            score = titleMatchScore(entry.item, items[i]);
            if (score >= 45) { matches.push({ item: items[i], score: score }); }
        }
        matches.sort(function (a, b) { return b.score - a.score; });
        if (matches.length > 6) { matches.length = 6; }
        return matches;
    }

    function matchedSavedEntry(entry, item) {
        var result = {};
        var key;
        for (key in entry) {
            if (entry.hasOwnProperty(key)) { result[key] = entry[key]; }
        }
        result.item = compactItem(item);
        result.serverHost = currentServerHost();
        result.serverName = currentServerName();
        result.serverKey = currentServerIdentity();
        result.key = currentServerIdentity() + "|" + entry.type + "|" + contentId(entry.type, item);
        return result;
    }

    function openSavedSearchMessage(title, message) {
        var content = byId("modal-content");
        var close = document.createElement("button");
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        setModalClass("saved-search-message-modal");
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = title;
        byId("modal-message").innerHTML = message;
        content.innerHTML = "";
        close.className = "modal-button focusable";
        close.setAttribute("data-action", "modal-close");
        close.innerHTML = "Fechar";
        content.appendChild(close);
        setFocus(close);
    }

    function offerSearchOnCurrentServer(pending) {
        var content = byId("modal-content");
        var search = document.createElement("button");
        var close = document.createElement("button");
        var originName;
        if (!pending || !pending.entry) { return; }
        originName = savedEntryServerName(pending.entry);
        state.pendingSavedServerOpen = pending;
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        setModalClass("saved-search-offer-modal");
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = "Servidor indispon\u00EDvel";
        byId("modal-message").innerHTML = "O servidor <strong>" + escapeDetailText(originName) +
            "</strong> n\u00E3o respondeu.<br>Deseja procurar " + savedContentTypeLabel(pending.entry.type) +
            " no servidor <strong>" + escapeDetailText(currentServerName()) + "</strong>?";
        content.innerHTML = "";
        search.className = "modal-button focusable";
        search.setAttribute("data-action", "saved-current-search");
        search.innerHTML = "Buscar neste servidor";
        close.className = "modal-button focusable";
        close.setAttribute("data-action", "modal-close");
        close.innerHTML = "Fechar";
        content.appendChild(search);
        content.appendChild(close);
        setFocus(search);
    }

    function offerSavedServerChoice(pending) {
        var content = byId("modal-content");
        var search = document.createElement("button");
        var change = document.createElement("button");
        var serverName;
        var messagePrefix;
        if (!pending || !pending.entry || !pending.server) {
            offerSearchOnCurrentServer(pending);
            return;
        }
        serverName = savedEntryServerName(pending.entry);
        messagePrefix = pending.returnView === "favorites" ?
            "Voc\u00EA adicionou " + savedContentTypeLabel(pending.entry.type) :
            "Voc\u00EA est\u00E1 assistindo " + savedContentTypeLabel(pending.entry.type);
        state.pendingSavedServerOpen = pending;
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        setModalClass("saved-server-choice-modal");
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = "Abrir conte\u00FAdo";
        byId("modal-message").innerHTML = messagePrefix + " no <strong>" +
            escapeDetailText(serverName) + "</strong>.<br>Escolha como deseja continuar.";
        content.innerHTML = "";
        search.className = "modal-button focusable";
        search.setAttribute("data-action", "saved-current-search");
        search.innerHTML = "Buscar neste servidor";
        change.className = "modal-button focusable";
        change.setAttribute("data-action", "saved-server-switch-confirm");
        change.innerHTML = "Trocar de servidor";
        content.appendChild(search);
        content.appendChild(change);
        setFocus(search);
    }

    function openSavedSearchResults(pending, matches) {
        var content = byId("modal-content");
        var button;
        var year;
        var i;
        state.pendingSavedServerOpen = pending;
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        setModalClass("saved-search-results-modal");
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = "Resultados encontrados";
        byId("modal-message").innerHTML = "Escolha o conte\u00FAdo correspondente no servidor " + escapeDetailText(currentServerName());
        content.innerHTML = "";
        for (i = 0; i < matches.length; i += 1) {
            button = document.createElement("button");
            button.className = "modal-button saved-search-result focusable";
            button.setAttribute("data-action", "saved-search-result");
            button._nexoSearchItem = matches[i].item;
            button._nexoSearchPending = pending;
            year = String(matches[i].item.year || matches[i].item.releaseDate || matches[i].item.releasedate || "").match(/(?:19|20)\d{2}/);
            button.innerHTML = escapeDetailText(safeName(matches[i].item, "Conte\u00FAdo")) +
                (year ? " <small>(" + year[0] + ")</small>" : "");
            content.appendChild(button);
        }
        button = document.createElement("button");
        button.className = "modal-button saved-search-close focusable";
        button.setAttribute("data-action", "modal-close");
        button.innerHTML = "Fechar";
        content.appendChild(button);
        setFocus(content.getElementsByClassName("focusable")[0]);
    }

    function openMatchedSavedContent(pending, item) {
        var entry;
        if (!pending || !pending.entry || !item) { return; }
        entry = matchedSavedEntry(pending.entry, item);
        if (pending.returnView === "recent") {
            entry._nexoMigration = {
                oldKey: pending.entry.key || (savedEntryServerIdentity(pending.entry) + "|" + pending.entry.type + "|" +
                    contentId(pending.entry.type, pending.entry.item)),
                newKey: entry.key,
                type: pending.entry.type,
                serverKey: savedEntryServerIdentity(pending.entry),
                seriesId: contentId("series", pending.entry.item)
            };
        }
        activateSavedWithAuthorization(entry, pending.returnView);
    }

    function searchSavedOnCurrentServer(pending) {
        var type;
        if (!pending || !pending.entry) { return; }
        type = pending.entry.type;
        if (type !== "live" && type !== "movie" && type !== "series") {
            openSavedSearchMessage("Busca indispon\u00EDvel", "Este tipo de conte\u00FAdo n\u00E3o pode ser pesquisado.");
            return;
        }
        showLoading("Buscando " + safeName(pending.entry.item, "conte\u00FAdo") +
            " no servidor " + currentServerName() + "...");
        setTimeout(function () {
            requestLatestCatalog(type, function (error, items) {
                var matches;
                hideLoading();
                if (error) {
                    openSavedSearchMessage("Falha na busca", "N\u00E3o foi poss\u00EDvel consultar o servidor atual.");
                    return;
                }
                matches = findSavedTitleMatches(pending.entry, items);
                if (!matches.length) {
                    openSavedSearchMessage("Conte\u00FAdo n\u00E3o encontrado", "N\u00E3o encontramos um t\u00EDtulo semelhante no servidor " +
                        escapeDetailText(currentServerName()) + ".");
                    return;
                }
                if (matches[0].score >= 95 && (matches.length === 1 || matches[1].score < matches[0].score - 8)) {
                    openMatchedSavedContent(pending, matches[0].item);
                    return;
                }
                openSavedSearchResults(pending, matches);
            });
        }, 80);
    }

    function requestSavedServerSwitch(entry, returnView) {
        var server = findServerForSavedEntry(entry);
        var pending;
        if (!server) {
            offerSearchOnCurrentServer({ entry: entry, returnView: returnView, server: null });
            return;
        }
        pending = {
            entry: entry,
            returnView: returnView,
            server: server
        };
        state.pendingSavedServerOpen = pending;
        offerSavedServerChoice(pending);
    }

    function switchServerForSavedEntry(pending) {
        var server;
        if (!pending || !pending.entry || !pending.server) { return; }
        server = pending.server;
        closeModal();
        showLoading("Conectando em " + server.serverName + "...");
        NexoApi.checkServer(server, state.session.username, state.session.password, function (error, account) {
            hideLoading();
            if (error) {
                offerSearchOnCurrentServer(pending);
                return;
            }
            state.session.server = server;
            state.session.account = account;
            state.parentalCategories = { live: null, movie: null, series: null };
            state.parentalCategoryNames = { live: {}, movie: {}, series: {} };
            state.favoriteLookup = null;
            state.watchedLookup = null;
            resetLatestCatalogCache(server.serverHost);
            saveSession();
            updateServerInfo();
            scheduleLatestCatalogPrefetch(true, function () {
                activateSavedWithAuthorization(pending.entry, pending.returnView);
                toast("Conectado em " + server.serverName);
            });
        });
    }

    function activateSavedWithAuthorization(entry, returnView) {
        var details;
        if (!entry || !entry.item) { return; }
        if (savedEntryServerIdentity(entry) !== currentServerIdentity()) {
            requestSavedServerSwitch(entry, returnView);
            return;
        }
        details = itemCategoryDetails(entry.type, entry.item);
        authorizeCategory(details, function () {
            activateSavedEntry(entry, returnView);
        });
    }

    function resumeSeriesEntry(entry, returnView) {
        var continueEntry = returnView === "recent" ? entry : findSeriesContinueEntry(entry.item);
        openSeries(entry.item, continueEntry, returnView);
    }

    function openSeries(item, continueEntry, returnView) {
        var root = byId("content-root");
        state.detailOpen = false;
        state.detailItem = null;
        state.detailReturnView = null;
        state.detailResumeEntry = null;
        state.seriesOpen = true;
        state.seriesItem = item;
        state.seriesData = null;
        state.seriesContinueEntry = continueEntry || findSeriesContinueEntry(item);
        state.seriesReturnView = returnView || null;
        state.seriesSeasonMenuOpen = false;
        state.seriesFocusEpisodeId = "";
        setPage("Detalhes da s\u00E9rie", "Carregando informa\u00E7\u00F5es...");
        root.innerHTML = "";
        showLoading("Carregando epis\u00F3dios...");
        NexoApi.getSeriesInfo(state.session, item.series_id, function (error, data) {
            var seasons;
            var seasonKeys = [];
            var key;
            hideLoading();
            if (error || !data || !data.episodes) {
                root.innerHTML = "<div class='empty-state'>N\u00E3o foi poss\u00EDvel carregar os epis\u00F3dios</div>";
                toast(error ? error.message : "S\u00E9rie sem epis\u00F3dios");
                return;
            }
            seasons = data.episodes;
            for (key in seasons) {
                if (seasons.hasOwnProperty(key)) { seasonKeys.push(key); }
            }
            seasonKeys.sort(function (a, b) { return parseInt(a, 10) - parseInt(b, 10); });
            if (!seasonKeys.length) {
                root.innerHTML = "<div class='empty-state'>S\u00E9rie sem temporadas dispon\u00EDveis</div>";
                return;
            }
            state.seriesData = data;
            migrateWatchedEpisodesForMatchedSeries(state.seriesContinueEntry, seasons);
            if (state.seriesContinueEntry && state.seriesContinueEntry.seasonKey && seasons[state.seriesContinueEntry.seasonKey]) {
                renderSeriesSeason(state.seriesContinueEntry.seasonKey, true, state.seriesContinueEntry.episodeId);
            } else {
                renderSeriesSeason(seasonKeys[0], false);
            }
        });
    }

    function renderSeriesSeason(seasonKey, focusEpisode, targetEpisodeId) {
        var root = byId("content-root");
        var seasons = state.seriesData.episodes;
        var seasonKeys = [];
        var layout = document.createElement("div");
        var infoPanel = document.createElement("div");
        var selector = document.createElement("button");
        var selectorArrow = document.createElement("span");
        var seasonMenu = document.createElement("div");
        var episodes = document.createElement("div");
        var poster = document.createElement("div");
        var posterImage = document.createElement("img");
        var detailObjects = [state.seriesData ? state.seriesData.info : null, state.seriesItem];
        var seriesTitle = detailValue(detailObjects, ["name", "title"]) || safeName(state.seriesItem, "S\u00E9rie");
        var seriesPlot = detailValue(detailObjects, ["plot", "description"]) || "Sinopse n\u00E3o informada pela lista.";
        var seriesMeta = detailMetaHtml(detailObjects);
        var seriesDirector = detailValue(detailObjects, ["director"]);
        var seriesCast = detailValue(detailObjects, ["cast", "actors"]);
        var key;
        var i;
        var episode;
        var button;
        var row;
        var targetRow = null;
        var fallbackTargetRow = null;
        for (key in seasons) {
            if (seasons.hasOwnProperty(key)) { seasonKeys.push(key); }
        }
        seasonKeys.sort(function (a, b) { return parseInt(a, 10) - parseInt(b, 10); });
        state.seriesSeason = String(seasonKey);
        state.seriesSeasonMenuOpen = false;
        state.seriesFocusEpisodeId = String(targetEpisodeId || "");
        setPage("Detalhes da s\u00E9rie", "");
        layout.className = "series-detail-layout";
        infoPanel.className = "media-detail-content series-detail-content";
        infoPanel.innerHTML = "<h3>" + escapeDetailText(seriesTitle) + "</h3>" +
            detailStarsHtml(detailObjects) +
            (seriesMeta ? "<div class='detail-meta'>" + seriesMeta + "</div>" : "") +
            "<p class='detail-synopsis'>" + escapeDetailText(seriesPlot) + "</p>" +
            (seriesDirector ? "<div class='detail-extra'><b>Dire\u00E7\u00E3o:</b> " + escapeDetailText(seriesDirector) + "</div>" : "") +
            (seriesCast ? "<div class='detail-extra'><b>Elenco:</b> " + escapeDetailText(seriesCast) + "</div>" : "");
        selector.className = "series-season-selector" + (seasonKeys.length > 1 ? " focusable" : " single-season");
        if (seasonKeys.length > 1) { selector.setAttribute("data-action", "season-menu-toggle"); }
        selector.innerHTML = "Temporada " + state.seriesSeason;
        if (seasonKeys.length > 1) {
            selectorArrow.className = "series-season-arrow";
            selectorArrow.innerHTML = "&#9660;";
            selector.appendChild(selectorArrow);
        }
        seasonMenu.className = "series-season-menu hidden";
        seasonMenu.id = "series-season-menu";
        episodes.id = "series-episodes";
        episodes.className = "items-list series-episode-list";
        for (i = 0; i < seasonKeys.length; i += 1) {
            button = document.createElement("button");
            button.className = "series-season-option focusable";
            button.setAttribute("data-action", "season-option");
            button.setAttribute("data-season", seasonKeys[i]);
            button.innerHTML = "Temporada " + seasonKeys[i];
            if (String(seasonKeys[i]) === state.seriesSeason) {
                addClass(button, "active-season-option");
            }
            seasonMenu.appendChild(button);
        }
        for (i = 0; i < (seasons[seasonKey] || []).length; i += 1) {
            episode = seasons[seasonKey][i];
            row = document.createElement("div");
            row.className = "series-episode-card focusable";
            row.setAttribute("data-action", "episode");
            row._nexoEpisode = episode;
            row._nexoSeason = String(seasonKey);
            row._nexoEpisodeIndex = i;
            if (targetEpisodeId && contentId("episode", episode) === String(targetEpisodeId)) {
                targetRow = row;
                row._nexoResumeEntry = state.seriesContinueEntry;
            } else if (state.seriesContinueEntry && String(state.seriesContinueEntry.seasonKey || "") === String(seasonKey) &&
                    parseInt(state.seriesContinueEntry.episodeIndex, 10) === i) {
                fallbackTargetRow = row;
                row._nexoResumeEntry = state.seriesContinueEntry;
            }
            row.innerHTML = "<span class='series-episode-title'>Epis\u00F3dio " + formatEpisodeNumber(episode, i, false) + "</span>" +
                (isEpisodeWatched(state.seriesItem, episode) ? "<span class='episode-watched-mark'>&#10003;</span>" : "");
            episodes.appendChild(row);
        }
        if (!targetRow && fallbackTargetRow) { targetRow = fallbackTargetRow; }
        poster.className = "media-detail-poster series-detail-poster";
        posterImage.src = imageFor(state.seriesItem, "series");
        posterImage.alt = safeName(state.seriesItem, "S\u00E9rie");
        posterImage.onerror = function () { this.onerror = null; this.src = "images/nexo-symbol.png"; };
        poster.appendChild(posterImage);
        layout.appendChild(poster);
        layout.appendChild(infoPanel);
        layout.appendChild(selector);
        layout.appendChild(seasonMenu);
        layout.appendChild(episodes);
        root.innerHTML = "";
        root.appendChild(layout);
        if (focusEpisode && episodes.getElementsByClassName("focusable").length) {
            setFocus(targetRow || episodes.getElementsByClassName("focusable")[0]);
        } else if (seasonKeys.length > 1) {
            setFocus(selector);
        } else if (episodes.getElementsByClassName("focusable").length) {
            setFocus(episodes.getElementsByClassName("focusable")[0]);
        }
    }

    function toggleSeriesSeasonMenu() {
        var menu = byId("series-season-menu");
        var selector = byId("content-root") ? byId("content-root").getElementsByClassName("series-season-selector") : [];
        var options;
        var target = null;
        var i;
        if (!menu || !selector.length) { return; }
        state.seriesSeasonMenuOpen = !state.seriesSeasonMenuOpen;
        if (!state.seriesSeasonMenuOpen) {
            addClass(menu, "hidden");
            setFocus(selector[0]);
            return;
        }
        removeClass(menu, "hidden");
        options = menu.getElementsByClassName("series-season-option");
        for (i = 0; i < options.length; i += 1) {
            if (String(options[i].getAttribute("data-season") || "") === String(state.seriesSeason || "")) {
                target = options[i];
                break;
            }
        }
        if (target || options.length) { setFocus(target || options[0]); }
    }

    function seriesSeasonKeys() {
        var result = [];
        var seasons = state.seriesData && state.seriesData.episodes ? state.seriesData.episodes : {};
        var key;
        for (key in seasons) {
            if (seasons.hasOwnProperty(key)) { result.push(String(key)); }
        }
        result.sort(function (a, b) { return parseInt(a, 10) - parseInt(b, 10); });
        return result;
    }

    function findSeriesEpisodeContext(episode, seasonHint, indexHint) {
        var seasons = state.seriesData && state.seriesData.episodes ? state.seriesData.episodes : {};
        var keys = seriesSeasonKeys();
        var wantedId = contentId("episode", episode);
        var seasonKey = null;
        var episodeIndex = -1;
        var list;
        var i;
        var j;
        var nextEpisode = null;
        var nextSeasonKey = null;
        var nextEpisodeIndex = -1;
        if (seasonHint !== null && typeof seasonHint !== "undefined" && seasons[String(seasonHint)]) {
            list = seasons[String(seasonHint)] || [];
            if (typeof indexHint === "number" && list[indexHint] && contentId("episode", list[indexHint]) === wantedId) {
                seasonKey = String(seasonHint);
                episodeIndex = indexHint;
            }
        }
        if (seasonKey === null) {
            for (i = 0; i < keys.length && seasonKey === null; i += 1) {
                list = seasons[keys[i]] || [];
                for (j = 0; j < list.length; j += 1) {
                    if (list[j] === episode || contentId("episode", list[j]) === wantedId) {
                        seasonKey = keys[i];
                        episodeIndex = j;
                        break;
                    }
                }
            }
        }
        if (seasonKey !== null) {
            list = seasons[seasonKey] || [];
            if (episodeIndex + 1 < list.length) {
                nextEpisode = list[episodeIndex + 1];
                nextSeasonKey = seasonKey;
                nextEpisodeIndex = episodeIndex + 1;
            } else {
                for (i = 0; i < keys.length; i += 1) {
                    if (keys[i] === seasonKey && i + 1 < keys.length && (seasons[keys[i + 1]] || []).length) {
                        nextSeasonKey = keys[i + 1];
                        nextEpisode = seasons[nextSeasonKey][0];
                        nextEpisodeIndex = 0;
                        break;
                    }
                }
            }
        }
        return {
            episode: episode,
            seasonKey: seasonKey,
            episodeIndex: episodeIndex,
            nextEpisode: nextEpisode,
            nextSeasonKey: nextSeasonKey,
            nextEpisodeIndex: nextEpisodeIndex,
            isLast: seasonKey !== null && !nextEpisode
        };
    }

    function formatPlayerTime(value) {
        var seconds = Math.max(0, Math.floor(Number(value) || 0));
        var hours = Math.floor(seconds / 3600);
        var minutes = Math.floor((seconds % 3600) / 60);
        var rest = seconds % 60;
        if (hours > 0) {
            return hours + ":" + (minutes < 10 ? "0" : "") + minutes + ":" + (rest < 10 ? "0" : "") + rest;
        }
        return (minutes < 10 ? "0" : "") + minutes + ":" + (rest < 10 ? "0" : "") + rest;
    }

    function formatEpisodeNumber(episode, fallbackIndex, padded) {
        var value = parseInt(episode && episode.episode_num, 10);
        if (!isFinite(value) || value <= 0) { value = fallbackIndex + 1; }
        return (padded && value < 10 ? "0" : "") + value;
    }

    function updatePlayerTimeline() {
        var duration = state.playerDuration;
        var percent = duration > 0 ? Math.max(0, Math.min(100, state.playerCurrentTime * 100 / duration)) : 0;
        byId("player-current-time").innerHTML = formatPlayerTime(state.playerCurrentTime);
        byId("player-duration").innerHTML = duration > 0 ? formatPlayerTime(duration) : "--:--";
        byId("player-timeline-progress").style.width = percent + "%";
    }

    function playerDisplayModeInfo(mode) {
        var modes = [
            { value: "auto", label: "Autom\u00E1tico" },
            { value: "fullscreen", label: "Tela cheia" },
            { value: "standard", label: "4:3" },
            { value: "cinema", label: "Cinema" }
        ];
        var i;
        for (i = 0; i < modes.length; i += 1) {
            if (modes[i].value === mode) { return { modes: modes, index: i, current: modes[i] }; }
        }
        return { modes: modes, index: 0, current: modes[0] };
    }

    function updatePlayerFormatButton() {
        var info = playerDisplayModeInfo(state.playerDisplayMode);
        var button = byId("player-format-button");
        if (button) { button.innerHTML = "Formato: " + info.current.label; }
    }

    function cyclePlayerDisplayMode() {
        var info = playerDisplayModeInfo(state.playerDisplayMode);
        var next = info.modes[(info.index + 1) % info.modes.length];
        state.playerDisplayMode = next.value;
        Platform.setDisplayMode(state.playerDisplayMode);
        updatePlayerFormatButton();
        try { window.localStorage.setItem("nexo_player_display_mode", state.playerDisplayMode); } catch (ignoreDisplaySave) {}
        toast("Formato da imagem: " + next.label);
        resetPlayerPanelTimer();
    }

    function playerControlContains(element) {
        var root = byId("player-controls");
        var node = element;
        while (node && node !== document.body) {
            if (node === root) { return true; }
            node = node.parentNode;
        }
        return false;
    }

    function resetPlayerPanelTimer() {
        if (state.playerPanelTimer) { clearTimeout(state.playerPanelTimer); }
        state.playerPanelTimer = setTimeout(function () {
            hidePlayerPanel();
        }, state.playerType === "episode" ? 12000 : 8000);
    }

    function hidePlayerPanel() {
        if (state.playerPanelTimer) { clearTimeout(state.playerPanelTimer); }
        state.playerPanelTimer = null;
        state.playerPanelOpen = false;
        state.playerPanelSeasonMenuOpen = false;
        addClass(byId("player-season-menu"), "hidden");
        addClass(byId("player-controls"), "hidden");
        removeClass(byId("player-controls"), "series-controls-open");
        removeClass(byId("player-controls"), "format-controls-open");
        if (state.focusElement && playerControlContains(state.focusElement)) {
            removeClass(state.focusElement, "focused");
            state.focusElement = null;
        }
    }

    function renderPlayerSeriesControls(seasonKey, focusFirstEpisode) {
        var seasons = state.seriesData && state.seriesData.episodes ? state.seriesData.episodes : {};
        var keys = seriesSeasonKeys();
        var nextRoot = byId("player-next-control");
        var seasonRoot = byId("player-season-controls");
        var seasonMenu = byId("player-season-menu");
        var episodeRoot = byId("player-episode-controls");
        var context = state.playerEpisodeContext;
        var episodeList;
        var button;
        var currentButton = null;
        var firstEpisodeButton = null;
        var i;
        seasonKey = seasons[String(seasonKey)] ? String(seasonKey) : (context && context.seasonKey ? context.seasonKey : keys[0]);
        state.playerPanelSeason = seasonKey;
        state.playerPanelSeasonMenuOpen = false;
        nextRoot.innerHTML = "";
        seasonRoot.innerHTML = "";
        seasonMenu.innerHTML = "";
        episodeRoot.innerHTML = "";
        addClass(seasonMenu, "hidden");
        removeClass(seasonRoot, "hidden");
        button = document.createElement("button");
        button.className = "player-control-button player-season-selector" + (keys.length > 1 ? " focusable" : " single-season");
        if (keys.length > 1) { button.setAttribute("data-action", "player-season-menu-toggle"); }
        button.innerHTML = "Temporada " + seasonKey + (keys.length > 1 ? " <span>&#9660;</span>" : "");
        seasonRoot.appendChild(button);
        for (i = 0; i < keys.length; i += 1) {
            button = document.createElement("button");
            button.className = "player-season-option focusable";
            button.setAttribute("data-action", "player-season-option");
            button.setAttribute("data-season", keys[i]);
            button.innerHTML = "Temporada " + keys[i];
            if (keys[i] === seasonKey) { addClass(button, "active-player-season"); }
            seasonMenu.appendChild(button);
        }
        if (context && context.nextEpisode) {
            removeClass(nextRoot, "hidden");
            button = document.createElement("button");
            button.className = "player-control-button player-next-button focusable";
            button.setAttribute("data-action", "player-next");
            button._nexoEpisode = context.nextEpisode;
            button._nexoSeason = context.nextSeasonKey;
            button._nexoEpisodeIndex = context.nextEpisodeIndex;
            button.innerHTML = "Pr\u00F3ximo: Ep " + formatEpisodeNumber(context.nextEpisode, context.nextEpisodeIndex, true);
            nextRoot.appendChild(button);
        } else {
            addClass(nextRoot, "hidden");
        }
        episodeList = seasons[seasonKey] || [];
        for (i = 0; i < episodeList.length; i += 1) {
            button = document.createElement("button");
            button.className = "player-control-button focusable";
            button.setAttribute("data-action", "player-episode");
            button._nexoEpisode = episodeList[i];
            button._nexoSeason = seasonKey;
            button._nexoEpisodeIndex = i;
            button.innerHTML = "Ep " + formatEpisodeNumber(episodeList[i], i, true) +
                (isEpisodeWatched(state.seriesItem, episodeList[i]) ? " <span class='player-watched-mark'>&#10003;</span>" : "");
            if (!firstEpisodeButton) { firstEpisodeButton = button; }
            if (context && contentId("episode", context.episode) === contentId("episode", episodeList[i])) {
                addClass(button, "current-episode");
                currentButton = button;
            }
            episodeRoot.appendChild(button);
        }
        if (focusFirstEpisode && firstEpisodeButton) {
            setFocus(firstEpisodeButton);
        } else if (currentButton) {
            setFocus(currentButton);
        } else if (firstEpisodeButton) {
            setFocus(firstEpisodeButton);
        }
    }

    function togglePlayerSeasonMenu() {
        var menu = byId("player-season-menu");
        var selectors = byId("player-season-controls").getElementsByClassName("player-season-selector");
        var options;
        var target = null;
        var i;
        if (!menu || !selectors.length || hasClass(selectors[0], "single-season")) { return; }
        state.playerPanelSeasonMenuOpen = !state.playerPanelSeasonMenuOpen;
        if (!state.playerPanelSeasonMenuOpen) {
            addClass(menu, "hidden");
            setFocus(selectors[0]);
            return;
        }
        removeClass(menu, "hidden");
        options = menu.getElementsByClassName("player-season-option");
        for (i = 0; i < options.length; i += 1) {
            if (String(options[i].getAttribute("data-season") || "") === String(state.playerPanelSeason || "")) {
                target = options[i];
                break;
            }
        }
        if (target || options.length) { setFocus(target || options[0]); }
    }

    function movePlayerSeasonMenuFocus(direction) {
        var menu = byId("player-season-menu");
        var options = menu ? menu.getElementsByClassName("player-season-option") : [];
        var index = -1;
        var i;
        for (i = 0; i < options.length; i += 1) {
            if (options[i] === state.focusElement) { index = i; break; }
        }
        if (index < 0 && options.length) { setFocus(options[0]); return; }
        if (direction === "up" && index > 0) { setFocus(options[index - 1]); }
        else if (direction === "down" && index + 1 < options.length) { setFocus(options[index + 1]); }
    }

    function showPlayerPanel() {
        var timeline = byId("player-timeline");
        state.playerPanelOpen = true;
        state.playerPanelSeasonMenuOpen = false;
        addClass(byId("player-osd"), "hidden");
        removeClass(byId("player-controls"), "hidden");
        addClass(byId("player-season-menu"), "hidden");
        byId("player-controls-title").innerHTML = byId("player-title").innerHTML;
        updatePlayerTimeline();
        if (state.playerType === "live" || state.playerType === "movie" || state.playerType === "episode") {
            addClass(byId("player-controls"), "format-controls-open");
            removeClass(byId("player-format-controls"), "hidden");
            updatePlayerFormatButton();
        } else {
            removeClass(byId("player-controls"), "format-controls-open");
            addClass(byId("player-format-controls"), "hidden");
        }
        if (state.playerType === "episode" && state.seriesData) {
            addClass(byId("player-controls"), "series-controls-open");
            removeClass(byId("player-series-controls"), "hidden");
            renderPlayerSeriesControls(state.playerEpisodeContext ? state.playerEpisodeContext.seasonKey : state.seriesSeason, false);
        } else {
            removeClass(byId("player-controls"), "series-controls-open");
            addClass(byId("player-series-controls"), "hidden");
            addClass(byId("player-season-controls"), "hidden");
            addClass(byId("player-next-control"), "hidden");
        }
        if (timeline) { setFocus(timeline); }
        resetPlayerPanelTimer();
    }

    function seekPlayer(seconds) {
        var nextTime = Math.max(0, state.playerCurrentTime + seconds);
        if (state.playerDuration > 0) { nextTime = Math.min(state.playerDuration - 1, nextTime); }
        if (Platform.seek(seconds)) {
            state.playerCurrentTime = nextTime;
            updatePlayerTimeline();
        }
        if (state.playerPanelOpen) { resetPlayerPanelTimer(); }
        else { showPlayerPanel(); }
    }

    function applyPlayerResume() {
        var delta;
        if (state.playerResumeApplied || state.playerResumeTime < 5) { return; }
        state.playerResumeApplied = true;
        delta = state.playerResumeTime - state.playerCurrentTime;
        if (Math.abs(delta) < 2 || Platform.seek(delta)) {
            state.playerCurrentTime = state.playerResumeTime;
            updatePlayerTimeline();
        }
    }

    function updatePlayerTime(current, duration) {
        if (typeof current === "number" && isFinite(current)) { state.playerCurrentTime = Math.max(0, current); }
        if (typeof duration === "number" && isFinite(duration) && duration > 0) { state.playerDuration = duration; }
        updatePlayerTimeline();
        if (state.playerType === "episode" && state.recentRecorded && state.playerDuration > 0 &&
                state.playerCurrentTime > 0 && state.playerDuration - state.playerCurrentTime <= 90) {
            prepareNextEpisodeContinue();
        }
        if (state.recentRecorded && Math.abs(state.playerCurrentTime - state.recentLastSavedTime) >= 15) {
            recordContinueNow();
        }
    }

    function playNextEpisodeAutomatically(context) {
        var nextEpisode;
        var nextSeasonKey;
        var nextEpisodeIndex;
        var nextTitle;
        if (!context || !context.nextEpisode || state.playerAutoAdvancePending) { return; }
        nextEpisode = context.nextEpisode;
        nextSeasonKey = context.nextSeasonKey;
        nextEpisodeIndex = context.nextEpisodeIndex;
        nextTitle = "Epis\u00F3dio " + formatEpisodeNumber(nextEpisode, nextEpisodeIndex, false);
        state.playerAutoAdvancePending = true;
        hidePlayerPanel();
        removeClass(byId("player-loading"), "hidden");
        removeClass(byId("player-osd"), "hidden");
        byId("player-title").innerHTML = "Carregando " + nextTitle + "...";
        byId("player-controls-title").innerHTML = byId("player-title").innerHTML;
        if (state.playerAutoAdvanceTimer) { clearTimeout(state.playerAutoAdvanceTimer); }
        state.playerAutoAdvanceTimer = setTimeout(function () {
            state.playerAutoAdvanceTimer = null;
            if (!state.playerOpen || state.playerType !== "episode" ||
                    state.playerEpisodeContext !== context) {
                state.playerAutoAdvancePending = false;
                return;
            }
            state.playerAutoAdvancePending = false;
            playItem("episode", nextEpisode, nextTitle, null, {
                seasonKey: nextSeasonKey,
                episodeIndex: nextEpisodeIndex
            });
        }, 150);
    }

    function clearPlayerReconnectTimer() {
        if (state.playerReconnectTimer) { clearTimeout(state.playerReconnectTimer); }
        state.playerReconnectTimer = null;
    }

    function markPlayerReconnected() {
        clearPlayerReconnectTimer();
        state.playerReconnectAttempts = 0;
        state.playerReconnectReason = "";
        if (state.playerTitle) {
            byId("player-title").innerHTML = state.playerTitle;
            byId("player-controls-title").innerHTML = state.playerTitle;
        }
    }

    function playerEndedNaturally() {
        var remaining;
        var tolerance;
        if (state.playerType === "live" || state.playerDuration <= 0) { return false; }
        remaining = Math.max(0, state.playerDuration - state.playerCurrentTime);
        tolerance = state.playerType === "episode" ? 90 : 30;
        return remaining <= tolerance;
    }

    function schedulePlayerReconnect(reason) {
        var type;
        var item;
        var title;
        var resumeTime;
        var episodeMeta;
        var token;
        var delay;
        if (!state.playerOpen || !state.playerItem || state.playerReconnectTimer) { return; }
        type = state.playerType;
        item = state.playerItem;
        title = state.playerTitle || safeName(item, "Reproduzindo");
        resumeTime = type === "live" ? 0 : Math.max(0, state.playerCurrentTime - 2);
        episodeMeta = state.playerEpisodeContext ? {
            seasonKey: state.playerEpisodeContext.seasonKey,
            episodeIndex: state.playerEpisodeContext.episodeIndex
        } : null;
        token = state.playerToken;
        state.playerReconnectAttempts += 1;
        state.playerReconnectReason = reason || "Transmissão interrompida";
        delay = Math.min(8000, 1000 + ((state.playerReconnectAttempts - 1) * 1500));
        removeClass(byId("player-loading"), "hidden");
        removeClass(byId("player-osd"), "hidden");
        byId("player-title").innerHTML = type === "live" ? "Reconectando canal..." : "Reconectando vídeo...";
        byId("player-controls-title").innerHTML = byId("player-title").innerHTML;
        state.playerReconnectTimer = setTimeout(function () {
            state.playerReconnectTimer = null;
            if (!state.playerOpen || token !== state.playerToken) { return; }
            playItem(type, item, title, type === "live" ? null : { currentTime: resumeTime }, episodeMeta, true);
        }, delay);
    }

    function handlePlayerEnded() {
        if (!playerEndedNaturally()) {
            schedulePlayerReconnect("Fluxo encerrado antes do fim");
            return;
        }
        if (state.playerType === "movie" && state.playerItem) {
            removeRecentItem("movie", state.playerItem);
            stopPlayer(true);
            return;
        }
        if (state.playerType === "episode" && state.seriesItem && state.playerEpisodeContext) {
            markEpisodeWatched(state.playerEpisodeContext);
            if (state.playerEpisodeContext.nextEpisode) {
                if (!state.playerAdvancePrepared) { prepareNextEpisodeContinue(); }
                playNextEpisodeAutomatically(state.playerEpisodeContext);
                return;
            } else {
                removeRecentItem("series", state.seriesItem);
            }
            stopPlayer(true);
            return;
        }
        stopPlayer(false);
    }

    function playItem(type, item, title, resumeEntry, episodeMeta, reconnecting) {
        var url = type === "episode" ? NexoApi.episodeUrl(state.session, item) : NexoApi.streamUrl(state.session, type, item);
        var replacingPlayer = state.playerOpen;
        var activeMigration = state.recentMigration;
        var token;
        clearPlayerReconnectTimer();
        if (!reconnecting) {
            state.playerReconnectAttempts = 0;
            state.playerReconnectReason = "";
        }
        if (state.playerAutoAdvanceTimer) { clearTimeout(state.playerAutoAdvanceTimer); }
        state.playerAutoAdvanceTimer = null;
        state.playerAutoAdvancePending = false;
        state.playerToken += 1;
        token = state.playerToken;
        if (replacingPlayer) {
            recordContinueNow();
            Platform.stop();
        } else {
            state.playerReturnFocus = state.focusElement;
        }
        cancelRecentTimer();
        hidePlayerPanel();
        state.playerType = type;
        state.playerItem = item;
        state.playerEpisodeContext = type === "episode" ? findSeriesEpisodeContext(item,
            episodeMeta ? episodeMeta.seasonKey : null, episodeMeta ? episodeMeta.episodeIndex : -1) : null;
        if (type === "episode" && state.playerReturnSeriesContext && state.playerEpisodeContext) {
            state.playerReturnSeriesContext = {
                seasonKey: state.playerEpisodeContext.seasonKey,
                episodeId: contentId("episode", item)
            };
        }
        state.playerCurrentTime = 0;
        state.playerDuration = 0;
        state.playerResumeTime = resumeEntry ? Math.max(0, Number(resumeEntry.currentTime) || 0) : 0;
        state.playerResumeApplied = false;
        state.playerAdvancePrepared = false;
        if (type === "movie") {
            state.recentPending = { type: "movie", item: compactItem(item) };
        } else if (type === "episode" && state.seriesItem) {
            state.recentPending = { type: "series", item: compactItem(state.seriesItem) };
        }
        if (resumeEntry && resumeEntry._nexoMigration) {
            state.recentMigration = {
                oldKey: resumeEntry._nexoMigration.oldKey,
                newKey: resumeEntry._nexoMigration.newKey
            };
        } else if (type === "episode" && activeMigration) {
            state.recentMigration = activeMigration;
        }
        state.playerOpen = true;
        state.playerTitle = title || safeName(item, "Reproduzindo");
        setScreen("player");
        Platform.setDisplayMode(state.playerDisplayMode);
        byId("player-title").innerHTML = state.playerTitle;
        byId("player-controls-title").innerHTML = byId("player-title").innerHTML;
        updatePlayerTimeline();
        removeClass(byId("player-loading"), "hidden");
        removeClass(byId("player-osd"), "hidden");
        if (state.loadingTimer) { clearTimeout(state.loadingTimer); }
        state.loadingTimer = setTimeout(function () {
            if (token === state.playerToken) { addClass(byId("player-loading"), "hidden"); }
        }, 6000);
        Platform.play(url, {
            bufferingStart: function () {
                if (token === state.playerToken) { removeClass(byId("player-loading"), "hidden"); }
            },
            bufferingComplete: function () {
                if (token !== state.playerToken) { return; }
                markPlayerReconnected();
                addClass(byId("player-loading"), "hidden");
                startRecentTimer();
                applyPlayerResume();
            },
            ready: function () {
                if (token !== state.playerToken) { return; }
                markPlayerReconnected();
                addClass(byId("player-loading"), "hidden");
                startRecentTimer();
                applyPlayerResume();
            },
            time: function (current, duration) {
                if (token === state.playerToken) { updatePlayerTime(current, duration); }
            },
            duration: function (duration) {
                if (token === state.playerToken) { updatePlayerTime(state.playerCurrentTime, duration); }
            },
            ended: function () {
                if (token === state.playerToken) { handlePlayerEnded(); }
            },
            error: function (message) {
                if (token !== state.playerToken) { return; }
                cancelRecentTimer();
                schedulePlayerReconnect(message);
            }
        });
        setTimeout(function () {
            if (token === state.playerToken && !state.playerPanelOpen) { addClass(byId("player-osd"), "hidden"); }
        }, 4500);
    }

    function stopPlayer(skipContinueSave) {
        var returnSeriesContext = state.playerReturnSeriesContext;
        clearPlayerReconnectTimer();
        if (state.playerAutoAdvanceTimer) { clearTimeout(state.playerAutoAdvanceTimer); }
        state.playerAutoAdvanceTimer = null;
        state.playerAutoAdvancePending = false;
        if (!skipContinueSave) { recordContinueNow(); }
        state.playerToken += 1;
        Platform.stop();
        cancelRecentTimer();
        hidePlayerPanel();
        state.playerOpen = false;
        state.playerType = null;
        state.playerItem = null;
        state.playerTitle = "";
        state.playerReconnectAttempts = 0;
        state.playerReconnectReason = "";
        state.playerEpisodeContext = null;
        state.playerResumeTime = 0;
        state.playerAdvancePrepared = false;
        setScreen("main");
        state.playerReturnSeriesContext = null;
        if (returnSeriesContext && state.seriesData && state.seriesData.episodes) {
            state.seriesOpen = true;
            state.seriesContinueEntry = findSeriesContinueEntry(state.seriesItem);
            renderSeriesSeason(returnSeriesContext.seasonKey, true, returnSeriesContext.episodeId);
            return;
        }
        if (state.playerReturnFocus && visible(state.playerReturnFocus)) {
            setFocus(state.playerReturnFocus);
        } else {
            focusFirst();
        }
    }

    function setModalClass(extraClass) {
        byId("modal").className = "modal" + (extraClass ? " " + extraClass : "");
    }

    function updateParentalPinDisplay() {
        var display = byId("parental-pin-display");
        var html = "";
        var i;
        if (!display) { return; }
        for (i = 0; i < 4; i += 1) {
            html += "<span class='parental-pin-cell" + (i < state.parentalPinValue.length ? " filled" : "") +
                (i === Math.min(state.parentalPinValue.length, 3) ? " current" : "") + "'>" +
                (i < state.parentalPinValue.length ? "&#9679;" : "") + "</span>";
        }
        display.innerHTML = html;
    }

    function renderParentalPinModal(title, message) {
        var content = byId("modal-content");
        var display = document.createElement("div");
        var keypad = document.createElement("div");
        var actions = document.createElement("div");
        var order = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
        var i;
        var button;
        setModalClass("parental-pin-modal");
        byId("modal-title").innerHTML = title;
        byId("modal-message").innerHTML = message || "Digite os 4 d\u00EDgitos";
        content.innerHTML = "";
        display.id = "parental-pin-display";
        display.className = "parental-pin-display";
        keypad.className = "parental-keypad";
        for (i = 0; i < order.length; i += 1) {
            button = document.createElement("button");
            button.className = "parental-key focusable";
            button.setAttribute("data-action", "parental-digit");
            button.setAttribute("data-digit", order[i]);
            button.innerHTML = order[i];
            keypad.appendChild(button);
        }
        actions.className = "parental-pin-actions";
        actions.innerHTML = "<button class='parental-action-button focusable' data-action='parental-backspace'>Apagar</button>" +
            "<button class='parental-action-button focusable' data-action='parental-clear'>Limpar</button>" +
            "<button class='parental-action-button focusable' data-action='parental-pin-submit'>Confirmar</button>" +
            "<button class='parental-action-button focusable' data-action='modal-close'>Fechar</button>";
        content.appendChild(display);
        content.appendChild(keypad);
        content.appendChild(actions);
        updateParentalPinDisplay();
        focusFirst();
    }

    function openParentalPin(message, success) {
        if (!state.modalOpen) { state.modalReturnFocus = state.focusElement; }
        state.modalOpen = true;
        state.parentalModalView = "pin";
        state.parentalPinMode = "verify";
        state.parentalPinValue = "";
        state.parentalPinSuccess = success || null;
        loadParentalSettings();
        removeClass(byId("modal-backdrop"), "hidden");
        renderParentalPinModal("Controle parental", message || "Digite o PIN de 4 d\u00EDgitos");
    }

    function appendParentalDigit(digit) {
        if (!state.parentalPinMode || state.parentalPinValue.length >= 4) { return; }
        state.parentalPinValue += String(digit);
        updateParentalPinDisplay();
        if (state.parentalPinValue.length === 4) {
            setTimeout(function () { submitParentalPin(); }, 120);
        }
    }

    function submitParentalPin() {
        var callback;
        if (!state.parentalPinMode || state.parentalPinValue.length !== 4) {
            byId("modal-message").innerHTML = "Digite os 4 d\u00EDgitos";
            return;
        }
        if (state.parentalPinMode === "verify") {
            if (state.parentalPinValue !== String((state.parentalSettings || loadParentalSettings()).pin)) {
                state.parentalPinValue = "";
                byId("modal-message").innerHTML = "PIN incorreto. Tente novamente.";
                updateParentalPinDisplay();
                return;
            }
            callback = state.parentalPinSuccess;
            state.parentalPinSuccess = null;
            closeModal();
            if (callback) { callback(); }
            return;
        }
        if (state.parentalPinMode === "new") {
            state.parentalNewPin = state.parentalPinValue;
            state.parentalPinValue = "";
            state.parentalPinMode = "confirm";
            renderParentalPinModal("Confirmar novo PIN", "Digite novamente o novo PIN");
            return;
        }
        if (state.parentalPinMode === "confirm") {
            if (state.parentalPinValue !== state.parentalNewPin) {
                state.parentalPinValue = "";
                byId("modal-message").innerHTML = "Os n\u00FAmeros n\u00E3o conferem. Digite novamente.";
                updateParentalPinDisplay();
                return;
            }
            state.parentalSettings.pin = state.parentalNewPin;
            saveParentalSettings();
            closeModal();
            toast("PIN alterado");
            openParentalSettings();
        }
    }

    function openChangeParentalPin() {
        state.parentalModalView = "pin";
        state.parentalPinMode = "new";
        state.parentalPinValue = "";
        state.parentalNewPin = "";
        renderParentalPinModal("Alterar PIN", "Digite o novo PIN de 4 d\u00EDgitos");
    }

    function parentalTypeLabel(type) {
        return type === "live" ? "TV ao vivo" : (type === "movie" ? "Filmes" : "S\u00E9ries");
    }

    function renderParentalSettings(focusCategories, focusCategoryId) {
        var content = byId("modal-content");
        var actions = document.createElement("div");
        var tabs = document.createElement("div");
        var grid = document.createElement("div");
        var types = ["live", "movie", "series"];
        var type = state.parentalCategoryType || "live";
        var categories = state.parentalCategories[type];
        var button;
        var category;
        var blocked;
        var adult;
        var focusTarget = null;
        var i;
        setModalClass("parental-settings-modal");
        byId("modal-title").innerHTML = "Controle parental";
        byId("modal-message").innerHTML = "Escolha as categorias que exigir\u00E3o PIN. Conte\u00FAdo adulto fica sempre protegido.";
        content.innerHTML = "";
        actions.className = "parental-settings-actions";
        actions.innerHTML = "<button class='parental-action-button focusable' data-action='parental-change-pin'>Alterar PIN</button>" +
            "<button class='parental-action-button focusable' data-action='modal-close'>Fechar</button>";
        tabs.className = "parental-type-tabs";
        for (i = 0; i < types.length; i += 1) {
            button = document.createElement("button");
            button.className = "parental-type-button focusable" + (types[i] === type ? " active-parental-type" : "");
            button.setAttribute("data-action", "parental-type");
            button.setAttribute("data-type", types[i]);
            button.innerHTML = parentalTypeLabel(types[i]);
            tabs.appendChild(button);
            if (types[i] === type) { focusTarget = button; }
        }
        grid.id = "parental-category-grid";
        grid.className = "parental-category-grid";
        content.appendChild(actions);
        content.appendChild(tabs);
        content.appendChild(grid);
        if (categories === null) {
            grid.innerHTML = "<div class='parental-loading'>Carregando categorias...</div>";
            setFocus(focusTarget);
            requestCatalogCategories(type, function (error, loaded) {
                if (!state.modalOpen || state.parentalModalView !== "settings" || state.parentalCategoryType !== type) { return; }
                state.parentalCategories[type] = error ? [] : (loaded || []);
                rememberCategoryNames(type, state.parentalCategories[type]);
                renderParentalSettings(true, focusCategoryId);
                if (error) { toast("N\u00E3o foi poss\u00EDvel carregar as categorias"); }
            });
            return;
        }
        if (!categories.length) {
            grid.innerHTML = "<div class='parental-loading'>Nenhuma categoria dispon\u00EDvel</div>";
        }
        for (i = 0; i < categories.length; i += 1) {
            category = {
                type: type,
                id: String(categories[i].category_id || ""),
                name: categories[i].category_name || ("Categoria " + (i + 1))
            };
            adult = isAdultCategoryName(category.name);
            blocked = isCategoryBlocked(type, category.id, category.name);
            button = document.createElement("button");
            button.className = "parental-category-button focusable" + (blocked ? " parental-blocked" : "");
            button.setAttribute("data-action", "parental-toggle");
            button._nexoCategory = category;
            button.innerHTML = "<span class='parental-lock-state'>" + (blocked ? "&#9679;" : "&#9675;") + "</span>" +
                "<span class='parental-category-name'>" + category.name + "</span>" +
                (adult ? "<small>Sempre protegido</small>" : "<small>" + (blocked ? "Bloqueado" : "Livre") + "</small>");
            grid.appendChild(button);
            if (focusCategoryId && category.id === String(focusCategoryId)) { focusTarget = button; }
            else if (focusCategories && !focusCategoryId && i === 0) { focusTarget = button; }
        }
        setFocus(focusTarget);
    }

    function openParentalSettings() {
        if (!state.modalOpen) { state.modalReturnFocus = state.focusElement; }
        state.modalOpen = true;
        state.parentalModalView = "settings";
        state.parentalPinMode = "";
        state.parentalCategoryType = state.parentalCategoryType || "live";
        removeClass(byId("modal-backdrop"), "hidden");
        renderParentalSettings(false);
    }

    function openParentalControl() {
        openParentalPin("Digite o PIN para abrir as configura\u00E7\u00F5es", function () {
            openParentalSettings();
        });
    }

    function openServers() {
        var content = byId("modal-content");
        var sources = state.codeEntry ? state.codeEntry.fontes || [] : [];
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        setModalClass("server-picker-modal");
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = "Servidores";
        byId("modal-message").innerHTML = "Escolha uma fonte e depois o servidor";
        content.innerHTML = "";
        state.serverModalSourceIndex = state.session && state.session.server ? (state.session.server.sourceIndex || 0) : 0;
        renderServerPicker(content, sources, state.serverModalSourceIndex, false);
    }

    function renderServerPicker(content, sources, selectedIndex, focusServers) {
        var tabs = document.createElement("div");
        var grid = document.createElement("div");
        var actions = document.createElement("div");
        var i;
        var j;
        var button;
        var servers;
        var selectedSource;
        var currentHost = state.session && state.session.server ? String(state.session.server.serverHost || "").replace(/\/+$/, "") : "";
        var firstServerButton = null;
        var activeSourceButton = null;
        if (!sources.length) {
            content.innerHTML = "<div class='server-empty-state'>Nenhuma fonte dispon\u00EDvel</div>";
            actions.className = "server-actions";
            actions.innerHTML = "<button class='server-refresh-button focusable' data-action='server-refresh'>Atualizar servidor atual</button>" +
                "<button class='server-refresh-button focusable' data-action='server-auto-update'>Atualizar autom\u00E1tico</button>";
            content.appendChild(actions);
            focusFirst();
            return;
        }
        selectedIndex = Math.max(0, Math.min(sources.length - 1, parseInt(selectedIndex, 10) || 0));
        state.serverModalSourceIndex = selectedIndex;
        tabs.className = "server-source-tabs";
        grid.className = "server-grid";
        content.innerHTML = "";
        for (i = 0; i < sources.length; i += 1) {
            button = document.createElement("button");
            button.className = "server-source-button focusable" + (i === selectedIndex ? " active-source" : "");
            button.setAttribute("data-action", "server-source");
            button.setAttribute("data-source-index", i);
            button.innerHTML = sources[i].nomeFonte || ("Fonte " + (i + 1));
            tabs.appendChild(button);
            if (i === selectedIndex) { activeSourceButton = button; }
        }
        selectedSource = sources[selectedIndex];
        servers = selectedSource.servidores || [];
        for (j = 0; j < servers.length; j += 1) {
            button = document.createElement("button");
            button.className = "modal-button focusable";
            button.setAttribute("data-action", "server-select");
            button._nexoServer = {
                sourceName: selectedSource.nomeFonte,
                sourceIndex: selectedIndex,
                serverIndex: j,
                serverName: servers[j].serverName,
                serverHost: servers[j].serverHost
            };
            if (currentHost && currentHost === String(servers[j].serverHost || "").replace(/\/+$/, "")) {
                button.innerHTML = "<span class='server-current-dot'></span>" + servers[j].serverName;
            } else {
                button.innerHTML = servers[j].serverName;
            }
            grid.appendChild(button);
            if (!firstServerButton) { firstServerButton = button; }
        }
        if (!servers.length) {
            grid.innerHTML = "<div class='empty-state'>Nenhum servidor nesta fonte</div>";
        }
        content.appendChild(tabs);
        content.appendChild(grid);
        actions.className = "server-actions";
        actions.innerHTML = "<button class='server-refresh-button focusable' data-action='server-refresh'>Atualizar servidor atual</button>" +
            "<button class='server-refresh-button focusable' data-action='server-auto-update'>Atualizar autom\u00E1tico</button>";
        content.appendChild(actions);
        if (focusServers && firstServerButton) { setFocus(firstServerButton); }
        else if (activeSourceButton) { setFocus(activeSourceButton); }
    }

    function openCatalogAutoUpdate() {
        var content = byId("modal-content");
        var list = document.createElement("div");
        var button;
        var selected = null;
        var i;
        state.modalOpen = true;
        setModalClass("auto-update-modal");
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = "Atualiza\u00E7\u00E3o autom\u00E1tica";
        byId("modal-message").innerHTML = "Escolha o intervalo. A atualiza\u00E7\u00E3o acontece ao abrir o app depois da meia-noite do dia previsto.";
        content.innerHTML = "";
        list.className = "auto-update-list";
        for (i = 1; i <= 7; i += 1) {
            button = document.createElement("button");
            button.className = "modal-button auto-update-option focusable" + (i === state.catalogUpdateDays ? " active-option" : "");
            button.setAttribute("data-action", "catalog-update-days");
            button.setAttribute("data-days", i);
            button.innerHTML = i === 1 ? "A cada 1 dia" : ("A cada " + i + " dias");
            list.appendChild(button);
            if (i === state.catalogUpdateDays) { selected = button; }
        }
        content.appendChild(list);
        setFocus(selected || list.getElementsByClassName("focusable")[0]);
    }

    function chooseServer(server) {
        showLoading("Conectando em " + server.serverName + "...");
        NexoApi.checkServer(server, state.session.username, state.session.password, function (error, account) {
            hideLoading();
            if (error) {
                toast("Servidor indispon\u00EDvel");
                return;
            }
            state.session.server = server;
            state.session.account = account;
            state.parentalCategories = { live: null, movie: null, series: null };
            state.parentalCategoryNames = { live: {}, movie: {}, series: {} };
            resetLatestCatalogCache(server.serverHost);
            saveSession();
            updateServerInfo();
            closeModal();
            scheduleLatestCatalogPrefetch(true, function () { openCatalog("live"); });
            toast("Conectado em " + server.serverName);
        });
    }

    function refreshCurrentServer(closePicker) {
        var returnType;
        var returnCategory;
        var returnSeries;
        var wasSeriesOpen;
        if (!state.session || !state.session.server) { return; }
        returnType = state.currentType || "live";
        returnCategory = state.currentCategory || "";
        returnSeries = state.seriesItem;
        wasSeriesOpen = state.seriesOpen;
        if (closePicker && state.modalOpen) { closeModal(); }
        showLoading("Atualizando " + state.session.server.serverName + "...");
        NexoApi.checkServer(state.session.server, state.session.username, state.session.password, function (error, account) {
            hideLoading();
            if (error) {
                toast("Servidor indispon\u00EDvel");
                return;
            }
            state.session.account = account;
            state.parentalCategories = { live: null, movie: null, series: null };
            state.parentalCategoryNames = { live: {}, movie: {}, series: {} };
            resetLatestCatalogCache(currentServerHost());
            saveSession();
            updateServerInfo();
            scheduleLatestCatalogPrefetch(true, function () {
                if (wasSeriesOpen && returnSeries) {
                    openSeries(returnSeries);
                } else if (returnType === "favorites" || returnType === "recent") {
                    openSavedList(returnType);
                } else if (returnType === "live" || returnType === "movie" || returnType === "series") {
                    openCatalog(returnType, returnCategory);
                } else {
                    openCatalog("live");
                }
            });
            toast("Conte\u00FAdo atualizado");
        });
    }

    function confirmModal(title, message, yesAction) {
        var content = byId("modal-content");
        var yes = document.createElement("button");
        var no = document.createElement("button");
        var icon;
        var removeConfirmation = yesAction === "recent-delete-confirm" || yesAction === "favorite-delete-confirm" ||
            yesAction === "saved-server-switch-confirm";
        state.modalReturnFocus = state.focusElement;
        state.modalOpen = true;
        setModalClass(yesAction === "exit-confirm" ? "exit-confirm-modal" :
            (removeConfirmation ? "remove-confirm-modal" : "confirm-modal"));
        removeClass(byId("modal-backdrop"), "hidden");
        byId("modal-title").innerHTML = title;
        byId("modal-message").innerHTML = message;
        content.innerHTML = "";
        yes.className = "modal-button focusable";
        yes.setAttribute("data-action", yesAction);
        yes.innerHTML = "Sim";
        no.className = "modal-button focusable";
        no.setAttribute("data-action", "modal-close");
        no.innerHTML = "N\u00E3o";
        if (yesAction === "exit-confirm") {
            icon = document.createElement("img");
            icon.className = "exit-modal-icon";
            icon.src = "images/menu/sair-da-conta.png";
            icon.alt = "";
            content.appendChild(icon);
            content.appendChild(no);
            content.appendChild(yes);
        } else if (removeConfirmation) {
            content.appendChild(no);
            content.appendChild(yes);
        } else {
            content.appendChild(yes);
            content.appendChild(no);
        }
        focusFirst();
    }

    function closeModal() {
        var returnFocus = state.modalReturnFocus;
        state.modalOpen = false;
        addClass(byId("modal-backdrop"), "hidden");
        setModalClass("");
        byId("modal-content").innerHTML = "";
        state.modalReturnFocus = null;
        state.loginKeyboardField = null;
        state.loginKeyboardValue = "";
        state.parentalModalView = "";
        state.parentalPinMode = "";
        state.parentalPinValue = "";
        state.parentalNewPin = "";
        state.parentalPinSuccess = null;
        state.pendingRecentDelete = null;
        state.pendingFavoriteRemove = null;
        state.pendingSavedServerOpen = null;
        if (returnFocus && visible(returnFocus)) {
            setFocus(returnFocus);
        } else {
            focusFirst();
        }
    }

    function activate(element) {
        var action;
        var field;
        var category;
        var pendingEntry;
        var pendingServerOpen;
        var oldCount;
        var rendered;
        if (!element) { return; }
        action = element.getAttribute("data-action");
        if (action === "login-field") {
            field = element.getAttribute("data-field");
            state.loginField = field;
            if (field === "code") { setFocus(byId("login-user")); }
            else { openLoginKeyboard(field); }
        } else if (action === "login-submit") {
            login(false);
        } else if (action === "search") {
            openSearch();
        } else if (action === "favorites") {
            state.favoriteOpenType = null;
            openSavedList("favorites");
        } else if (action === "favorite-group-toggle") {
            field = element.getAttribute("data-favorite-type") || "";
            state.favoriteOpenType = state.favoriteOpenType === field ? null : field;
            openSavedList("favorites");
            focusFavoriteHeader(field);
        } else if (action === "recent") {
            openSavedList("recent");
        } else if (action === "catalog") {
            openCatalog(element.getAttribute("data-type"));
        } else if (action === "category") {
            category = element._nexoCategory || {
                type: state.currentType,
                id: element.getAttribute("data-category") || "",
                name: element.innerHTML
            };
            authorizeCategory(category, function () {
                state.currentCategoryName = category.name;
                state.searchQuery = "";
                loadCatalogItems(category.type, category.id);
            });
        } else if (action === "load-more") {
            oldCount = state.catalogRenderedCount;
            renderCatalogResults(state.catalogViewItems, state.currentType, oldCount +
                ((state.currentCategory === "__latest__" && (state.currentType === "movie" || state.currentType === "series")) ? 20 : NEXO_CONFIG.catalogItemLimit));
            rendered = byId("catalog-items").getElementsByClassName("focusable");
            if (rendered.length > oldCount) {
                setFocus(rendered[oldCount]);
            }
        } else if (action === "item") {
            activateCatalogElement(element);
        } else if (action === "saved-item") {
            activateSavedWithAuthorization(element._nexoSaved, element._nexoSavedKind);
        } else if (action === "saved-server-switch-confirm") {
            pendingServerOpen = state.pendingSavedServerOpen;
            switchServerForSavedEntry(pendingServerOpen);
        } else if (action === "saved-current-search") {
            pendingServerOpen = state.pendingSavedServerOpen;
            closeModal();
            searchSavedOnCurrentServer(pendingServerOpen);
        } else if (action === "saved-search-result") {
            pendingServerOpen = element._nexoSearchPending;
            pendingEntry = element._nexoSearchItem;
            closeModal();
            openMatchedSavedContent(pendingServerOpen, pendingEntry);
        } else if (action === "recent-delete") {
            state.pendingRecentDelete = element._nexoSaved;
            confirmModal("Remover conte\u00FAdo", "Deseja remover:<br><strong>" +
                (element._nexoSaved.type === "series" ? "S\u00E9rie: " : "Filme: ") +
                safeName(element._nexoSaved.item, "Conte\u00FAdo") + "</strong><br>do Continue assistindo?", "recent-delete-confirm");
        } else if (action === "recent-delete-confirm") {
            pendingEntry = state.pendingRecentDelete;
            if (pendingEntry) { removeRecentEntry(pendingEntry); }
            closeModal();
            openSavedList("recent");
            toast("Removido do Continue assistindo");
        } else if (action === "favorite-delete-confirm") {
            pendingEntry = state.pendingFavoriteRemove;
            if (pendingEntry) {
                toggleFavoriteItem(pendingEntry.type, pendingEntry.item, pendingEntry.sourceEntry);
                updatePosterFavoriteBadge(pendingEntry.element, false);
            }
            closeModal();
            if (state.currentType === "favorites") {
                openSavedList("favorites");
                focusFavoriteHeader(state.favoriteOpenType);
            }
        } else if (action === "movie-play") {
            playItem("movie", element._nexoItem, safeName(element._nexoItem, "Filme"), element._nexoResumeEntry || null);
        } else if (action === "episode") {
            var episodeResumeEntry = element._nexoResumeEntry || null;
            if (!episodeResumeEntry && state.seriesContinueEntry && state.seriesContinueEntry._nexoMigration) {
                episodeResumeEntry = { currentTime: 0, _nexoMigration: state.seriesContinueEntry._nexoMigration };
            }
            state.playerReturnSeriesContext = {
                seasonKey: element._nexoSeason,
                episodeId: contentId("episode", element._nexoEpisode)
            };
            playItem("episode", element._nexoEpisode, safeName(element._nexoEpisode, "Epis\u00F3dio"),
                episodeResumeEntry,
                { seasonKey: element._nexoSeason, episodeIndex: element._nexoEpisodeIndex });
        } else if (action === "season-menu-toggle") {
            toggleSeriesSeasonMenu();
        } else if (action === "season-option") {
            renderSeriesSeason(element.getAttribute("data-season"), true);
        } else if (action === "player-season-menu-toggle") {
            togglePlayerSeasonMenu();
            resetPlayerPanelTimer();
        } else if (action === "player-season-option" || action === "player-season") {
            state.playerPanelSeasonMenuOpen = false;
            addClass(byId("player-season-menu"), "hidden");
            renderPlayerSeriesControls(element.getAttribute("data-season"), true);
            resetPlayerPanelTimer();
        } else if (action === "player-episode" || action === "player-next") {
            playItem("episode", element._nexoEpisode, safeName(element._nexoEpisode, "Epis\u00F3dio"), null,
                { seasonKey: element._nexoSeason, episodeIndex: element._nexoEpisodeIndex });
        } else if (action === "player-format") {
            cyclePlayerDisplayMode();
        } else if (action === "player-timeline") {
            Platform.togglePause();
            resetPlayerPanelTimer();
        } else if (action === "login-keyboard-key") {
            appendLoginKeyboardCharacter(element.getAttribute("data-character") || "");
        } else if (action === "login-keyboard-backspace") {
            state.loginKeyboardValue = state.loginKeyboardValue.substring(0, Math.max(0, state.loginKeyboardValue.length - 1));
            updateLoginKeyboardDisplay();
        } else if (action === "login-keyboard-clear") {
            state.loginKeyboardValue = "";
            updateLoginKeyboardDisplay();
        } else if (action === "login-keyboard-case") {
            state.loginKeyboardUppercase = !state.loginKeyboardUppercase;
            renderLoginKeyboardKeys();
            setFocus(byId("login-keyboard-grid").getElementsByClassName("focusable")[0]);
        } else if (action === "login-keyboard-ok") {
            field = state.loginKeyboardField;
            if (field) { state.login[field] = state.loginKeyboardValue; }
            updateLoginUi();
            closeModal();
            if (field === "username") { setFocus(byId("login-pass")); }
            else { setFocus(byId("login-submit")); }
        } else if (action === "search-key") {
            if (state.searchQuery.length < 32) {
                state.searchQuery += element.getAttribute("data-character") || "";
                updateSearchDisplay();
            }
        } else if (action === "search-space") {
            if (state.searchQuery.length < 32) {
                state.searchQuery += " ";
                updateSearchDisplay();
            }
        } else if (action === "search-backspace") {
            state.searchQuery = state.searchQuery.substring(0, Math.max(0, state.searchQuery.length - 1));
            updateSearchDisplay();
        } else if (action === "search-clear") {
            state.searchQuery = "";
            updateSearchDisplay();
        } else if (action === "search-apply") {
            applySearch();
        } else if (action === "servers") {
            openServers();
        } else if (action === "parental") {
            openParentalControl();
        } else if (action === "server-refresh") {
            refreshCurrentServer(true);
        } else if (action === "server-auto-update") {
            openCatalogAutoUpdate();
        } else if (action === "catalog-update-days") {
            saveCatalogUpdateDays(element.getAttribute("data-days"));
            closeModal();
            toast(state.catalogUpdateDays === 1 ? "Atualiza\u00E7\u00E3o autom\u00E1tica: a cada dia" :
                ("Atualiza\u00E7\u00E3o autom\u00E1tica: a cada " + state.catalogUpdateDays + " dias"));
        } else if (action === "server-source") {
            renderServerPicker(byId("modal-content"), state.codeEntry ? state.codeEntry.fontes || [] : [],
                element.getAttribute("data-source-index"), true);
        } else if (action === "server-select") {
            chooseServer(element._nexoServer);
        } else if (action === "parental-digit") {
            appendParentalDigit(element.getAttribute("data-digit") || "");
        } else if (action === "parental-backspace") {
            eraseDigit(false);
        } else if (action === "parental-clear") {
            eraseDigit(true);
        } else if (action === "parental-pin-submit") {
            submitParentalPin();
        } else if (action === "parental-change-pin") {
            openChangeParentalPin();
        } else if (action === "parental-type") {
            state.parentalCategoryType = element.getAttribute("data-type") || "live";
            renderParentalSettings(true);
        } else if (action === "parental-toggle") {
            category = element._nexoCategory;
            toggleBlockedCategory(category);
            renderParentalSettings(true, category ? category.id : "");
        } else if (action === "logout") {
            confirmModal("Sair da conta", "Deseja apagar o acesso salvo nesta TV?", "logout-confirm");
        } else if (action === "logout-confirm") {
            clearRecentItems();
            clearSavedSession();
            clearPersistentCatalogCache();
            state.session = null;
            resetLatestCatalogCache("");
            state.login.password = "";
            updateLoginUi();
            closeModal();
            setScreen("login");
            setLoginStatus("Acesso removido desta TV", false);
            focusFirst("login-code");
        } else if (action === "exit-confirm") {
            Platform.exitApp();
        } else if (action === "modal-close") {
            closeModal();
        }
    }

    function handleBack() {
        if (state.playerOpen) {
            stopPlayer();
            return;
        }
        if (state.seriesOpen && state.seriesSeasonMenuOpen) {
            toggleSeriesSeasonMenu();
            return;
        }
        if (state.modalOpen) {
            closeModal();
            return;
        }
        if (state.screen === "login") {
            Platform.exitApp();
            return;
        }
        if (state.seriesOpen) {
            state.seriesOpen = false;
            if (state.seriesReturnView) {
                openSavedList(state.seriesReturnView);
            } else {
                openCatalog("series", state.currentCategory);
            }
            return;
        }
        if (state.detailOpen) {
            state.detailOpen = false;
            state.detailItem = null;
            state.detailResumeEntry = null;
            if (state.detailReturnView) {
                openSavedList(state.detailReturnView);
            } else {
                openCatalog("movie", state.currentCategory);
            }
            state.detailReturnView = null;
            return;
        }
        if (state.searchActive) {
            state.searchActive = false;
            setPage(state.currentType === "live" ? "TV ao vivo" : (state.currentType === "movie" ? "Filmes" : "S\u00E9ries"), "Escolha uma categoria e um conte\u00FAdo");
            renderCatalogResults(state.catalogItems, state.currentType);
            if (byId("catalog-items").getElementsByClassName("focusable").length) {
                setFocus(byId("catalog-items").getElementsByClassName("focusable")[0]);
            }
            return;
        }
        confirmModal("Sair do aplicativo", "Deseja fechar o Nexo Play?", "exit-confirm");
    }

    function consumeKeyEvent(event) {
        if (event.preventDefault) { event.preventDefault(); }
        event.returnValue = false;
        event.cancelBubble = true;
        return false;
    }

    function favoriteTarget(element) {
        if (!element) { return null; }
        if ((element.getAttribute("data-action") === "item" || element.getAttribute("data-action") === "movie-play") && element._nexoItem &&
                (element._nexoType === "live" || element._nexoType === "movie" || element._nexoType === "series")) {
            return { type: element._nexoType, item: element._nexoItem };
        }
        if (element.getAttribute("data-action") === "saved-item" && element._nexoSaved) {
            return { type: element._nexoSaved.type, item: element._nexoSaved.item, sourceEntry: element._nexoSaved };
        }
        return null;
    }

    function resetEnterPress() {
        if (state.enterHoldTimer) { clearTimeout(state.enterHoldTimer); }
        if (state.enterShortTimer) { clearTimeout(state.enterShortTimer); }
        if (state.enterReleaseTimer) { clearTimeout(state.enterReleaseTimer); }
        state.enterHoldTimer = null;
        state.enterShortTimer = null;
        state.enterReleaseTimer = null;
        state.enterPressed = false;
        state.enterLongFired = false;
        state.enterRepeatSeen = false;
        state.enterHoldElement = null;
        state.enterStartedAt = 0;
    }

    function beginEnterPress(event) {
        var now = new Date().getTime();
        if (state.playerOpen) {
            Platform.togglePause();
            return consumeKeyEvent(event);
        }
        if (state.enterPressed) {
            return consumeKeyEvent(event);
        }
        if (now < state.enterSuppressUntil) {
            return consumeKeyEvent(event);
        }
        state.enterPressed = true;
        state.enterLongFired = true;
        state.enterStartedAt = now;
        state.enterHoldElement = state.focusElement;
        activate(state.focusElement);
        state.enterSuppressUntil = now + 500;
        state.enterReleaseTimer = setTimeout(resetEnterPress, 900);
        return consumeKeyEvent(event);
    }

    function onKeyUp(event) {
        var code;
        var heldElement;
        event = event || window.event;
        code = event.keyCode || event.which;
        if (code !== 29443 && !(event.key && event.key === "Enter")) {
            return true;
        }
        if (!state.enterPressed) { return true; }
        state.enterKeyUpObserved = true;
        heldElement = state.enterHoldElement;
        if (state.enterHoldTimer) { clearTimeout(state.enterHoldTimer); }
        if (!state.enterLongFired && heldElement) {
            activate(heldElement);
        }
        state.enterSuppressUntil = new Date().getTime() + 350;
        resetEnterPress();
        return consumeKeyEvent(event);
    }

    function handlePlayerKey(event, code) {
        var before;
        if (code === 88 || event.key === "Escape") {
            if (state.playerPanelOpen) { hidePlayerPanel(); }
            else { stopPlayer(false); }
            return consumeKeyEvent(event);
        }
        if (code === 45) {
            recordContinueNow();
            Platform.exitApp();
            return consumeKeyEvent(event);
        }
        if (code === 7 || code === 447) {
            if (Platform.changeVolume("up")) { showVolumeOsd("up"); }
            return consumeKeyEvent(event);
        }
        if (code === 11 || code === 448) {
            if (Platform.changeVolume("down")) { showVolumeOsd("down"); }
            return consumeKeyEvent(event);
        }
        if (code === 27 || code === 449) {
            if (Platform.changeVolume("mute")) { showVolumeOsd("mute"); }
            return consumeKeyEvent(event);
        }
        if (code === 69 || code === 412) {
            seekPlayer(-30);
            return consumeKeyEvent(event);
        }
        if (code === 72 || code === 417) {
            seekPlayer(30);
            return consumeKeyEvent(event);
        }
        if (code === 29461 || code === 40 || event.key === "ArrowDown") {
            if (!state.playerPanelOpen) {
                showPlayerPanel();
            } else if (state.playerPanelSeasonMenuOpen) {
                movePlayerSeasonMenuFocus("down");
                resetPlayerPanelTimer();
            } else {
                moveFocus("down");
                resetPlayerPanelTimer();
            }
            return consumeKeyEvent(event);
        }
        if (code === 29460 || code === 38 || event.key === "ArrowUp") {
            if (state.playerPanelOpen && state.playerPanelSeasonMenuOpen) {
                movePlayerSeasonMenuFocus("up");
                resetPlayerPanelTimer();
            } else if (state.playerPanelOpen) {
                before = state.focusElement;
                moveFocus("up");
                if (state.focusElement === before) { hidePlayerPanel(); }
                else { resetPlayerPanelTimer(); }
            }
            return consumeKeyEvent(event);
        }
        if (code === 4 || code === 37 || event.key === "ArrowLeft") {
            if (state.playerPanelOpen && state.playerPanelSeasonMenuOpen) {
                resetPlayerPanelTimer();
            } else if (state.playerPanelOpen && state.focusElement && state.focusElement.getAttribute("data-action") === "player-timeline") {
                seekPlayer(-30);
            } else if (state.playerPanelOpen && state.playerType === "episode") {
                moveFocus("left");
                resetPlayerPanelTimer();
            }
            return consumeKeyEvent(event);
        }
        if (code === 5 || code === 39 || event.key === "ArrowRight") {
            if (state.playerPanelOpen && state.playerPanelSeasonMenuOpen) {
                resetPlayerPanelTimer();
            } else if (state.playerPanelOpen && state.focusElement && state.focusElement.getAttribute("data-action") === "player-timeline") {
                seekPlayer(30);
            } else if (state.playerPanelOpen && state.playerType === "episode") {
                moveFocus("right");
                resetPlayerPanelTimer();
            }
            return consumeKeyEvent(event);
        }
        if (code === 29443 || code === 13 || event.key === "Enter") {
            if (state.playerPanelOpen && state.focusElement && playerControlContains(state.focusElement)) {
                activate(state.focusElement);
            } else {
                Platform.togglePause();
                if (state.playerPanelOpen) { resetPlayerPanelTimer(); }
            }
            return consumeKeyEvent(event);
        }
        if (code === 71 || code === 74 || code === 415 || code === 19) {
            Platform.togglePause();
            return consumeKeyEvent(event);
        }
        return true;
    }

    function onKeyDown(event) {
        event = event || window.event;
        var code = event.keyCode || event.which;
        var digit;
        if (state.playerOpen) {
            return handlePlayerKey(event, code);
        }
        if (state.catalogBlocking) {
            if (code === 7 || code === 447) {
                if (Platform.changeVolume("up")) { showVolumeOsd("up"); }
            } else if (code === 11 || code === 448) {
                if (Platform.changeVolume("down")) { showVolumeOsd("down"); }
            } else if (code === 27 || code === 449) {
                if (Platform.changeVolume("mute")) { showVolumeOsd("mute"); }
            }
            return consumeKeyEvent(event);
        }
        if (code === 29460 || code === 38) {
            if (!handleStructuredNavigation("up")) { moveFocusSafely("up"); }
            return consumeKeyEvent(event);
        }
        if (code === 29461 || code === 40) {
            if (shouldLockSideMenuDown() || shouldLockCatalogDown()) { return consumeKeyEvent(event); }
            if (!handleStructuredNavigation("down") && !moveFromTopStripToContent()) { moveFocusSafely("down"); }
            return consumeKeyEvent(event);
        }
        if (code === 4 || code === 37) {
            if (handleStructuredNavigation("left")) { return consumeKeyEvent(event); }
            if (state.seriesOpen && state.focusElement && state.focusElement.getAttribute("data-action") === "episode") {
                focusSideMenuType("series");
                return consumeKeyEvent(event);
            }
            if (moveLiveChannelToSideMenu()) { return consumeKeyEvent(event); }
            moveFocusSafely("left");
            return consumeKeyEvent(event);
        }
        if (code === 5 || code === 39) {
            if (!handleStructuredNavigation("right")) { moveFocusSafely("right"); }
            return consumeKeyEvent(event);
        }
        if (code === 29443) {
            return beginEnterPress(event);
        }
        if (code === 88) {
            if (state.playerOpen) { stopPlayer(); }
            else { handleBack(); }
            return consumeKeyEvent(event);
        }
        if (code === 7 || code === 447) {
            if (Platform.changeVolume("up")) { showVolumeOsd("up"); }
            return consumeKeyEvent(event);
        }
        if (code === 11 || code === 448) {
            if (Platform.changeVolume("down")) { showVolumeOsd("down"); }
            return consumeKeyEvent(event);
        }
        if (code === 27 || code === 449) {
            if (Platform.changeVolume("mute")) { showVolumeOsd("mute"); }
            return consumeKeyEvent(event);
        }
        if (code === 45) {
            Platform.exitApp();
            return consumeKeyEvent(event);
        }
        digit = Platform.digitFromEvent(event);
        if (digit !== null && appendDigit(digit)) {
            return consumeKeyEvent(event);
        }
        if (Platform.isKey(event, "GREEN")) {
            var greenTarget = favoriteTarget(state.focusElement);
            var favoriteNow;
            if (greenTarget) {
                if (isFavoriteItem(greenTarget.type, greenTarget.item, greenTarget.sourceEntry)) {
                    state.pendingFavoriteRemove = {
                        type: greenTarget.type,
                        item: greenTarget.item,
                        sourceEntry: greenTarget.sourceEntry || null,
                        element: state.focusElement
                    };
                    confirmModal("Remover conte\u00FAdo", "Deseja remover:<br><strong>" +
                        (greenTarget.type === "series" ? "S\u00E9rie: " : (greenTarget.type === "movie" ? "Filme: " : "Canal: ")) +
                        safeName(greenTarget.item, "Conte\u00FAdo") + "</strong><br>dos Favoritos?", "favorite-delete-confirm");
                    return consumeKeyEvent(event);
                }
                favoriteNow = toggleFavoriteItem(greenTarget.type, greenTarget.item, greenTarget.sourceEntry);
                updatePosterFavoriteBadge(state.focusElement, favoriteNow);
                if (state.focusElement && state.focusElement._nexoSavedKind === "favorites") {
                    openSavedList("favorites");
                    focusFavoriteHeader(state.favoriteOpenType);
                }
                return consumeKeyEvent(event);
            }
        }
        if (Platform.isKey(event, "UP")) {
            if (!handleStructuredNavigation("up")) { moveFocusSafely("up"); }
        }
        else if (Platform.isKey(event, "DOWN")) {
            if (!shouldLockSideMenuDown() && !shouldLockCatalogDown() && !handleStructuredNavigation("down") &&
                    !moveFromTopStripToContent()) { moveFocusSafely("down"); }
        }
        else if (Platform.isKey(event, "LEFT")) {
            if (handleStructuredNavigation("left")) {
                return consumeKeyEvent(event);
            } else if (state.seriesOpen && state.focusElement && state.focusElement.getAttribute("data-action") === "episode") {
                focusSideMenuType("series");
            } else if (moveLiveChannelToSideMenu()) {
                return consumeKeyEvent(event);
            } else {
                moveFocusSafely("left");
            }
        }
        else if (Platform.isKey(event, "RIGHT")) {
            if (!handleStructuredNavigation("right")) { moveFocusSafely("right"); }
        }
        else if (Platform.isKey(event, "ENTER")) { return beginEnterPress(event); }
        else if (Platform.isKey(event, "RETURN") || Platform.isKey(event, "EXIT")) { handleBack(); }
        else if (Platform.isKey(event, "YELLOW") || code === 8 || code === 46) { eraseDigit(false); }
        else if (Platform.isKey(event, "RED")) { eraseDigit(true); }
        else { return true; }
        return consumeKeyEvent(event);
    }

    function bindPointerTesting() {
        document.onclick = function (event) {
            var target = event.target;
            while (target && target !== document.body && !hasClass(target, "focusable")) {
                target = target.parentNode;
            }
            if (target && hasClass(target, "focusable")) {
                setFocus(target);
                activate(target);
            }
        };
    }

    function updateClock() {
        var now = new Date();
        var hours = now.getHours();
        var minutes = now.getMinutes();
        byId("clock").innerHTML = (hours < 10 ? "0" : "") + hours + ":" + (minutes < 10 ? "0" : "") + minutes;
        maybeRefreshCatalogDaily();
    }

    function init() {
        var saved;
        var previewSeries;
        var previewMovie;
        var savedDisplayMode;
        if (state.initialized) { return; }
        state.initialized = true;
        try { savedDisplayMode = window.localStorage.getItem("nexo_player_display_mode"); } catch (ignoreDisplayLoad) {}
        if (savedDisplayMode) {
            state.playerDisplayMode = playerDisplayModeInfo(savedDisplayMode).current.value;
        }
        loadCatalogUpdateDays();
        Platform.init();
        document.onkeydown = onKeyDown;
        document.onkeyup = onKeyUp;
        window.onkeyup = onKeyUp;
        if (document.body) { document.body.onkeyup = onKeyUp; }
        bindPointerTesting();
        updateClock();
        state.clockTimer = setInterval(updateClock, 30000);
        updateLoginUi();
        previewSeries = window.location && window.location.search.indexOf("preview=series") >= 0;
        previewMovie = window.location && window.location.search.indexOf("preview=movie") >= 0;
        if (window.location && (window.location.search.indexOf("preview=main") >= 0 || previewSeries || previewMovie)) {
            state.preview = true;
            state.login.code = "0001";
            state.login.username = "USUARIO DE TESTE";
            state.login.password = "0000";
            state.codeEntry = {
                fontes: [{
                    nomeFonte: "TV On+",
                    servidores: [
                        { serverName: "Speed (TV On+)", serverHost: "http://speed.tvonplus.shop" },
                        { serverName: "Galaxy (TV On+)", serverHost: "http://galaxy.tvonplus.shop" }
                    ]
                }, {
                    nomeFonte: "Netplay",
                    servidores: [
                        { serverName: "Principal (Netplay)", serverHost: "http://netplay.example" },
                        { serverName: "Reserva (Netplay)", serverHost: "http://reserva.example" }
                    ]
                }]
            };
            state.session = {
                username: state.login.username,
                password: state.login.password,
                server: {
                    sourceName: "TV On+",
                    sourceIndex: 0,
                    serverIndex: 0,
                    serverName: "Speed (TV On+)",
                    serverHost: "http://speed.tvonplus.shop"
                }
            };
            openMain();
            if (previewMovie) {
                state.currentType = "movie";
                state.currentCategory = "preview-movie";
                state.detailOpen = true;
                state.detailItem = { name: "Filme de demonstra\u00E7\u00E3o", stream_icon: "images/nexo-play-logo.png", stream_id: 1 };
                renderMovieDetails(state.detailItem, { info: {
                    name: "Filme de demonstra\u00E7\u00E3o",
                    plot: "Uma sinopse de demonstra\u00E7\u00E3o mostra como as informa\u00E7\u00F5es do filme aparecem antes da reprodu\u00E7\u00E3o.",
                    rating: "8.4",
                    genre: "Drama, Aventura",
                    year: "2026",
                    duration: "1h 48min",
                    director: "Diretor de demonstra\u00E7\u00E3o",
                    cast: "Pessoa Um, Pessoa Dois, Pessoa Tr\u00EAs"
                }});
            } else if (previewSeries) {
                state.currentType = "series";
                state.currentCategory = "preview-series";
                state.currentCategoryName = "Em alta";
                state.seriesOpen = true;
                state.seriesItem = { name: "S\u00E9rie de demonstra\u00E7\u00E3o" };
                state.seriesData = {
                    info: {
                        plot: "Sinopse de demonstra\u00E7\u00E3o da s\u00E9rie, com avalia\u00E7\u00E3o, g\u00EAnero e ano fornecidos pela lista.",
                        rating: "9.0",
                        genre: "Drama, Fic\u00E7\u00E3o",
                        year: "2026"
                    },
                    episodes: {
                        "1": [{ id: 1, episode_num: 1, title: "Primeiro epis\u00F3dio" }, { id: 2, episode_num: 2, title: "Segundo epis\u00F3dio" }],
                        "2": [{ id: 3, episode_num: 1, title: "Retorno" }, { id: 4, episode_num: 2, title: "Final" }]
                    }
                };
                renderSeriesSeason("1", false);
            }
            return;
        }
        saved = loadSavedSession();
        if (saved) {
            setScreen("splash");
            setLoginStatus("Validando acesso salvo...", false);
            login(true);
        } else {
            setScreen("login");
            focusFirst("login-code");
        }
    }

    function clearRuntimeTimers() {
        var names = ["toastTimer", "volumeTimer", "loadingTimer", "enterHoldTimer", "enterShortTimer",
            "enterReleaseTimer", "recentTimer", "playerPanelTimer", "playerAutoAdvanceTimer", "playerReconnectTimer",
            "latestPrefetchTimer", "catalogStatusTimer", "catalogDailyTimer", "clockTimer"];
        var i;
        for (i = 0; i < names.length; i += 1) {
            if (state[names[i]]) {
                clearTimeout(state[names[i]]);
                clearInterval(state[names[i]]);
                state[names[i]] = null;
            }
        }
    }

    function suspend() {
        if (state.suspended) { return; }
        state.suspended = true;
        if (state.playerOpen) {
            recordContinueNow();
            state.playerToken += 1;
            state.playerOpen = false;
            state.playerType = null;
            state.playerItem = null;
            state.playerTitle = "";
            state.playerReconnectAttempts = 0;
            state.playerReconnectReason = "";
            state.playerEpisodeContext = null;
            state.playerResumeTime = 0;
            state.playerAutoAdvancePending = false;
            setScreen(state.session ? "main" : "login");
        }
        clearRuntimeTimers();
        Platform.shutdown();
    }

    function resume() {
        if (!state.suspended) { return; }
        state.suspended = false;
        updateClock();
        state.clockTimer = setInterval(updateClock, 30000);
        if (state.session) {
            setScreen("main");
            focusFirst();
        } else {
            setScreen("login");
            focusFirst("login-code");
        }
    }

    function shutdown() {
        suspend();
        state.latestCatalogImages = { movie: [], series: [] };
        state.latestCatalogCache = { serverHost: "", live: null, movie: null, series: null };
        state.catalogCategories = { live: null, movie: null, series: null };
        document.onkeydown = null;
        document.onkeyup = null;
        if (document.body) { document.body.onkeyup = null; }
    }

    return { init: init, suspend: suspend, resume: resume, shutdown: shutdown };
}());

var nexoSplashStartedAt = new Date().getTime();
var nexoSplashTimer = null;
var nexoStartupRequested = false;

function startNexoAfterSplash() {
    var remaining = 1800 - (new Date().getTime() - nexoSplashStartedAt);
    if (nexoSplashTimer || nexoStartupRequested) { return; }
    nexoStartupRequested = true;
    nexoSplashTimer = setTimeout(function () {
        nexoSplashTimer = null;
        NexoApp.init();
    }, remaining > 0 ? remaining : 0);
}

function handleNexoShow() {
    Platform.resume();
    NexoApp.resume();
}

function handleNexoHide() {
    NexoApp.suspend();
}

function handleNexoUnload() {
    NexoApp.shutdown();
}

/* Os nomes com letra maiuscula sao os eventos nativos usados nas TVs Samsung Legacy. */
window.onShow = handleNexoShow;
window.onHide = handleNexoHide;
window.onUnload = handleNexoUnload;
/* Mantem tambem os eventos HTML para navegador e modelos que os disparam dessa forma. */
window.onshow = handleNexoShow;
window.onhide = handleNexoHide;
window.onunload = handleNexoUnload;
window.onbeforeunload = handleNexoUnload;

/* O aplicativo so continua depois que a TV confirmar que as APIs do Smart Hub estao prontas. */
Platform.init(startNexoAfterSplash);
window.onload = function () {
    Platform.init(startNexoAfterSplash);
};
