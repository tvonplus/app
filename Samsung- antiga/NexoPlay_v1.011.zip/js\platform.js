var Platform = (function () {
    var widgetAPI = null;
    var tvKey = null;
    var pluginAPI = null;
    var audio = null;
    var nnavi = null;
    var player = null;
    var html5Player = null;
    var callbacks = {};
    var samsungLegacy = false;
    var playerPaused = false;
    var playbackStarted = false;
    var playerDisplayMode = "auto";
    var shuttingDown = false;
    var shutdownComplete = false;
    var systemInitTimer = null;
    var initialized = false;
    var initializing = false;
    var initializationCallbacks = [];
    var apiLoadStarted = false;
    var apiLoadIndex = 0;
    var apiPollTimer = null;
    var apiBootStartedAt = 0;
    var readyEventSent = false;
    var legacyApiScripts = [
        { id: "nexo-api-widget", src: "$MANAGER_WIDGET/Common/API/Widget.js" },
        { id: "nexo-api-tvkey", src: "$MANAGER_WIDGET/Common/API/TVKeyValue.js" },
        { id: "nexo-api-plugin", src: "$MANAGER_WIDGET/Common/API/Plugin.js" }
    ];

    var fallbackKeys = {
        UP: 38,
        DOWN: 40,
        LEFT: 37,
        RIGHT: 39,
        ENTER: 13,
        RETURN: 88,
        EXIT: 45,
        RED: 403,
        GREEN: 404,
        YELLOW: 405,
        BLUE: 406,
        PLAY: 415,
        PAUSE: 19,
        STOP: 413,
        REWIND: 412,
        FORWARD: 417,
        VOLUME_UP: 447,
        VOLUME_DOWN: 448,
        MUTE: 449
    };

    var legacyKeys = {
        UP: 29460,
        DOWN: 29461,
        LEFT: 4,
        RIGHT: 5,
        ENTER: 29443,
        RETURN: 88,
        EXIT: 45,
        RED: 108,
        GREEN: 20,
        YELLOW: 21,
        BLUE: 22,
        PLAY: 71,
        PAUSE: 74,
        STOP: 70,
        REWIND: 69,
        FORWARD: 72,
        VOLUME_UP: 7,
        VOLUME_DOWN: 11,
        MUTE: 27
    };

    var legacyDigits = {
        17: "0",
        101: "1",
        98: "2",
        6: "3",
        8: "4",
        9: "5",
        10: "6",
        12: "7",
        13: "8",
        14: "9"
    };

    function getKey(name, fallback) {
        var samsungName = "KEY_" + name;
        if (tvKey && typeof tvKey[samsungName] !== "undefined") {
            return tvKey[samsungName];
        }
        return fallback;
    }

    function unregisterSystemKey(keyCode) {
        try {
            if (pluginAPI && typeof pluginAPI.unregistKey === "function" && typeof keyCode !== "undefined") {
                pluginAPI.unregistKey(keyCode);
            }
        } catch (ignoreUnregister) {}
    }

    function enableNativeSystemKeys() {
        unregisterSystemKey(legacyKeys.VOLUME_UP);
        unregisterSystemKey(legacyKeys.VOLUME_DOWN);
        unregisterSystemKey(legacyKeys.MUTE);
        unregisterSystemKey(legacyKeys.EXIT);
        if (tvKey) {
            unregisterSystemKey(tvKey.KEY_VOL_UP);
            unregisterSystemKey(tvKey.KEY_VOL_DOWN);
            unregisterSystemKey(tvKey.KEY_MUTE);
            unregisterSystemKey(tvKey.KEY_EXIT);
        }
    }

    function ensureSystemPlugins() {
        var host = document.getElementById("nativePluginHost");
        if (!samsungLegacy || !host) { return; }
        try {
            if (!document.getElementById("pluginAudio")) {
                host.innerHTML = '<object id="pluginAudio" border="0" classid="clsid:SAMSUNG-INFOLINK-AUDIO"></object>';
            }
            audio = document.getElementById("pluginAudio");
        } catch (ignoreSystemPlugins) {
            audio = null;
        }
    }

    function activateSystemIntegration() {
        refreshOptionalLegacyApis();
        enableNativeSystemKeys();
        try {
            if (pluginAPI) {
                pluginAPI.registKey(tvKey && typeof tvKey.KEY_GREEN !== "undefined" ? tvKey.KEY_GREEN : legacyKeys.GREEN);
            }
        } catch (ignoreGreen) {}
    }

    function scheduleSystemIntegration(delay) {
        if (systemInitTimer) { clearTimeout(systemInitTimer); }
        systemInitTimer = setTimeout(function () {
            systemInitTimer = null;
            activateSystemIntegration();
        }, delay || 1200);
    }

    function releaseSystemPlugins() {
        var host = document.getElementById("nativePluginHost");
        try { if (host) { host.innerHTML = ""; } } catch (ignoreRemoveSystemPlugins) {}
        audio = null;
        nnavi = null;
    }

    function setStartupStatus(message) {
        var status;
        try {
            status = document.getElementById("splash-status");
            if (status) { status.innerHTML = message; }
        } catch (ignoreStartupStatus) {}
    }

    function isSamsungLegacyEnvironment() {
        var userAgent = "";
        try {
            userAgent = window.navigator && window.navigator.userAgent ? window.navigator.userAgent : "";
        } catch (ignoreUserAgent) {}
        return /Maple|SMART-TV|Samsung/i.test(userAgent);
    }

    function refreshOptionalLegacyApis() {
        try {
            if (!tvKey && window.Common && Common.API && Common.API.TVKeyValue) {
                tvKey = new Common.API.TVKeyValue();
            }
        } catch (ignoreTvKeyInit) {
            tvKey = null;
        }
        try {
            if (!pluginAPI && window.Common && Common.API && Common.API.Plugin) {
                pluginAPI = new Common.API.Plugin();
            }
        } catch (ignorePluginApiInit) {
            pluginAPI = null;
        }
    }

    function notifyInitializationCallbacks() {
        var callbacksToRun = initializationCallbacks.slice(0);
        var i;
        initializationCallbacks = [];
        for (i = 0; i < callbacksToRun.length; i += 1) {
            try { callbacksToRun[i](samsungLegacy); } catch (ignoreInitCallback) {}
        }
    }

    function finishInitialization(isLegacy) {
        if (initialized) { return; }
        initialized = true;
        initializing = false;
        samsungLegacy = !!isLegacy;
        if (apiPollTimer) {
            clearTimeout(apiPollTimer);
            apiPollTimer = null;
        }
        if (samsungLegacy) {
            setStartupStatus("Iniciando Nexo Play...");
            scheduleSystemIntegration(2000);
        }
        notifyInitializationCallbacks();
    }

    function trySamsungReady() {
        if (initialized) { return true; }
        try {
            if (!window.Common || !Common.API || !Common.API.Widget) { return false; }
            if (!widgetAPI) { widgetAPI = new Common.API.Widget(); }
            if (!readyEventSent) {
                /* Esta precisa ser a primeira chamada nativa feita durante a abertura. */
                widgetAPI.sendReadyEvent();
                readyEventSent = true;
            }
            refreshOptionalLegacyApis();
            finishInitialization(true);
            return true;
        } catch (ignoreSamsungReady) {
            widgetAPI = null;
            return false;
        }
    }

    function pollSamsungApis() {
        var elapsed;
        if (trySamsungReady()) { return; }
        elapsed = new Date().getTime() - apiBootStartedAt;
        if (elapsed >= 8000) {
            setStartupStatus("Preparando a TV... aguarde");
        } else if (elapsed >= 2500) {
            setStartupStatus("Preparando a TV...");
        }
        apiPollTimer = setTimeout(pollSamsungApis, 50);
    }

    function loadNextLegacyApi() {
        var descriptor;
        var script;
        var completed = false;
        var head;

        if (apiLoadIndex >= legacyApiScripts.length) { return; }
        descriptor = legacyApiScripts[apiLoadIndex];
        apiLoadIndex += 1;
        if (document.getElementById(descriptor.id)) {
            loadNextLegacyApi();
            return;
        }

        function completeLoad() {
            if (completed) { return; }
            completed = true;
            script.onload = null;
            script.onreadystatechange = null;
            script.onerror = null;
            loadNextLegacyApi();
        }

        try {
            script = document.createElement("script");
            script.id = descriptor.id;
            script.type = "text/javascript";
            script.src = descriptor.src;
            script.onload = completeLoad;
            script.onreadystatechange = function () {
                if (!script.readyState || script.readyState === "loaded" || script.readyState === "complete") {
                    completeLoad();
                }
            };
            script.onerror = completeLoad;
            head = document.getElementsByTagName("head")[0] || document.documentElement;
            head.appendChild(script);
        } catch (ignoreApiLoad) {
            completeLoad();
        }
    }

    function startLegacyApiLoad() {
        if (apiLoadStarted) { return; }
        apiLoadStarted = true;
        apiLoadIndex = 0;
        loadNextLegacyApi();
    }

    function init(callback) {
        if (typeof callback === "function") {
            if (initialized) {
                setTimeout(function () { callback(samsungLegacy); }, 0);
            } else {
                initializationCallbacks.push(callback);
            }
        }
        if (initialized) { return samsungLegacy; }
        if (initializing) { return false; }
        initializing = true;
        player = null;
        audio = null;
        nnavi = null;
        html5Player = document.getElementById("html5Player");
        shuttingDown = false;

        if (!isSamsungLegacyEnvironment() && !(window.Common && Common.API)) {
            finishInitialization(false);
            return false;
        }

        setStartupStatus("Preparando a TV...");
        apiBootStartedAt = new Date().getTime();
        startLegacyApiLoad();
        pollSamsungApis();
        return false;
    }

    function resume() {
        shuttingDown = false;
        shutdownComplete = false;
        if (samsungLegacy) {
            refreshOptionalLegacyApis();
            scheduleSystemIntegration(900);
        }
    }

    function ensureLegacyPlayer() {
        var host;
        if (!samsungLegacy) { return null; }
        if (player) { return player; }
        host = document.getElementById("pluginPlayerHost");
        if (!host) { return null; }
        try {
            host.innerHTML = '<object id="pluginPlayer" classid="clsid:SAMSUNG-INFOLINK-PLAYER"></object>';
            player = document.getElementById("pluginPlayer");
        } catch (ignoreCreatePlayer) {
            player = null;
        }
        return player;
    }

    function releasePlayer() {
        var host = document.getElementById("pluginPlayerHost");
        try {
            if (player && typeof player.Stop === "function") { player.Stop(); }
            if (player && typeof player.StopPlayer === "function") { player.StopPlayer(); }
        } catch (ignoreStopPlayer) {}
        try {
            if (host) { host.innerHTML = ""; }
        } catch (ignoreRemovePlayer) {}
        try { window.NexoLegacyPlayerCallbacks = null; } catch (ignoreCallbacks) {}
        player = null;
        callbacks = {};
        playerPaused = false;
        playbackStarted = false;
    }

    function keys() {
        return {
            UP: getKey("UP", fallbackKeys.UP),
            DOWN: getKey("DOWN", fallbackKeys.DOWN),
            LEFT: getKey("LEFT", fallbackKeys.LEFT),
            RIGHT: getKey("RIGHT", fallbackKeys.RIGHT),
            ENTER: getKey("ENTER", fallbackKeys.ENTER),
            RETURN: getKey("RETURN", fallbackKeys.RETURN),
            EXIT: getKey("EXIT", fallbackKeys.EXIT),
            RED: getKey("RED", fallbackKeys.RED),
            GREEN: getKey("GREEN", fallbackKeys.GREEN),
            YELLOW: getKey("YELLOW", fallbackKeys.YELLOW),
            BLUE: getKey("BLUE", fallbackKeys.BLUE),
            PLAY: getKey("PLAY", fallbackKeys.PLAY),
            PAUSE: getKey("PAUSE", fallbackKeys.PAUSE),
            STOP: getKey("STOP", fallbackKeys.STOP),
            REWIND: getKey("RW", fallbackKeys.REWIND),
            FORWARD: getKey("FF", fallbackKeys.FORWARD),
            VOLUME_UP: getKey("VOL_UP", fallbackKeys.VOLUME_UP),
            VOLUME_DOWN: getKey("VOL_DOWN", fallbackKeys.VOLUME_DOWN),
            MUTE: getKey("MUTE", fallbackKeys.MUTE)
        };
    }

    function isKey(event, name) {
        var map = keys();
        var code = event.keyCode || event.which;
        var browserNames = {
            UP: "ArrowUp",
            DOWN: "ArrowDown",
            LEFT: "ArrowLeft",
            RIGHT: "ArrowRight",
            ENTER: "Enter",
            RETURN: "Escape",
            EXIT: "Escape"
        };
        if (name === "VOLUME_UP" || name === "VOLUME_DOWN" || name === "MUTE" || name === "EXIT" ||
                name === "REWIND" || name === "FORWARD") {
            return code === fallbackKeys[name] || code === legacyKeys[name] || event.key === browserNames[name];
        }
        return code === map[name] || code === fallbackKeys[name] || code === legacyKeys[name] || event.key === browserNames[name];
    }

    function digitFromEvent(event) {
        var code = event.keyCode || event.which;
        var i;
        if (event.key && /^[0-9]$/.test(event.key)) {
            return event.key;
        }
        if (code >= 48 && code <= 57) {
            return String(code - 48);
        }
        if (event.key) {
            return null;
        }
        if (legacyDigits.hasOwnProperty(code)) {
            return legacyDigits[code];
        }
        if (tvKey) {
            for (i = 0; i <= 9; i += 1) {
                if (typeof tvKey["KEY_" + i] !== "undefined" && code === tvKey["KEY_" + i]) {
                    return String(i);
                }
            }
        }
        return null;
    }

    function changeVolume(direction) {
        var control;
        var muted;
        ensureSystemPlugins();

        /* API de m\u00EDdia usada nos modelos Samsung Legacy 2013/2014. */
        try {
            control = window.webapis && window.webapis.audiocontrol;
            if (control) {
                if (direction === "up" && typeof control.setVolumeUp === "function") {
                    control.setVolumeUp();
                    return true;
                }
                if (direction === "down" && typeof control.setVolumeDown === "function") {
                    control.setVolumeDown();
                    return true;
                }
                if (direction === "mute" && typeof control.setMute === "function") {
                    muted = typeof control.getMute === "function" ? control.getMute() :
                        (typeof control.isMute === "function" ? control.isMute() : false);
                    control.setMute(!muted);
                    return true;
                }
            }
        } catch (ignoreWebApi) {}

        /* Alguns firmwares exp\u00F5em o mesmo controle pelo namespace deviceapis. */
        try {
            control = window.deviceapis && window.deviceapis.audiocontrol;
            if (control) {
                if (direction === "up" && typeof control.setVolumeUp === "function") {
                    control.setVolumeUp();
                    return true;
                }
                if (direction === "down" && typeof control.setVolumeDown === "function") {
                    control.setVolumeDown();
                    return true;
                }
                if (direction === "mute" && typeof control.setMute === "function") {
                    muted = typeof control.getMute === "function" ? control.getMute() : false;
                    control.setMute(!muted);
                    return true;
                }
            }
        } catch (ignoreDeviceApi) {}

        /* Fallback do plugin nativo AUDIO. */
        try {
            if (!audio) { return false; }
            if (direction === "up") {
                audio.SetVolumeWithKey(0);
                return true;
            }
            if (direction === "down") {
                audio.SetVolumeWithKey(1);
                return true;
            }
            if (direction === "mute") {
                muted = audio.GetUserMute();
                audio.SetUserMute(muted === 1 || muted === true ? 0 : 1);
                return true;
            }
        } catch (ignoreAudioPlugin) {}

        /* \u00DAltima alternativa para firmwares que ligam volume ao PLAYER. */
        try {
            if (player && direction === "up") { player.SetVolumeWithKey(0); return true; }
            if (player && direction === "down") { player.SetVolumeWithKey(1); return true; }
        } catch (ignorePlayerVolume) {}
        return false;
    }

    function getVolume() {
        var control;
        try {
            control = window.webapis && window.webapis.audiocontrol;
            if (control && typeof control.getVolume === "function") { return control.getVolume(); }
        } catch (ignoreWebVolume) {}
        try {
            control = window.deviceapis && window.deviceapis.audiocontrol;
            if (control && typeof control.getVolume === "function") { return control.getVolume(); }
        } catch (ignoreDeviceVolume) {}
        try { if (audio) { return audio.GetVolume(); } } catch (ignoreAudioVolume) {}
        try { if (player) { return player.GetVolume(); } } catch (ignorePlayerVolume) {}
        return null;
    }

    function getCurrentTime() {
        var value;
        try {
            if (samsungLegacy && player && typeof player.GetCurrentPlayTime === "function") {
                value = Number(player.GetCurrentPlayTime());
                return isFinite(value) && value >= 0 ? value / 1000 : 0;
            }
            if (html5Player && isFinite(html5Player.currentTime)) { return html5Player.currentTime; }
        } catch (ignoreCurrentTime) {}
        return 0;
    }

    function getDuration() {
        var value;
        try {
            if (samsungLegacy && player && typeof player.GetDuration === "function") {
                value = Number(player.GetDuration());
                return isFinite(value) && value > 0 ? value / 1000 : 0;
            }
            if (html5Player && isFinite(html5Player.duration)) { return html5Player.duration; }
        } catch (ignoreDuration) {}
        return 0;
    }

    function displayRectangleForMode(mode) {
        var screenWidth = samsungLegacy ? 1280 : 960;
        var screenHeight = samsungLegacy ? 720 : 540;
        var width = screenWidth;
        var height = screenHeight;
        var left = 0;
        var top = 0;
        var videoWidth = 0;
        var videoHeight = 0;
        var videoRatio;
        var screenRatio = screenWidth / screenHeight;

        if (mode === "standard") {
            width = Math.round(screenWidth * 0.75);
            left = Math.round((screenWidth - width) / 2);
        } else if (mode === "cinema") {
            height = Math.round(screenHeight * (408 / 540));
            top = Math.round((screenHeight - height) / 2);
        } else if (mode === "auto") {
            try {
                if (samsungLegacy && player && typeof player.GetVideoWidth === "function" &&
                        typeof player.GetVideoHeight === "function") {
                    videoWidth = Number(player.GetVideoWidth()) || 0;
                    videoHeight = Number(player.GetVideoHeight()) || 0;
                } else if (html5Player) {
                    videoWidth = Number(html5Player.videoWidth) || 0;
                    videoHeight = Number(html5Player.videoHeight) || 0;
                }
            } catch (ignoreVideoSize) {}
            if (videoWidth > 0 && videoHeight > 0) {
                videoRatio = videoWidth / videoHeight;
                if (videoRatio > screenRatio) {
                    height = Math.max(1, Math.round(screenWidth / videoRatio));
                    top = Math.round((screenHeight - height) / 2);
                } else if (videoRatio < screenRatio) {
                    width = Math.max(1, Math.round(screenHeight * videoRatio));
                    left = Math.round((screenWidth - width) / 2);
                }
            }
        }
        return { left: left, top: top, width: width, height: height };
    }

    function applyDisplayMode() {
        var rect = displayRectangleForMode(playerDisplayMode);
        var legacyScale = 1280 / 960;
        try {
            if (samsungLegacy && player && typeof player.SetDisplayArea === "function") {
                player.SetDisplayArea(
                    Math.round(rect.left / legacyScale),
                    Math.round(rect.top / legacyScale),
                    Math.round(rect.width / legacyScale),
                    Math.round(rect.height / legacyScale)
                );
            }
            if (html5Player) {
                html5Player.style.left = rect.left + "px";
                html5Player.style.top = rect.top + "px";
                html5Player.style.width = rect.width + "px";
                html5Player.style.height = rect.height + "px";
                html5Player.style.objectFit = playerDisplayMode === "fullscreen" ? "fill" : "contain";
            }
        } catch (ignoreDisplayMode) {}
        return rect;
    }

    function setDisplayMode(mode) {
        if (mode !== "auto" && mode !== "fullscreen" && mode !== "standard" && mode !== "cinema") {
            mode = "auto";
        }
        playerDisplayMode = mode;
        applyDisplayMode();
        return playerDisplayMode;
    }

    function bindPlayerCallbacks() {
        if (!player) {
            return;
        }
        try {
            window.NexoLegacyPlayerCallbacks = {
                OnBufferingStart: function () {
                    playbackStarted = false;
                    if (callbacks.bufferingStart) { callbacks.bufferingStart(); }
                },
                OnBufferingProgress: function (percent) {
                    if (callbacks.bufferingProgress) { callbacks.bufferingProgress(percent); }
                },
                OnBufferingComplete: function () {
                    playbackStarted = true;
                    if (callbacks.bufferingComplete) { callbacks.bufferingComplete(); }
                },
                OnRenderingComplete: function () {
                    if (callbacks.ended) { callbacks.ended(); }
                },
                OnCurrentPlayTime: function (time) {
                    if (!playbackStarted) {
                        playbackStarted = true;
                        if (callbacks.ready) { callbacks.ready(); }
                    }
                    if (callbacks.time) { callbacks.time(Math.max(0, Number(time) || 0) / 1000, getDuration()); }
                },
                OnStreamInfoReady: function () {
                    applyDisplayMode();
                    if (callbacks.duration) { callbacks.duration(getDuration()); }
                    if (callbacks.ready) { callbacks.ready(); }
                },
                OnResolutionChanged: function () {
                    applyDisplayMode();
                },
                OnNetworkDisconnected: function () {
                    if (callbacks.error) { callbacks.error("Conex\u00E3o interrompida"); }
                },
                OnConnectionFailed: function () {
                    if (callbacks.error) { callbacks.error("N\u00E3o foi poss\u00EDvel abrir o v\u00EDdeo"); }
                },
                OnStreamNotFound: function () {
                    if (callbacks.error) { callbacks.error("V\u00EDdeo n\u00E3o encontrado"); }
                },
                OnRenderError: function () {
                    if (callbacks.error) { callbacks.error("Formato de v\u00EDdeo n\u00E3o suportado"); }
                }
            };
            player.OnBufferingStart = "NexoLegacyPlayerCallbacks.OnBufferingStart";
            player.OnBufferingProgress = "NexoLegacyPlayerCallbacks.OnBufferingProgress";
            player.OnBufferingComplete = "NexoLegacyPlayerCallbacks.OnBufferingComplete";
            player.OnRenderingComplete = "NexoLegacyPlayerCallbacks.OnRenderingComplete";
            player.OnCurrentPlayTime = "NexoLegacyPlayerCallbacks.OnCurrentPlayTime";
            player.OnStreamInfoReady = "NexoLegacyPlayerCallbacks.OnStreamInfoReady";
            player.OnNetworkDisconnected = "NexoLegacyPlayerCallbacks.OnNetworkDisconnected";
            player.OnConnectionFailed = "NexoLegacyPlayerCallbacks.OnConnectionFailed";
            player.OnStreamNotFound = "NexoLegacyPlayerCallbacks.OnStreamNotFound";
            player.OnRenderError = "NexoLegacyPlayerCallbacks.OnRenderError";
            try {
                player.OnResolutionChanged = "NexoLegacyPlayerCallbacks.OnResolutionChanged";
            } catch (ignoreResolutionCallback) {}
            /* Some desktop test shims accept functions instead of callback names. */
            if (!samsungLegacy) {
                player.OnBufferingStart = function () {
                if (callbacks.bufferingStart) { callbacks.bufferingStart(); }
                };
            }
        } catch (ignore) {}
    }

    function play(url, eventCallbacks) {
        callbacks = eventCallbacks || {};
        playerPaused = false;
        playbackStarted = false;
        if (samsungLegacy) {
            try {
                if (!ensureLegacyPlayer()) { throw new Error("Player Legacy indispon\u00EDvel"); }
                player.style.display = "block";
                html5Player.style.display = "none";
                bindPlayerCallbacks();
                applyDisplayMode();
                if (typeof player.Play === "function") {
                    player.Play(url);
                } else if (typeof player.InitPlayer === "function") {
                    player.InitPlayer(url);
                    if (typeof player.StartPlayback === "function") {
                        player.StartPlayback();
                    }
                } else {
                    throw new Error("Player Legacy indispon\u00EDvel");
                }
                return true;
            } catch (error) {
                if (callbacks.error) { callbacks.error(error.message || "Falha no player Legacy"); }
                return false;
            }
        }

        try {
            if (player) { player.style.display = "none"; }
            html5Player.style.display = "block";
            html5Player.src = url;
            html5Player.autoplay = true;
            html5Player.onwaiting = function () {
                if (callbacks.bufferingStart) { callbacks.bufferingStart(); }
            };
            html5Player.onplaying = function () {
                if (callbacks.bufferingComplete) { callbacks.bufferingComplete(); }
            };
            html5Player.ontimeupdate = function () {
                if (callbacks.time) { callbacks.time(getCurrentTime(), getDuration()); }
            };
            html5Player.ondurationchange = function () {
                applyDisplayMode();
                if (callbacks.duration) { callbacks.duration(getDuration()); }
            };
            html5Player.onloadedmetadata = function () {
                applyDisplayMode();
            };
            html5Player.onerror = function () {
                if (callbacks.error) { callbacks.error("O navegador de teste n\u00E3o conseguiu reproduzir este v\u00EDdeo"); }
            };
            html5Player.onended = function () {
                if (callbacks.ended) { callbacks.ended(); }
            };
            html5Player.play();
            return true;
        } catch (browserError) {
            if (callbacks.error) { callbacks.error(browserError.message); }
            return false;
        }
    }

    function stop() {
        try {
            if (samsungLegacy && player) {
                if (typeof player.Stop === "function") { player.Stop(); }
                if (typeof player.StopPlayer === "function") { player.StopPlayer(); }
            } else if (html5Player) {
                html5Player.pause();
                html5Player.removeAttribute("src");
                html5Player.load();
            }
        } catch (ignore) {}
    }

    function shutdown() {
        if (shuttingDown || shutdownComplete) { return; }
        shuttingDown = true;
        if (systemInitTimer) { clearTimeout(systemInitTimer); systemInitTimer = null; }
        releasePlayer();
        releaseSystemPlugins();
        try {
            if (html5Player) {
                html5Player.onwaiting = null;
                html5Player.onplaying = null;
                html5Player.ontimeupdate = null;
                html5Player.ondurationchange = null;
                html5Player.onloadedmetadata = null;
                html5Player.onerror = null;
                html5Player.onended = null;
                html5Player.pause();
                html5Player.removeAttribute("src");
            }
        } catch (ignoreHtmlShutdown) {}
        shutdownComplete = true;
        shuttingDown = false;
    }

    function togglePause() {
        try {
            if (samsungLegacy && player) {
                if (playerPaused && typeof player.Resume === "function") {
                    player.Resume();
                    playerPaused = false;
                } else if (!playerPaused && typeof player.Pause === "function") {
                    player.Pause();
                    playerPaused = true;
                }
            } else if (html5Player) {
                if (html5Player.paused) { html5Player.play(); } else { html5Player.pause(); }
            }
        } catch (ignore) {}
    }

    function seek(seconds) {
        try {
            if (samsungLegacy && player) {
                if (seconds > 0 && typeof player.JumpForward === "function") {
                    player.JumpForward(Math.round(seconds));
                    return true;
                } else if (seconds < 0 && typeof player.JumpBackward === "function") {
                    player.JumpBackward(Math.round(Math.abs(seconds)));
                    return true;
                }
            } else if (html5Player && isFinite(html5Player.currentTime)) {
                html5Player.currentTime = Math.max(0, html5Player.currentTime + seconds);
                return true;
            }
        } catch (ignore) {}
        return false;
    }

    function persistentStorageName(name) {
        return String(name || "data").replace(/[^a-z0-9_.-]/gi, "_");
    }

    function persistentStorageDirectory() {
        try {
            if (typeof curWidget !== "undefined" && curWidget && curWidget.id) { return String(curWidget.id); }
        } catch (ignoreWidgetId) {}
        return "NexoPlayHDLegacy";
    }

    function ensurePersistentDirectory(fileSystem) {
        var directory = persistentStorageDirectory();
        try {
            if (typeof fileSystem.isValidCommonPath !== "function" || !fileSystem.isValidCommonPath(directory)) {
                fileSystem.createCommonDir(directory);
            }
        } catch (ignorePersistentDirectory) {}
        return directory;
    }

    function readPersistentText(name) {
        var fileSystem;
        var file = null;
        var value = null;
        var storageName = persistentStorageName(name);
        try {
            if (typeof FileSystem !== "undefined") {
                fileSystem = new FileSystem();
                file = fileSystem.openCommonFile(ensurePersistentDirectory(fileSystem) + "/" + storageName, "r");
                if (file) { value = file.readAll(); }
                if (file) { fileSystem.closeCommonFile(file); }
                return value;
            }
        } catch (ignoreLegacyRead) {
            try { if (file && fileSystem) { fileSystem.closeCommonFile(file); } } catch (ignoreLegacyReadClose) {}
        }
        try { return window.localStorage.getItem("nexo_persistent_" + storageName); } catch (ignoreBrowserRead) {}
        return null;
    }

    function writePersistentText(name, value) {
        var fileSystem;
        var file = null;
        var storageName = persistentStorageName(name);
        value = String(value || "");
        try {
            if (typeof FileSystem !== "undefined") {
                fileSystem = new FileSystem();
                file = fileSystem.openCommonFile(ensurePersistentDirectory(fileSystem) + "/" + storageName, "w");
                if (!file) { return false; }
                file.writeAll(value);
                fileSystem.closeCommonFile(file);
                return true;
            }
        } catch (ignoreLegacyWrite) {
            try { if (file && fileSystem) { fileSystem.closeCommonFile(file); } } catch (ignoreLegacyWriteClose) {}
            return false;
        }
        try {
            window.localStorage.setItem("nexo_persistent_" + storageName, value);
            return true;
        } catch (ignoreBrowserWrite) {}
        return false;
    }

    function deletePersistentText(name) {
        var fileSystem;
        var storageName = persistentStorageName(name);
        try {
            if (typeof FileSystem !== "undefined") {
                fileSystem = new FileSystem();
                fileSystem.deleteCommonFile(ensurePersistentDirectory(fileSystem) + "/" + storageName);
            }
        } catch (ignoreLegacyDelete) {}
        try { window.localStorage.removeItem("nexo_persistent_" + storageName); } catch (ignoreBrowserDelete) {}
    }

    function exitApp() {
        try {
            if (window.NexoApp && typeof window.NexoApp.shutdown === "function") {
                window.NexoApp.shutdown();
            } else {
                shutdown();
            }
        } catch (ignoreAppShutdown) {
            shutdown();
        }
        try {
            if (widgetAPI) {
                widgetAPI.sendExitEvent();
                return;
            }
        } catch (ignore) {}
        window.close();
    }

    return {
        init: init,
        resume: resume,
        keys: keys,
        isKey: isKey,
        digitFromEvent: digitFromEvent,
        changeVolume: changeVolume,
        getVolume: getVolume,
        getCurrentTime: getCurrentTime,
        getDuration: getDuration,
        setDisplayMode: setDisplayMode,
        isSamsungLegacy: function () { return samsungLegacy; },
        shutdown: shutdown,
        play: play,
        stop: stop,
        togglePause: togglePause,
        seek: seek,
        readPersistentText: readPersistentText,
        writePersistentText: writePersistentText,
        deletePersistentText: deletePersistentText,
        exitApp: exitApp
    };
}());
