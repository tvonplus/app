var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.034-legacy-json-jsdelivr",
    accessCodeUrl: "https://cdn.jsdelivr.net/gh/nexoplay88/app@main/Aplicativos/dns-codigos/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
