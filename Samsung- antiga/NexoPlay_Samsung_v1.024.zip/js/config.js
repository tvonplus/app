var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.024-legacy-force-access-codes",
    accessCodeUrl: "https://tvonplus.github.io/app/nexo_play_codigos.json",
    accessCodeRetryWindow: 60000,
    accessCodeAttemptTimeout: 6000,
    accessCodeRetryDelay: 900,
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
