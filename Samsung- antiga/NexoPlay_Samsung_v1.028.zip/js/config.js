var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.028-legacy-themes-home-back-jsdelivr",
    accessCodeUrl: "https://cdn.jsdelivr.net/gh/tvonplus/app@main/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
