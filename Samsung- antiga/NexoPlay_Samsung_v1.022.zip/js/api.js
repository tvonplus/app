var NexoApi = (function () {
    function cacheBustedUrl(url) {
        return url + (url.indexOf("?") >= 0 ? "&" : "?") + "_nexo=" + new Date().getTime();
    }

    function requestJson(url, timeout, callback, maxAttempts) {
        var attempt = 0;
        maxAttempts = parseInt(maxAttempts || 2, 10);
        if (maxAttempts < 1) { maxAttempts = 1; }

        function run() {
            var xhr = new XMLHttpRequest();
            var finished = false;
            var timer;

            function fail(error) {
                if (finished) { return; }
                finished = true;
                clearTimeout(timer);
                try { xhr.abort(); } catch (ignore) {}
                if (attempt < maxAttempts) {
                    setTimeout(run, 220);
                } else {
                    callback(error);
                }
            }

            attempt += 1;
            timer = setTimeout(function () {
                fail(new Error("Tempo de conex\u00E3o esgotado"));
            }, timeout || NEXO_CONFIG.requestTimeout);

            try {
                xhr.open("GET", cacheBustedUrl(url), true);
                xhr.onreadystatechange = function () {
                    var data;
                    if (xhr.readyState !== 4 || finished) {
                        return;
                    }
                    if ((xhr.status >= 200 && xhr.status < 300) || (xhr.status === 0 && xhr.responseText)) {
                        finished = true;
                        clearTimeout(timer);
                        try {
                            data = JSON.parse(xhr.responseText);
                            callback(null, data);
                        } catch (parseError) {
                            callback(new Error("Resposta inv\u00E1lida do servidor"));
                        }
                    } else {
                        fail(new Error("Falha HTTP " + xhr.status));
                    }
                };
                xhr.onerror = function () {
                    fail(new Error("Falha de conex\u00E3o"));
                };
                xhr.send(null);
            } catch (error) {
                fail(error);
            }
        }

        run();
    }

    function hasAccessCodes(data) {
        return !!(data && data.codigos && typeof data.codigos === "object");
    }

    function saveAccessCodesCache(data) {
        var saved;
        try {
            saved = { savedAt: new Date().getTime(), data: data };
            localStorage.setItem(NEXO_CONFIG.accessCodeCacheKey || "nexo_legacy_access_codes", JSON.stringify(saved));
        } catch (ignore) {}
    }

    function loadAccessCodesCache() {
        var saved;
        var maxAge;
        var savedAt;
        try {
            saved = JSON.parse(localStorage.getItem(NEXO_CONFIG.accessCodeCacheKey || "nexo_legacy_access_codes") || "null");
            maxAge = parseInt(NEXO_CONFIG.accessCodeCacheMaxAge || 0, 10);
            savedAt = parseInt(saved && saved.savedAt, 10);
            if (!hasAccessCodes(saved && saved.data) || !savedAt) {
                return null;
            }
            if (maxAge > 0 && new Date().getTime() - savedAt > maxAge) {
                return null;
            }
            return saved.data;
        } catch (ignore) {
            return null;
        }
    }

    function loadAccessCodes(callback) {
        var urls = [];
        var index = 0;
        var lastError = null;

        function addUrl(url) {
            var i;
            if (!url) { return; }
            for (i = 0; i < urls.length; i += 1) {
                if (urls[i] === url) { return; }
            }
            urls.push(url);
        }

        function next() {
            var cached;
            var url;
            if (index >= urls.length) {
                cached = loadAccessCodesCache();
                if (cached) {
                    callback(null, cached, true);
                    return;
                }
                callback(lastError || new Error("N\u00E3o foi poss\u00EDvel validar o c\u00F3digo online"));
                return;
            }
            url = urls[index];
            index += 1;
            requestJson(url, NEXO_CONFIG.accessCodeTimeout || NEXO_CONFIG.requestTimeout, function (error, data) {
                if (!error && hasAccessCodes(data)) {
                    saveAccessCodesCache(data);
                    callback(null, data, false);
                    return;
                }
                lastError = error || new Error("Resposta sem c\u00F3digos dispon\u00EDveis");
                next();
            }, 1);
        }

        addUrl(NEXO_CONFIG.accessCodeUrl);
        addUrl(NEXO_CONFIG.accessCodeFallbackUrl);
        next();
    }

    function normalizeHost(host) {
        return String(host || "").replace(/\/+$/, "");
    }

    function apiUrl(server, username, password, action, extra) {
        var url = normalizeHost(server.serverHost) + "/player_api.php?username=" + encodeURIComponent(username) + "&password=" + encodeURIComponent(password);
        if (action) { url += "&action=" + encodeURIComponent(action); }
        if (extra) { url += extra; }
        return url;
    }

    function flattenServers(codeEntry) {
        var result = [];
        var sources = codeEntry && codeEntry.fontes ? codeEntry.fontes : [];
        var i;
        var j;
        for (i = 0; i < sources.length; i += 1) {
            for (j = 0; j < (sources[i].servidores || []).length; j += 1) {
                result.push({
                    sourceName: sources[i].nomeFonte || ("Fonte " + (i + 1)),
                    sourceIndex: i,
                    serverIndex: j,
                    serverName: sources[i].servidores[j].serverName,
                    serverHost: normalizeHost(sources[i].servidores[j].serverHost)
                });
            }
        }
        return result;
    }

    function checkServer(server, username, password, callback, timeout) {
        requestJson(apiUrl(server, username, password), timeout || NEXO_CONFIG.serverTimeout, function (error, data) {
            var authenticated = data && data.user_info && (data.user_info.auth === 1 || data.user_info.auth === "1");
            if (error || !authenticated) {
                callback(error || new Error("Usu\u00E1rio n\u00E3o autorizado"));
                return;
            }
            callback(null, data);
        });
    }

    function findWorkingServer(servers, username, password, progress, callback, options) {
        var index = 0;
        var startedAt = new Date().getTime();
        var maxDuration;
        var retryDelay;
        var attempts = 0;

        options = options || {};
        maxDuration = parseInt(options.maxDuration || 0, 10);
        retryDelay = parseInt(options.retryDelay || 500, 10);

        function elapsed() {
            return new Date().getTime() - startedAt;
        }

        function isExpired() {
            return maxDuration > 0 && elapsed() >= maxDuration;
        }

        function next() {
            var current;
            var remaining;
            var checkTimeout;
            if (!servers || !servers.length) {
                callback(new Error("Nenhum servidor dispon\u00EDvel"));
                return;
            }
            if (isExpired()) {
                callback(new Error("Nenhum servidor respondeu ap\u00F3s 1 minuto"));
                return;
            }
            if (index >= servers.length) {
                if (maxDuration > 0) {
                    index = 0;
                    setTimeout(next, retryDelay);
                    return;
                }
                callback(new Error("Nenhum servidor aceitou este usu\u00E1rio e senha"));
                return;
            }
            current = servers[index];
            attempts += 1;
            if (progress) { progress(current, index + 1, servers.length, elapsed(), attempts); }
            remaining = maxDuration > 0 ? Math.max(1000, maxDuration - elapsed()) : NEXO_CONFIG.serverTimeout * 2;
            checkTimeout = Math.min(NEXO_CONFIG.serverTimeout, Math.max(1000, Math.floor(remaining / 2)));
            checkServer(current, username, password, function (error, account) {
                index += 1;
                if (!error) {
                    callback(null, current, account);
                } else {
                    next();
                }
            }, checkTimeout);
        }
        next();
    }

    function getCategories(session, type, callback) {
        var actions = {
            live: "get_live_categories",
            movie: "get_vod_categories",
            series: "get_series_categories"
        };
        requestJson(apiUrl(session.server, session.username, session.password, actions[type]), NEXO_CONFIG.requestTimeout, callback);
    }

    function getItems(session, type, categoryId, callback) {
        var actions = {
            live: "get_live_streams",
            movie: "get_vod_streams",
            series: "get_series"
        };
        var extra = categoryId ? "&category_id=" + encodeURIComponent(categoryId) : "";
        requestJson(apiUrl(session.server, session.username, session.password, actions[type], extra), NEXO_CONFIG.requestTimeout, callback);
    }

    function getAllItems(session, type, callback) {
        var actions = {
            live: "get_live_streams",
            movie: "get_vod_streams",
            series: "get_series"
        };
        requestJson(apiUrl(session.server, session.username, session.password, actions[type]), NEXO_CONFIG.searchTimeout, callback);
    }

    function getSeriesInfo(session, seriesId, callback) {
        requestJson(apiUrl(session.server, session.username, session.password, "get_series_info", "&series_id=" + encodeURIComponent(seriesId)), NEXO_CONFIG.requestTimeout, callback);
    }

    function getMovieInfo(session, movieId, callback) {
        requestJson(apiUrl(session.server, session.username, session.password, "get_vod_info", "&vod_id=" + encodeURIComponent(movieId)), NEXO_CONFIG.requestTimeout, callback);
    }

    function sortNewest(items) {
        var copy = (items || []).slice(0);
        copy.sort(function (a, b) {
            return parseInt(b.added || b.last_modified || 0, 10) - parseInt(a.added || a.last_modified || 0, 10);
        });
        return copy;
    }

    function streamUrl(session, type, item) {
        var host = normalizeHost(session.server.serverHost);
        var extension = item.container_extension || (type === "live" ? "ts" : "mp4");
        var id = item.stream_id || item.id;
        var folder = type === "movie" ? "movie" : "live";
        if (item.direct_source) { return item.direct_source; }
        return host + "/" + folder + "/" + encodeURIComponent(session.username) + "/" + encodeURIComponent(session.password) + "/" + id + "." + extension;
    }

    function episodeUrl(session, episode) {
        var host = normalizeHost(session.server.serverHost);
        var extension = episode.container_extension || "mp4";
        var id = episode.id || episode.stream_id;
        if (episode.direct_source) { return episode.direct_source; }
        return host + "/series/" + encodeURIComponent(session.username) + "/" + encodeURIComponent(session.password) + "/" + id + "." + extension;
    }

    return {
        requestJson: requestJson,
        loadAccessCodes: loadAccessCodes,
        flattenServers: flattenServers,
        checkServer: checkServer,
        findWorkingServer: findWorkingServer,
        getCategories: getCategories,
        getItems: getItems,
        getAllItems: getAllItems,
        getMovieInfo: getMovieInfo,
        getSeriesInfo: getSeriesInfo,
        sortNewest: sortNewest,
        streamUrl: streamUrl,
        episodeUrl: episodeUrl
    };
}());
