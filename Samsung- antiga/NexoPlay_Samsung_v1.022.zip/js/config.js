var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.022-legacy-code-fallback",
    accessCodeUrl: "https://tvonplus.github.io/app/nexo_play_codigos.json",
    accessCodeFallbackUrl: "https://raw.githubusercontent.com/tvonplus/app/main/nexo_play_codigos.json",
    accessCodeTimeout: 7000,
    accessCodeCacheKey: "nexo_legacy_access_codes_v1",
    accessCodeCacheMaxAge: 86400000,
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
