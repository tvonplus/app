/* Medicao sob demanda, ES5 e uma transferencia por vez. Nenhum teste em segundo plano. */
var NexoSpeedTest = (function () {
    var request = null;
    var timer = null;
    var generation = 0;
    var networkPlugin = null;

    function cancel() {
        generation += 1;
        if (timer) { clearTimeout(timer); timer = null; }
        if (request) {
            request.onreadystatechange = request.onprogress = request.onerror = null;
            try { request.abort(); } catch (ignoreAbort) {}
            request = null;
        }
    }

    function connectionType() {
        var host;
        var value;
        var api;
        var types;
        try {
            /* Legacy NETWORK: GetActiveType() retorna 0 Wi-Fi, 1 cabo, -1 sem interface. */
            if (!networkPlugin && window.Common && window.Common.API) {
                host = document.getElementById("nativePluginHost");
                if (host) {
                    networkPlugin = document.createElement("object");
                    networkPlugin.id = "nexo-settings-network";
                    networkPlugin.setAttribute("classid", "clsid:SAMSUNG-INFOLINK-NETWORK");
                    host.appendChild(networkPlugin);
                    if (networkPlugin.CreatePlugin) { networkPlugin.CreatePlugin(); }
                }
            }
            if (networkPlugin && networkPlugin.GetActiveType) {
                value = networkPlugin.GetActiveType();
                if (value === 0) { return "wifi"; }
                if (value === 1) { return "ethernet"; }
                if (value === -1) { return "none"; }
            }
        } catch (ignoreLegacyNetwork) {}
        try {
            api = window.webapis && window.webapis.network;
            types = api && api.NetworkActiveConnectionType;
            if (api && api.getActiveConnectionType && types) {
                value = api.getActiveConnectionType();
                if (value === types.WIFI) { return "wifi"; }
                if (value === types.ETHERNET) { return "ethernet"; }
                if (value === types.DISCONNECTED) { return "none"; }
            }
            api = window.navigator && (window.navigator.connection || window.navigator.webkitConnection);
            if (api && (api.type === "wifi" || api.type === "ethernet")) { return api.type; }
        } catch (ignoreNetworkInfo) {}
        return "unknown";
    }

    function assessment(mbps, connection) {
        var label;
        var advice;
        if (mbps < 5) {
            label = "Velocidade baixa";
            advice = "Velocidade indicada para qualidade mais baixa. Repita o teste para conferir sua conex\u00E3o.";
        } else if (mbps < 15) {
            label = "Regular para IPTV";
            advice = "Velocidade indicada para qualidade padr\u00E3o e HD.";
        } else if (mbps < 30) {
            label = "Boa para IPTV";
            advice = "Velocidade indicada para assistir em HD e Full HD.";
        } else if (mbps < 50) {
            label = "Muito boa para IPTV";
            advice = "Velocidade muito boa para assistir em Full HD e alta qualidade.";
        } else {
            label = "Excelente para IPTV";
            advice = "Velocidade excelente para assistir em alta qualidade.";
        }
        if (mbps < 10 && connection === "wifi") {
            advice += " O Wi-Fi est\u00E1 lento: conecte a TV por cabo de rede e repita o teste.";
        } else if (mbps < 10 && connection === "unknown") {
            advice += " Se estiver no Wi-Fi, tente conectar a TV por cabo de rede.";
        }
        return { label: label, advice: advice };
    }

    function start(onProgress, onComplete) {
        var token;
        var serverIndex = 0;
        var totalBytes = 0;
        var totalMs = 0;
        var servers = ["https://speed.cloudflare.com/__down", "http://cachefly.cachefly.net/10mb.test", "http://speedtest.tele2.net/10MB.zip"];
        cancel();
        token = generation;

        function complete(error) {
            var mbps = totalMs > 0 ? totalBytes * 8 / totalMs / 1000 : 0;
            if (token !== generation) { return; }
            cancel();
            onComplete(error, error ? null : { mbps: mbps, bytes: totalBytes, duration: totalMs });
        }

        function download(bytes, warmup) {
            var xhr;
            var started;
            var loaded = 0;
            var lastProgress = 0;
            var done = false;
            var binary = false;
            var url = servers[serverIndex];
            if (token !== generation) { return; }
            if (serverIndex === 0) { url += "?bytes=" + bytes; }
            url += (url.indexOf("?") >= 0 ? "&" : "?") + "nexo=" + new Date().getTime() + "-" + Math.random();
            onProgress({ phase: warmup ? "Preparando a medi\u00E7\u00E3o..." : "Medindo a velocidade...", percent: warmup ? 5 : 20 });

            function finish(failed, timedOut) {
                var elapsed;
                var status = 0;
                var contentType = "";
                if (done || token !== generation) { return; }
                done = true;
                elapsed = Math.max(1, new Date().getTime() - started);
                if (timer) { clearTimeout(timer); timer = null; }
                try {
                    status = xhr.status;
                    contentType = xhr.getResponseHeader("Content-Type") || "";
                    if (!failed && xhr.readyState === 4) {
                        if (binary && xhr.response) { loaded = xhr.response.byteLength; }
                        else if (!binary && xhr.responseText) { loaded = xhr.responseText.length; }
                    }
                } catch (ignoreResponse) { failed = true; }
                if ((status !== 200 && status !== 206) || /text\/html|application\/json/i.test(contentType)) { failed = true; }
                xhr.onreadystatechange = xhr.onprogress = xhr.onerror = null;
                if (xhr.readyState !== 4) { try { xhr.abort(); } catch (ignoreAbort) {} }
                request = null;
                if (timedOut && loaded < 65536) { failed = true; }
                if (loaded < 1024) { failed = true; }
                if (failed) {
                    if (totalBytes >= 65536) { complete(null); return; }
                    serverIndex += 1;
                    totalBytes = totalMs = 0;
                    if (serverIndex >= servers.length) { complete(new Error("test-unavailable")); return; }
                    onProgress({ phase: "Tentando outro servidor de teste...", percent: 5 });
                    download(250000, true);
                    return;
                }
                if (warmup) { download(1000000, false); return; }
                totalBytes += loaded;
                totalMs += elapsed;
                if (bytes === 1000000 && elapsed < 1300 && !timedOut) { download(4000000, false); }
                else { complete(null); }
            }

            try {
                xhr = new XMLHttpRequest();
                request = xhr;
                xhr.open("GET", url, true);
                try { xhr.responseType = "arraybuffer"; binary = xhr.responseType === "arraybuffer"; } catch (ignoreBinary) {}
                if (!binary && xhr.overrideMimeType) { xhr.overrideMimeType("text/plain; charset=x-user-defined"); }
                started = new Date().getTime();
                xhr.onprogress = function (event) {
                    var now;
                    if (done || token !== generation) { return; }
                    loaded = event.loaded || loaded;
                    if (loaded >= bytes) { finish(false, false); return; }
                    now = new Date().getTime();
                    if (now - lastProgress >= 250) {
                        lastProgress = now;
                        onProgress({ phase: warmup ? "Preparando a medi\u00E7\u00E3o..." : "Medindo a velocidade...",
                            percent: warmup ? 10 : Math.min(95, 20 + Math.round(loaded / bytes * 75)) });
                    }
                };
                xhr.onreadystatechange = function () { if (xhr.readyState === 4) { finish(false, false); } };
                xhr.onerror = function () { finish(true, false); };
                timer = setTimeout(function () { finish(false, true); }, 12000);
                xhr.send(null);
            } catch (error) {
                if (xhr) { finish(true, false); }
                else { complete(error); }
            }
        }

        download(250000, true);
    }

    return { start: start, cancel: cancel, connectionType: connectionType, assessment: assessment };
}());
