var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.023-legacy-code-retry",
    accessCodeUrl: "https://tvonplus.github.io/app/nexo_play_codigos.json",
    accessCodeRetryWindow: 60000,
    accessCodeAttemptTimeout: 7000,
    accessCodeRetryDelay: 1000,
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
