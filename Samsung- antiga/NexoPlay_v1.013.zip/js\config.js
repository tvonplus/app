var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.0.37-legacy-migration-player-compact",
    accessCodeUrl: "https://tvonplus.github.io/app/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
