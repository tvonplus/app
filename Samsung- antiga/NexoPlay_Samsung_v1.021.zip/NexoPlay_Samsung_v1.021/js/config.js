var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.021-legacy-home-light-logo",
    accessCodeUrl: "http://huggingface.co/datasets/nexoplay/app/resolve/main/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
