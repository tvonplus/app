/* Configuracoes locais. O catalogo e o player continuam sob responsabilidade do NexoApp. */
var NexoSettings = (function () {
    var callbacks = {};
    var activeSection = "network";
    var themeId = "petroleo";
    var themeKey = "nexo_legacy_theme";
    var themes = [
        { id: "preto", name: "Preto", bg: "#000000", panel: "#111111", surface: "#090909", border: "#4b4b4b", text: "#f5f5f5", muted: "#bebebe", accent: "#242424", highlight: "#d5d5d5" },
        { id: "violeta", name: "Violeta", bg: "#180e26", panel: "#29163e", surface: "#201030", border: "#795891", text: "#faf5ff", muted: "#d3c1e2", accent: "#663b85", highlight: "#dcacff" },
        { id: "cinza", name: "Cinza", bg: "#16191d", panel: "#282d34", surface: "#1c2026", border: "#626e7b", text: "#f6f7f9", muted: "#c5ccd3", accent: "#48596b", highlight: "#b9d4ef" },
        { id: "petroleo", name: "Petr\u00F3leo", bg: "#061d2d", panel: "#08263a", surface: "#03131e", border: "#466a80", text: "#f5f5f5", muted: "#c8d7e0", accent: "#15558a", highlight: "#8fc6c2" },
        { id: "verde", name: "Verde", bg: "#091e18", panel: "#13382b", surface: "#0b281f", border: "#477c64", text: "#f4faf6", muted: "#bfd9ca", accent: "#236647", highlight: "#9fe0b8" },
        { id: "cafe", name: "Caf\u00E9", bg: "#21150e", panel: "#39261c", surface: "#2b1a12", border: "#8b6851", text: "#fff8f1", muted: "#dec9b9", accent: "#76503a", highlight: "#ecc19c" },
        { id: "ambar", name: "\u00C2mbar", bg: "#201807", panel: "#392c10", surface: "#291e09", border: "#927336", text: "#fff9e9", muted: "#e0d0a9", accent: "#80601c", highlight: "#f4cf78" },
        { id: "claro", name: "Claro", bg: "#e8edf3", panel: "#f9fbfd", surface: "#dce5ee", border: "#70889d", text: "#1e3448", muted: "#405b72", accent: "#bed8ee", highlight: "#1b6092" }
    ];

    function byId(id) { return document.getElementById(id); }
    function text(element, value) {
        while (element.firstChild) { element.removeChild(element.firstChild); }
        element.appendChild(document.createTextNode(String(value)));
    }
    function node(tag, className, value) {
        var element = document.createElement(tag);
        element.className = className || "";
        if (typeof value !== "undefined") { text(element, value); }
        return element;
    }
    function button(className, action, label) {
        var element = node("button", className + " focusable", label);
        element.setAttribute("data-action", action);
        return element;
    }
    function findTheme(id) {
        var i;
        for (i = 0; i < themes.length; i += 1) { if (themes[i].id === id) { return themes[i]; } }
        return null;
    }

    function applyTheme() {
        var palette = findTheme(themeId) || findTheme("petroleo");
        var style = byId("nexo-theme-style");
        var css = "";
        var focusBg = themeId === "claro" ? "#173e61" : "#f4f4f3";
        var focusText = themeId === "claro" ? "#ffffff" : "#414b56";
        var logos = document.querySelectorAll(".menu-logo,.login-logo,.splash-logo");
        var logoSource = themeId === "claro" ? "images/nexo-play-logo-light.png" : "images/nexo-play-logo.png";
        var logoIndex;
        for (logoIndex = 0; logoIndex < logos.length; logoIndex += 1) {
            if (logos[logoIndex].getAttribute("src") !== logoSource) { logos[logoIndex].setAttribute("src", logoSource); }
        }
        function rule(selector, properties) { css += selector + "{" + properties + "}\n"; }
        function rgba(hex, alpha) {
            hex = String(hex || "#000000").replace("#", "");
            return "rgba(" + parseInt(hex.substr(0, 2), 16) + "," + parseInt(hex.substr(2, 2), 16) + "," + parseInt(hex.substr(4, 2), 16) + "," + alpha + ")";
        }
        if (!style) {
            style = document.createElement("style");
            style.id = "nexo-theme-style";
            style.type = "text/css";
            document.getElementsByTagName("head")[0].appendChild(style);
        }
        /* O padrao conserva exatamente as cores anteriores, inclusive os detalhes do player. */
        if (themeId !== "petroleo") {
            rule("html,body,#screen-main,#screen-login,#screen-splash,.content-area", "background:" + palette.bg + ";color:" + palette.text + ";");
            rule(".modal-backdrop", "background:" + rgba(palette.bg, 0.78) + ";");
            rule(".background-status", "background:" + rgba(palette.bg, 0.8) + ";");
            rule(".global-loading", "background:" + rgba(palette.surface, 0.9) + ";color:" + palette.text + ";");
            rule(".side-menu,.login-panel,.modal,.settings-panel,.background-status-card,.series-season-menu,.player-season-menu,.toast,.volume-osd,.home-empty",
                "background:" + palette.panel + ";border-color:" + palette.border + ";color:" + palette.text + ";");
            rule(".login-field,.primary-button,.poster-card,.list-row,.saved-live-card,.favorite-group-header,.favorite-carousel-arrow,.continue-delete-button,.home-tile,.modal-button,.category-button,.catalog-search-button,.server-source-button,.server-refresh-button,.auto-update-option,.parental-pin-cell,.parental-key,.parental-action-button,.parental-type-button,.parental-category-button,.detail-play-button,.detail-favorite-button,.series-season-selector,.series-detail-favorite-button,.series-season-option,.series-episode-card,.search-value,.search-key,.search-action,.player-control-button,.player-season-option,.settings-tab,.settings-action,.settings-theme",
                "background:" + palette.surface + ";border-color:" + palette.border + ";color:" + palette.text + ";");
            rule(".home-more,.home-shortcut", "background:" + palette.panel + ";border-color:" + palette.border + ";color:" + palette.text + ";");
            rule(".menu-item,.poster-card .card-name,.continue-card-info,.saved-live-name,.parental-category-name,.series-episode-title,.media-detail-content h3,.saved-search-result",
                "color:" + palette.text + ";");
            rule(".catalog-grid .catalog-poster-card .card-name", "background:" + palette.surface + ";color:" + palette.text + ";");
            rule(".subtitle,.field-label,.key-help,.connected-user,.server-info,.content-header p,.list-subtitle,.favorite-server-label,.continue-card-info small,.continue-card-info span,.saved-group-title,.saved-group-empty,.empty-state,.modal p,.parental-category-button small,.detail-meta,.detail-synopsis,.detail-extra,.home-tile small,.settings-description,.settings-note,.settings-help,.speed-test-phase,.app-version,.home-shortcut small,.home-empty p,.home-help,#screen-splash p",
                "color:" + palette.muted + ";");
            rule(".side-menu,.content-header,.connected-user,.server-info,.media-detail-poster", "border-color:" + palette.border + ";");
            rule(".active-season,.active-season-option,.server-source-button.active-source,.parental-type-button.active-parental-type,.auto-update-option.active-option,.settings-tab.active-settings-tab",
                "background:" + palette.accent + ";border-color:" + palette.highlight + ";");
            rule(".settings-theme.selected-theme,.detail-favorite-button.is-favorite", "border-color:" + palette.highlight + ";");
            rule(".speed-test-track,.continue-card-timeline", "background:" + palette.surface + ";");
            rule(".speed-test-bar,.continue-card-timeline span,.player-timeline-progress", "background:" + palette.highlight + ";");
            rule(".focusable.focused", "background:" + focusBg + "!important;border-color:" + focusBg + "!important;color:" + focusText + "!important;");
            rule(".series-season-selector.single-season", "border-color:" + palette.border + ";color:" + palette.text + ";");
            rule(".series-episode-card.focused .series-episode-title", "color:" + focusText + "!important;");
            rule(".login-field.focused .field-label,.login-field.focused .field-value,.list-row.focused .list-subtitle,.parental-category-button.focused small,.parental-category-button.focused .parental-lock-state,.home-tile.focused small,.home-shortcut.focused small,.favorite-group-header.focused .favorite-group-arrow",
                "color:" + focusText + ";");
            /* A variante clara tem NEXO cinza e transparencia real, sem fundo artificial. */
            if (themeId === "claro") {
                rule(".catalog-search-icon", "background:#173e61;border-radius:4px;");
                rule(".focused .catalog-search-icon", "background:#f4f4f3;");
                rule(".menu-item-icon", "background:transparent;border-radius:0;");
            }
        }
        if (style.styleSheet) { style.styleSheet.cssText = css; }
        else { text(style, css); }
        document.body.setAttribute("data-nexo-theme", themeId);
    }

    function init(options) {
        var saved;
        callbacks = options || {};
        try { saved = window.localStorage.getItem(themeKey); } catch (ignoreLoad) {}
        if (saved === "azul") {
            saved = "preto";
            try { window.localStorage.setItem(themeKey, saved); } catch (ignoreMigration) {}
        }
        themeId = findTheme(saved) ? saved : "petroleo";
        applyTheme();
        if (callbacks.refreshMenuIcons) { callbacks.refreshMenuIcons(); }
    }

    function render(username) {
        var root = byId("content-root");
        var tabs = node("div", "settings-tabs");
        var sections = [
            { id: "network", name: "Rede" }, { id: "themes", name: "Temas" },
            { id: "parental", name: "Controle parental" }, { id: "account", name: "Conta" }
        ];
        var panel = node("div", "settings-panel");
        var tab;
        var i;
        root.innerHTML = "";
        root.setAttribute("data-settings-user", username || "");
        for (i = 0; i < sections.length; i += 1) {
            tab = button("settings-tab", "settings-section", sections[i].name);
            tab.setAttribute("data-section", sections[i].id);
            tabs.appendChild(tab);
        }
        panel.id = "settings-panel";
        root.appendChild(tabs);
        root.appendChild(panel);
        root.appendChild(node("p", "settings-help", "Setas: navegar \u2022 OK: selecionar \u2022 RETURN: voltar ao menu"));
        selectSection(activeSection);
    }

    function selectedTab() {
        var tabs = byId("content-root").getElementsByClassName("settings-tab");
        var i;
        for (i = 0; i < tabs.length; i += 1) { if (tabs[i].getAttribute("data-section") === activeSection) { return tabs[i]; } }
        return tabs[0];
    }

    function refreshThemeChecks() {
        var items = byId("settings-panel").getElementsByClassName("settings-theme");
        var i;
        var selected;
        for (i = 0; i < items.length; i += 1) {
            selected = items[i].getAttribute("data-theme") === themeId;
            items[i].className = "settings-theme focusable" + (selected ? " selected-theme" : "") +
                (items[i].className.indexOf(" focused") >= 0 ? " focused" : "");
            items[i].setAttribute("aria-pressed", selected ? "true" : "false");
            text(items[i].getElementsByClassName("settings-theme-check")[0], selected ? "\u2713" : "");
        }
    }

    function renderThemes(panel) {
        var grid = node("div", "settings-theme-grid");
        var item;
        var swatch;
        var sample;
        var i;
        panel.className += " settings-theme-panel";
        panel.appendChild(node("h3", "", "Tema do aplicativo"));
        panel.appendChild(node("p", "settings-description", "Escolha uma cor. A mudan\u00E7a aparece na hora, inclusive nos modais."));
        for (i = 0; i < themes.length; i += 1) {
            item = button("settings-theme", "settings-theme", "");
            item.setAttribute("data-theme", themes[i].id);
            item.setAttribute("aria-label", themes[i].name);
            swatch = node("span", "settings-theme-swatch");
            swatch.style.backgroundColor = themes[i].bg;
            sample = node("span", "");
            sample.style.backgroundColor = themes[i].accent;
            swatch.appendChild(sample);
            item.appendChild(swatch);
            item.appendChild(node("span", "settings-theme-name", themes[i].name));
            item.appendChild(node("span", "settings-theme-check", ""));
            grid.appendChild(item);
        }
        panel.appendChild(grid);
        panel.appendChild(node("p", "settings-note", "O tema escolhido fica salvo nesta TV."));
        refreshThemeChecks();
    }

    function selectSection(section) {
        var panel = byId("settings-panel");
        var tabs = byId("content-root").getElementsByClassName("settings-tab");
        var i;
        var active;
        var connection;
        if (!panel) { return; }
        activeSection = section;
        for (i = 0; i < tabs.length; i += 1) {
            active = tabs[i].getAttribute("data-section") === section;
            tabs[i].className = "settings-tab focusable" + (active ? " active-settings-tab" : "") +
                (tabs[i].className.indexOf(" focused") >= 0 ? " focused" : "");
            tabs[i].setAttribute("aria-selected", active ? "true" : "false");
        }
        panel.className = "settings-panel";
        panel.innerHTML = "";
        if (section === "themes") { renderThemes(panel); return; }
        if (section === "network") {
            connection = NexoSpeedTest.connectionType();
            panel.appendChild(node("h3", "", "Teste de velocidade"));
            panel.appendChild(node("p", "settings-description", "Confira a velocidade dispon\u00EDvel nesta TV e uma orienta\u00E7\u00E3o para assistir IPTV."));
            panel.appendChild(button("settings-action", "settings-speed-test", "Testar velocidade da internet"));
            panel.appendChild(node("p", "settings-note", "Conex\u00E3o: " + (connection === "wifi" ? "Wi-Fi" : connection === "ethernet" ? "Cabo de rede" : connection === "none" ? "sem interface ativa" : "tipo n\u00E3o informado pela TV") +
                ".\nO teste usa um pequeno download e s\u00F3 come\u00E7a quando voc\u00EA selecionar o bot\u00E3o."));
        } else if (section === "parental") {
            panel.appendChild(node("h3", "", "Controle parental"));
            panel.appendChild(node("p", "settings-description", "Gerencie o PIN e o bloqueio das categorias de TV ao vivo, filmes e s\u00E9ries."));
            panel.appendChild(button("settings-action", "parental", "Abrir controle parental"));
            panel.appendChild(node("p", "settings-note", "Seu PIN atual continua v\u00E1lido. O aplicativo pede o PIN antes de permitir altera\u00E7\u00F5es."));
        } else if (section === "account") {
            panel.appendChild(node("h3", "", "Conta conectada"));
            panel.appendChild(node("p", "settings-description", "Usu\u00E1rio: " + (byId("content-root").getAttribute("data-settings-user") || "n\u00E3o informado")));
            panel.appendChild(button("settings-action", "logout", "Desconectar desta TV"));
            panel.appendChild(node("p", "settings-note", "Antes de desconectar, voc\u00EA ver\u00E1 uma confirma\u00E7\u00E3o. O acesso salvo e o hist\u00F3rico ser\u00E3o removidos, como j\u00E1 acontece no aplicativo."));
        }
    }

    function startSpeedTest() {
        var content = byId("modal-content");
        var value = node("div", "speed-test-value", "-- Mbps");
        var phase = node("div", "speed-test-phase", "Preparando o teste...");
        var track = node("div", "speed-test-track");
        var bar = node("div", "speed-test-bar");
        var advice = node("div", "speed-test-advice", "Aguarde. Voc\u00EA pode cancelar com RETURN ou pelo bot\u00E3o abaixo.");
        var actions = node("div", "speed-test-actions");
        var close = button("modal-button", "modal-close", "Cancelar");
        var retry = button("modal-button hidden", "settings-speed-retest", "Testar novamente");
        var connection = NexoSpeedTest.connectionType();
        NexoSpeedTest.cancel();
        content.innerHTML = "";
        track.appendChild(bar);
        content.appendChild(value);
        content.appendChild(phase);
        content.appendChild(track);
        content.appendChild(advice);
        actions.appendChild(close);
        actions.appendChild(retry);
        content.appendChild(actions);
        callbacks.focus(close);
        NexoSpeedTest.start(function (update) {
            text(phase, update.phase);
            bar.style.width = update.percent + "%";
        }, function (error, result) {
            var grade;
            text(close, "Fechar");
            retry.className = "modal-button focusable";
            bar.style.width = "100%";
            if (error) {
                text(value, "Teste indispon\u00EDvel");
                value.style.fontSize = "27px";
                text(phase, "N\u00E3o foi poss\u00EDvel medir agora.");
                text(advice, "Isso n\u00E3o significa necessariamente que sua TV est\u00E1 sem internet. O servidor de teste pode estar indispon\u00EDvel ou incompat\u00EDvel com este modelo. Tente novamente.");
                return;
            }
            grade = NexoSpeedTest.assessment(result.mbps, connection);
            text(value, result.mbps.toFixed(1).replace(".", ",") + " Mbps");
            text(phase, grade.label);
            text(advice, grade.advice);
        });
    }

    function activate(element) {
        var action = element.getAttribute("data-action");
        var chosen;
        var saved = true;
        if (action === "settings-section") { selectSection(element.getAttribute("data-section")); return true; }
        if (action === "settings-theme") {
            chosen = findTheme(element.getAttribute("data-theme"));
            if (!chosen) { return true; }
            themeId = chosen.id;
            applyTheme();
            if (callbacks.refreshMenuIcons) { callbacks.refreshMenuIcons(); }
            try { window.localStorage.setItem(themeKey, themeId); } catch (ignoreSave) { saved = false; }
            refreshThemeChecks();
            callbacks.toast(saved ? "Tema " + chosen.name + " salvo" : "Tema aplicado, mas a TV n\u00E3o permitiu salvar a escolha");
            return true;
        }
        if (action === "settings-speed-test") { callbacks.openSpeedModal(); return true; }
        if (action === "settings-speed-retest") { startSpeedTest(); return true; }
        return false;
    }

    function navigate(direction, focused, modalOpen) {
        var root = byId("settings-panel");
        var tabs;
        var items;
        var index = -1;
        var i;
        var action;
        var target;
        if (!root || !focused || modalOpen) { return false; }
        action = focused.getAttribute("data-action");
        if (focused.className.indexOf("menu-item") >= 0) {
            if (direction !== "right") { return false; }
            callbacks.focus(selectedTab());
            return true;
        }
        if (action === "settings-section") {
            tabs = byId("content-root").getElementsByClassName("settings-tab");
            for (i = 0; i < tabs.length; i += 1) { if (tabs[i] === focused) { index = i; } }
            if (direction === "left" || direction === "right") {
                target = direction === "left" ? index - 1 : index + 1;
                if (target < 0) { callbacks.focusMenu(); }
                else if (target < tabs.length) { selectSection(tabs[target].getAttribute("data-section")); callbacks.focus(tabs[target]); }
            } else if (direction === "down") {
                if (focused.getAttribute("data-section") !== activeSection) { selectSection(focused.getAttribute("data-section")); }
                items = root.getElementsByClassName("focusable");
                if (items.length) { callbacks.focus(items[0]); }
            }
            return true;
        }
        items = root.getElementsByClassName("focusable");
        for (i = 0; i < items.length; i += 1) { if (items[i] === focused) { index = i; } }
        if (index < 0) { return false; }
        if (action === "settings-theme") {
            if (direction === "up") { if (index < 4) { callbacks.focus(selectedTab()); } else { callbacks.focus(items[index - 4]); } }
            else if (direction === "down") { if (index + 4 < items.length) { callbacks.focus(items[index + 4]); } }
            else if (direction === "left") { if (index % 4 === 0) { callbacks.focusMenu(); } else { callbacks.focus(items[index - 1]); } }
            else if (direction === "right" && index % 4 < 3 && index + 1 < items.length) { callbacks.focus(items[index + 1]); }
        } else {
            if (direction === "up") { callbacks.focus(selectedTab()); }
            else if (direction === "left") { callbacks.focusMenu(); }
        }
        return true;
    }

    return { init: init, render: render, selectedTab: selectedTab, activate: activate, navigate: navigate,
        getThemeId: function () { return themeId; },
        startSpeedTest: startSpeedTest, cancelSpeedTest: function () { NexoSpeedTest.cancel(); } };
}());
