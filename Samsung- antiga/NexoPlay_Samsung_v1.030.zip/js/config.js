var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.030-legacy-server-delay-json",
    accessCodeUrl: "https://nexoplay88.github.io/app/Aplicativos/DNS-C%C3%B3digos/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
