var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.020-legacy-settings-themes",
    accessCodeUrl: "https://tvonplus.github.io/app/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
