var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.0.40-legacy-progressive-catalog-cache",
    accessCodeUrl: "https://tvonplus.github.io/app/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
